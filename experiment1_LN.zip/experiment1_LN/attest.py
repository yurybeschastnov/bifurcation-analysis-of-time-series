"""Independent numerical attestations; never used to select main-experiment fits."""
import json
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
from common import ROOT, dumps, metrics
from mssv import particle_loglik
from hmm import fit_range
from baselines import pelt_cluster


def grid_loglik(x, mu, phi, veta, A, size):
    """Direct quadrature over joint (h,z); independent of particle-filter code."""
    grid = np.linspace(-9., 9., size)
    dh = grid[1] - grid[0]
    K = len(mu)
    # Destination quadrature includes dh; no row renormalization hides tail loss.
    previous = grid[None, :, None]
    destination = grid[None, None, :]
    trans = np.empty((K, size, K, size))
    for j in range(K):
        for k in range(K):
            mean = mu[k] + phi * (grid - mu[j])
            trans[j, :, k, :] = (A[j, k] * dh / np.sqrt(2*np.pi*veta)
                * np.exp(-.5*(grid[None, :] - mean[:, None])**2/veta))
    transition = trans.reshape(K*size, K*size)
    alpha = np.exp(-.5*(grid[None, :] - mu[:, None])**2) * dh / (K*np.sqrt(2*np.pi))
    ll = 0.
    for i, observation in enumerate(x):
        if i:
            alpha = (alpha.reshape(-1) @ transition).reshape(K, size)
        log_observation = -.5*np.log(2*np.pi) - grid/2 - observation**2*np.exp(-grid)/2
        offset = log_observation.max()
        alpha *= np.exp(log_observation - offset)[None, :]
        scale = alpha.sum()
        ll += np.log(scale) + offset
        alpha /= scale
    return float(ll)


def main():
    audits = {}
    generation = json.loads((ROOT/'truth'/'generation_audit.json').read_text())
    max_intersection = 0.
    max_identity = 0.
    max_balance = 0.
    min_refractory_gap = float('inf')
    for record in generation:
        f = np.load(ROOT/'truth'/f"{record['series']}.npz")
        K = len(f['parameters'])
        p = f['parameters'][f['z']]
        residual = np.max(np.abs(f['y'] - (p[:, 0] + p[:, 1]*f['t'] + p[:, 2]*f['w'] + p[:, 3]*f['w']**3)))
        max_identity = max(max_identity, float(residual))
        for key in ['occupancy_time', 'occupancy_points']:
            balance = float(np.max(np.abs(np.array(record[key]) - 1/K)))
            assert balance <= .025 + 1e-12
            max_balance = max(max_balance, balance)
        max_intersection = max(max_intersection, record['intersection_residual'])
        if len(f['event_t']) > 1:
            gap = float(np.min(np.diff(f['event_t'])))
            assert gap >= .02 - 1e-12
            min_refractory_gap = min(min_refractory_gap, gap)
    assert max_identity < 1e-12 and max_intersection < 1e-10
    audits['generator'] = dict(series=13, max_identity_residual=max_identity,
        max_intersection_residual=max_intersection, max_balance_error=max_balance,
        minimum_refractory_gap=min_refractory_gap, passed=True)

    # Small synthetic series from the exact MSSV model, independently simulated.
    rng = np.random.default_rng(97531)
    mu = np.array([-1.2, .8]); phi = .92; veta = .025
    A = np.array([[.97, .03], [.02, .98]])
    n = 60; z = int(rng.integers(2)); h = mu[z] + rng.normal(); x = np.empty(n)
    for i in range(n):
        if i:
            new_z = int(rng.choice(2, p=A[z]))
            h = mu[new_z] + phi*(h-mu[z]) + np.sqrt(veta)*rng.normal()
            z = new_z
        x[i] = np.exp(h/2)*rng.normal()
    grids = {str(size): grid_loglik(x, mu, phi, veta, A, size) for size in [241, 481, 961]}
    pf = np.array([particle_loglik(x, mu, phi, veta, A, 8000, 11000+j)[0] for j in range(8)])
    estimate = float(logsumexp(pf)-np.log(len(pf)))
    likelihoods = np.exp(pf-pf.max())
    mcse_log = float(likelihoods.std(ddof=1)/np.sqrt(len(pf))/likelihoods.mean())
    difference = abs(estimate-grids['961'])
    grid_error = abs(grids['481']-grids['961'])
    passed = bool(grid_error < 1e-4 and difference < 4*mcse_log+.01)
    audits['MSSV_particle_vs_grid'] = dict(n=n, K=2, particles=8000, independent_runs=8,
        grid_LL=grids, particle_LL=pf, log_mean_likelihood=estimate,
        approximate_log_MCSE=mcse_log, absolute_difference=difference,
        grid_refinement_difference=grid_error, passed=passed,
        interpretation='numerical likelihood check at fixed parameters, not MCMC convergence or recovery attestation')
    assert passed, 'Particle/grid likelihood attestation failed.'

    # Own-class Gaussian-HMM and piecewise-variance recovery, fixed seeds.
    rng = np.random.default_rng(86420)
    sig = np.array([.35, .75, 1.30]); n = 2500
    A = np.ones((3, 3))*.005 + np.eye(3)*.985
    z = np.empty(n, int); z[0] = 0
    for i in range(1, n):
        z[i] = rng.choice(3, p=A[z[i-1]])
    x = rng.normal(size=n)*sig[z]
    models = fit_range(x, 6, restarts=10, seed=24680)
    fitted = min(models, key=lambda m:m['BIC'])
    audits['Gaussian_HMM_own_class'] = dict(K_true=3, K_hat=fitted['K'],
        **metrics(z, fitted['labels'], sig[z], fitted['sigma'][fitted['labels']]),
        candidate_BIC=[dict(K=m['K'], BIC=m['BIC']) for m in models],
        interpretation='one independent own-class realization; not a consistency guarantee')
    rng = np.random.default_rng(13579)
    z = np.repeat(np.arange(4), 625); sig = np.array([.4, .6, 1.2, 1.5])
    x = rng.normal(size=2500)*sig[z]
    fitted = pelt_cluster(x, seed=11223)
    audits['PELT_own_class'] = dict(K_true=4, K_hat=fitted['K'],
        **metrics(z, fitted['labels'], sig[z], fitted['sigma'][fitted['labels']]),
        segment_edges=fitted['segment_edges'], interpretation='one own-class realization')
    (ROOT/'results'/'numerical_attestation.json').write_text(dumps(audits))
    print(dumps(audits))


if __name__ == '__main__':
    main()
