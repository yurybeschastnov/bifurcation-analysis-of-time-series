"""Reproduce changed benchmark settings, with truth confined to final scoring.
This does not replace any baseline with its worst variant, or tune on metrics.
"""
from __future__ import annotations
import os
for var in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[var]='1'
import pickle,json,hashlib,argparse,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import pandas as pd
from common import ROOT,prepare,metrics,dumps
from baselines import kernel_sigma
from hdp_sensitivity import fit_hdp_variant
OUT=ROOT/'revision3';(OUT/'baseline_variants').mkdir(parents=True,exist_ok=True)
NAMES=[f'L{i}' for i in range(1,7)]+[f'N{i}' for i in range(1,8)]


def fit_one(name):
    before=time.perf_counter();f=np.load(ROOT/'data'/f'{name}.npz',allow_pickle=False);t,y,T,scale=prepare(f['t'],f['y'])
    x=np.diff(y)/np.sqrt(np.diff(t));hmms=pickle.load(open(ROOT/'results'/f'{name}_hmm.pkl','rb'))
    prior=pickle.load(open(ROOT/'results'/f'{name}_baselines.pkl','rb'));out={};audit=[]
    def wrap(m):
        z=m['labels'];s=m['sigma'][z]
        return dict(K=m['K'],labels=np.r_[z[0],z],volatility=np.r_[s[0],s])
    for crit in ['BIC','AIC','ICL']:
        # The primary table uses K^2+K-1, i.e. K fewer parameters than full.
        adjust=lambda m:m[crit]-m['K']*(2 if crit=='AIC' else np.log(len(x)))
        m=min(hmms,key=adjust);out[f'HMM_{crit}_paper_count']=wrap(m)
        audit.append(dict(kind='HMM_count',criterion=crit,K_previous=prior[f'HMM_{crit}']['K'],K_paper=m['K']))
    m=min(hmms,key=lambda m:m['BIC']-m['K']*np.log(len(x)))
    if m['K']==prior['Kernel_HMM']['K']:out['Kernel_HMM_paper_count']=prior['Kernel_HMM']
    else:
        sigma,details=kernel_sigma(y,t,m['labels'])
        out['Kernel_HMM_paper_count']=dict(K=m['K'],labels=np.r_[m['labels'][0],m['labels']],volatility=np.r_[sigma[0],sigma])
    seed=502000+sum((j+1)*ord(c) for j,c in enumerate(name))+2
    for mode in [0,1]:
        m=fit_hdp_variant(x,seed,mode);z=m['labels'];label='crt' if mode==0 else 'occupied_transitions'
        for summary in ['mean','representative']:
            s=m['volatility' if summary=='mean' else 'representative_volatility']
            out[f'HDP_{label}_{summary}']=dict(K=m['K'],labels=np.r_[z[0],z],volatility=np.r_[s[0],s])
        if mode==0:
            assert np.array_equal(out['HDP_crt_mean']['labels'],prior['sticky_HDP']['labels'])
            assert np.allclose(out['HDP_crt_mean']['volatility'],prior['sticky_HDP']['volatility'],rtol=0,atol=1e-12)
        audit.append(dict(kind='HDP',variant=label,K=m['K'],K_trace=m['K_trace'],representative_draw=m['representative_draw']))
    # An actual additional change: eight PF likelihood estimates were averaged.
    pfpath=ROOT/'results'/f'{name}_mssv.pkl'
    if pfpath.exists():
        cs=pickle.load(open(pfpath,'rb'))['candidates']
        def first_bic(m):return -2*m['particle_LL'][0]+(m['K']+2+m['K']*(m['K']-1))*np.log(len(x))
        selected=min(cs,key=first_bic);z=selected['labels'];s=selected['volatility']
        out['MSSV_one_PF_run']=dict(K=selected['K'],labels=np.r_[z[0],z],volatility=np.r_[s[0],s])
        audit.append(dict(kind='MSSV_particle_repeats',K_single=selected['K'],K_eight=min(cs,key=lambda m:m['BIC'])['K']))
    payload=dict(predictions=out,audit=audit,normalization=dict(T=T,scale=scale),seconds=time.perf_counter()-before)
    with open(OUT/'baseline_variants'/f'{name}.pkl','wb') as h:pickle.dump(payload,h)
    print(name,'fairness variants',round(payload['seconds'],1),flush=True)


def score_all():
    paths=[OUT/'baseline_variants'/f'{n}.pkl' for n in NAMES]
    (OUT/'baseline_variants'/'frozen_sha256.json').write_text(dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}))
    rows=[];adjust=[]
    for n,p in zip(NAMES,paths):
        q=pickle.load(open(p,'rb'));truth=np.load(ROOT/'truth'/f'{n}.npz',allow_pickle=False)
        for method,m in q['predictions'].items():
            s=m['volatility']*q['normalization']['scale']/np.sqrt(q['normalization']['T'])
            rows.append(dict(series=n,method=method,K_hat=m['K'],K_true=len(truth['parameters']),**metrics(truth['z'],m['labels'],truth['sigma'],s)))
        for a in q['audit']:
            if a['kind']!='HDP':adjust.append(dict(series=n,**a))
    pd.DataFrame(rows).to_csv(OUT/'baseline_sensitivity_metrics.csv',index=False)
    (OUT/'baseline_sensitivity_choices.json').write_text(dumps(adjust))
    # True-label evaluation of the previously saved pre-continuation DP outputs.
    before=pd.read_csv(ROOT/'results'/'metrics_before_DP_continuation.csv');after=pd.read_csv(ROOT/'results'/'metrics_all.csv')
    a=before[(before.method=='DP_HMM')&(before.grid=='full')].set_index('series')
    b=after[(after.method=='DP_HMM')&(after.grid=='full')].set_index('series')
    pd.concat([a[['K_hat','ARI','EL2']].add_suffix('_before'),b[['K_hat','ARI','EL2']].add_suffix('_after')],axis=1).to_csv(OUT/'DP_continuation_impact.csv')
    print('Fairness scoring complete',flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--score-only',action='store_true');p.add_argument('--workers',type=int,default=4);a=p.parse_args()
    if not a.score_only:
        with ProcessPoolExecutor(max_workers=a.workers) as ex:
            fs=[ex.submit(fit_one,n) for n in NAMES]
            for f in as_completed(fs):f.result()
    score_all()
if __name__=='__main__':main()
