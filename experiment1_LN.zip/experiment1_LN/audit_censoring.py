"""Fix quantile ties, refitting only changed masks. Never reads ground truth."""
import os
for var in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[var]='1'
import argparse,pickle,hashlib,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import pandas as pd
from common import ROOT,prepare,local_rv,dumps
from censoring_exact import ranked_mask
from branches_v3 import audit_profile
from stable_inference import finalize_stable
BASE=ROOT/'revision3';FINAL=BASE/'final_models';FINAL.mkdir(exist_ok=True)
NAMES=[f'L{i}' for i in range(1,7)]+[f'N{i}' for i in range(1,8)]


def one(name,K):
    before=time.perf_counter();f=np.load(ROOT/'data'/f'{name}.npz',allow_pickle=False)
    t,y,T,scale=prepare(f['t'],f['y']);rv=local_rv(y,t,40);mask=ranked_mask(rv);family=str(f['family'])
    v3=pickle.load(open(BASE/f'{name}_branches.pkl','rb'));v2=pickle.load(open(ROOT/'revision2'/f'{name}_branches.pkl','rb'))
    m,trace=audit_profile([('v3',v3['candidates'][K-1]),('v2',v2['candidates'][K-1])],t,y,rv,mask,family)
    path=FINAL/f'{name}_K{K}.pkl'
    with open(path,'wb') as h:pickle.dump(dict(model=m,trace=trace,mask=mask,normalization=dict(T=T,scale=scale)),h)
    print('MASK REFIT',name,K,m['ll'],'seconds',round(time.perf_counter()-before,1),flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workers',type=int,default=4);p.add_argument('--validate-only',action='store_true');a=p.parse_args()
    changed=[];rows=[]
    for name in NAMES:
        f=np.load(ROOT/'data'/f'{name}.npz',allow_pickle=False);t,y,T,scale=prepare(f['t'],f['y']);rv=local_rv(y,t,40)
        prev=pickle.load(open(BASE/f'{name}_branches.pkl','rb'));mask=ranked_mask(rv);is_changed=not np.array_equal(mask,prev['mask'])
        rows.append(dict(series=name,n=len(y),excluded_old=int((~prev['mask']).sum()),excluded_ranked=int((~mask).sum()),mask_changes=int((prev['mask']!=mask).sum()),anchor_retained=True))
        if is_changed:changed.append(name)
        elif not a.validate_only:
            with open(FINAL/f'{name}_branches.pkl','wb') as h:pickle.dump(prev,h)
    if not a.validate_only:
        with ProcessPoolExecutor(max_workers=a.workers) as ex:
            fs=[ex.submit(one,n,K) for n in changed for K in range(1,7)]
            for f in as_completed(fs):f.result()
        for name in changed:
            payloads=[pickle.load(open(FINAL/f'{name}_K{K}.pkl','rb')) for K in range(1,7)];models=[p['model'] for p in payloads]
            f=np.load(ROOT/'data'/f'{name}.npz');t,y,T,scale=prepare(f['t'],f['y']);rv=local_rv(y,t,40);mask=ranked_mask(rv);family=str(f['family'])
            for i in range(1,6):
                prev=models[i-1];P=np.vstack([prev['P'],[0.,0.,max(20.,8*rv.max()),0.]])
                emb=finalize_stable(dict(P=P,kappa=prev['kappa'],source='rank-mask-dormant',optimizer=[]),t,y,rv,mask,family,False)
                if emb is not None and emb['QV_valid'] and emb['ll']>models[i]['ll']:models[i]=emb
            best=min(models,key=lambda m:m['BIC']);best['BIC_gap']=min(m['BIC'] for m in models if m is not best)-best['BIC']
            with open(FINAL/f'{name}_branches.pkl','wb') as h:pickle.dump(dict(selected=best,candidates=models,mask=mask,normalization=dict(T=T,scale=scale)),h)
    pd.DataFrame(rows).to_csv(BASE/'censoring_audit.csv',index=False)
    print(pd.DataFrame(rows).to_string(index=False))
if __name__=='__main__':main()
