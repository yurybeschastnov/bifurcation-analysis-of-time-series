"""Independent NumPy/SciPy reference for the exact LOCAL score in pp.34-38.
It deliberately does not call the production inverse or pair-potential functions.
This evaluates the written discrete path criterion, not a new first-hit model.
"""
from __future__ import annotations
import numpy as np
from scipy.special import logsumexp


def inverse_bisection(y,t,P):
    rho=np.asarray(y)[:,None]-P[None,:,0]-np.asarray(t)[:,None]*P[None,:,1]
    mag=np.abs(rho); b=P[None,:,2]; r=P[None,:,3]/3.
    if np.any(b<=0) or np.any(r<0):raise ValueError('Non-monotone branch')
    hi=mag/b;lo=np.zeros_like(hi)
    for _ in range(80):
        mid=(lo+hi)/2;above=b*mid+r*mid**3>=mag
        hi=np.where(above,mid,hi);lo=np.where(above,lo,mid)
    w=np.sign(rho)*(lo+hi)/2
    return w,b+3*r*w*w


def reference_score(y,t,rv,P,kappa,return_arrays=False):
    w,s=inverse_bisection(y,t,P);n,K=w.shape;dt=np.diff(t)
    delta=w[1:,None,:]-w[:-1,:,None]
    allowed=(np.abs(delta)<=8*np.sqrt(dt)[:,None,None]) & (s[1:,None,:]>=.25*np.asarray(rv)[1:,None,None]) & (s[1:,None,:]<=4*np.asarray(rv)[1:,None,None])
    weights=np.exp(-kappa*(1-np.eye(K)))[None,:,:]*allowed
    den=weights.sum(axis=2,keepdims=True)
    q=np.divide(weights,den,out=np.zeros_like(weights),where=den>0)
    with np.errstate(divide='ignore'):
        L=-delta*delta/(2*dt[:,None,None])-.5*np.log(2*np.pi*dt)[:,None,None]-np.log(s[1:,None,:])+np.log(q)
    alpha=np.full(K,-np.inf);alpha[0]=0.
    for i in range(n-1):alpha=np.logaddexp.reduce(alpha[:,None]+L[i],axis=0)
    ll=float(np.logaddexp.reduce(alpha))
    return (ll,L,w,s,q) if return_arrays else ll
