import sys,json,pickle,time
from pathlib import Path
import numpy as np
from common import prepare,local_rv,metrics,dumps
from branches import *
BASE=Path(__file__).resolve().parent;OUT=BASE/'revision2'
rows=[]
for path in sorted((BASE/'data').glob('*.npz')):
 name=path.stem;f=np.load(path);tr=np.load(BASE/'truth'/f'{name}.npz');p=pickle.load(open(BASE/'results'/f'{name}_branches.pkl','rb'));m=p['selected']
 t,y,T,scale=prepare(f['t'],f['y']);rv=local_rv(y,t,40);mask=p['mask'];tk=t[mask];yk=y[mask];rk=rv[mask]
 P=tr['parameters'].copy();P[:,0]/=scale;P[:,1]*=T/scale;P[:,2]*=np.sqrt(T)/scale;P[:,3]*=3*T**1.5/scale
 ll,kappa,_=profile(P,yk,tk,rk);ora=finalize(dict(P=P,kappa=kappa),t,y,rv,mask,str(f['family']))
 _,g=evaluate(m['P'],yk,tk,rk,m['kappa']);g[0,0]=0
 if str(f['family'])=='affine':g[:,3]=0
 g[:,3]=np.where((m['P'][:,3]==0)&(g[:,3]<0),0,g[:,3])
 blls=[]
 for Q,kap in [(m['P'],m['kappa']),(P,kappa)]:
  w,s,_,_=inversion(yk,tk,Q);L,dq=pair_potentials(w,s,tk,rk,kap,True);blls.append((pair_forward(L,dq)[0],tilted_log_forward(L,dq,0.)))
 row=dict(series=name,old_ll=m['ll'],oracle_ll=ll,oracle_minus_old=ll-m['ll'],gradient_max=float(abs(g).max()),oracle_kappa=kappa,oracle_metrics=metrics(tr['z'],ora['labels'],tr['sigma'],ora['volatility']*scale/np.sqrt(T)),old_switches=int(np.count_nonzero(np.diff(m['labels']))),oracle_switches=int(np.count_nonzero(np.diff(ora['labels']))),forward_log_vs_scaled=[a-b for a,b in blls],oracle_P=P)
 rows.append(row);print(name,'old',round(m['ll'],4),'oracle',round(ll,4),'diff',round(ll-m['ll'],4),'grad',round(abs(g).max(),3),'oracle metrics',row['oracle_metrics'],flush=True)
(OUT/'initial_audit.json').write_text(dumps(rows))
