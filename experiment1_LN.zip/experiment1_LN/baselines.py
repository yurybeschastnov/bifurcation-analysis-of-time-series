"""Independent implementations of the comparison procedures in section 3.
Unpruned exact dynamic programming minimizes the same segmentation objective
as PELT, with no risk of unsafe minimum-segment-length pruning.
"""
import numpy as np
from numba import njit
from sklearn.cluster import KMeans
from sklearn.mixture import BayesianGaussianMixture
from common import local_rv
from hmm import fit_hmm
@njit(cache=True)
def segment_variance(x,penalty,minlen=15):
 n=len(x);s=np.zeros(n+1);ss=np.zeros(n+1);s[1:]=np.cumsum(x);ss[1:]=np.cumsum(x*x)
 val=np.full(n+1,1e300);pr=np.full(n+1,-1,np.int64);val[0]=-penalty;floor=max(np.var(x)*1e-8,1e-12)
 for end in range(minlen,n+1):
  for start in range(end-minlen+1):
   if start>0 and start<minlen:continue
   m=end-start;mean=(s[end]-s[start])/m;var=max((ss[end]-ss[start])/m-mean*mean,floor);cost=val[start]+m*np.log(var)+penalty
   if cost<val[end]:val[end]=cost;pr[end]=start
 return val,pr

def pelt_cluster(x,Kmax=6,seed=0):
 n=len(x);val,pr=segment_variance(np.asarray(x,float),2*np.log(n));edges=[n]
 while edges[-1]>0:
  if pr[edges[-1]]<0:raise RuntimeError('No feasible segmentation')
  edges.append(int(pr[edges[-1]]))
 edges=np.array(edges[::-1]);lengths=np.diff(edges);lv=np.array([np.log(max(np.var(x[a:b]),1e-12)) for a,b in zip(edges[:-1],edges[1:])]);models=[]
 for K in range(1,min(Kmax,len(lengths))+1):
  km=KMeans(n_clusters=K,n_init=20,random_state=seed+K).fit(lv[:,None],sample_weight=lengths);z=np.repeat(km.labels_,lengths)
  mu=np.array([np.mean(x[z==k]) for k in range(K)]);sig=np.array([np.sqrt(max(np.var(x[z==k]),1e-12)) for k in range(K)])
  ll=np.sum(-.5*((x-mu[z])/sig[z])**2-np.log(sig[z])-.5*np.log(2*np.pi));models.append(dict(K=K,labels=z,sigma=sig,BIC=float(-2*ll+2*K*np.log(n)),ll=float(ll)))
 out=min(models,key=lambda m:m['BIC']);out.update(segment_edges=edges,models_summary=[{'K':m['K'],'BIC':m['BIC']} for m in models]);return out

def dp_hmm(x,models,seed=0):
 bgm=BayesianGaussianMixture(n_components=10,weight_concentration_prior_type='dirichlet_process',weight_concentration_prior=1.,covariance_type='full',n_init=4,max_iter=1500,tol=1e-6,reg_covar=1e-6*np.var(x),random_state=seed).fit(x[:,None])
 continuations=[];total_iterations=int(bgm.n_iter_)
 # Continuation is triggered ONLY by the optimizer's convergence flag, not true K
 # or validation accuracy. It retains the best initial variational solution.
 if not bgm.converged_:
  bgm.warm_start=True
  for budget in [3000,6000,10000]:
   previous=float(bgm.lower_bound_);bgm.max_iter=budget;bgm.fit(x[:,None]);total_iterations+=int(bgm.n_iter_)
   continuations.append(dict(budget=budget,iterations=int(bgm.n_iter_),lower_bound=float(bgm.lower_bound_),gain=float(bgm.lower_bound_-previous),converged=bool(bgm.converged_)))
   if bgm.converged_:break
 q=np.bincount(bgm.predict(x[:,None]),minlength=10)/len(x);K=max(1,int(np.sum(q>.02)));m=models[K-1] if K<=len(models) else fit_hmm(x,K,restarts=10,seed=seed)
 return m,dict(hard_occupancy=q.tolist(),K=K,converged=bool(bgm.converged_),iterations=total_iterations,continuations=continuations)
@njit(cache=True)
def local_linear_predictions(w,v,bw,loo=False):
 n=len(w);out=np.empty(n)
 for i in range(n):
  s0=0.;s1=0.;s2=0.;v0=0.;v1=0.
  for j in range(n):
   if loo and i==j:continue
   d=w[j]-w[i];u=d/bw
   if abs(u)>8:continue
   a=np.exp(-.5*u*u);s0+=a;s1+=a*d;s2+=a*d*d;v0+=a*v[j];v1+=a*d*v[j]
  det=s0*s2-s1*s1
  if det>1e-14:out[i]=(s2*v0-s1*v1)/det
  else:out[i]=v0/max(s0,1e-14)
 return np.maximum(out,1e-8)

def kernel_sigma(y,t,labels):
 rv=local_rv(y,t,80);w=np.cumsum(np.diff(y)/rv[1:]);x=np.diff(y)/np.sqrt(np.diff(t));v=x*x;out=np.empty(len(x));bws={}
 for k in np.unique(labels):
  mask=labels==k;wk=w[mask];vk=v[mask];best=None
  for bw in [.03,.05,.08,.12,.2,.3,.5]:
   pred=local_linear_predictions(wk,vk,bw,True);cv=float(np.mean((vk-pred)**2))
   if best is None or cv<best[0]:best=(cv,bw)
  bw=best[1];out[mask]=np.sqrt(local_linear_predictions(wk,vk,bw));bws[int(k)]=bw
 return out,dict(bandwidths=bws,driver=w)
