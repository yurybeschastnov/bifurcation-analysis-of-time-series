"""Independent implementation of root-branch inference (preprint, pp.34-38).
All optimization uses observations only. Coordinates are P=(c,a,b,d), d=3r,
where b=sigma(0), b+d=sigma(1). The first active branch is anchored at c0=0.

A K-state forward recursion sums LOCAL admissible path weights. The extra global
QV condition is NOT automatically enforced by this recursion: qv_certificate()
bounds its omitted mass by tilted forward sums. See the generated audit/report.
"""
import numpy as np
from numba import njit
from scipy.optimize import minimize
from common import local_rv,censor_mask,nearest_indices
KAPPAS=np.arange(2.5,9.01,.5)

@njit(cache=True)
def inverse_scalar(rho,b,r):
 if b<=0 or r<0:return np.nan
 if r==0:return rho/b
 z=1.5*(rho/b)*np.sqrt(3.*r/b)
 w=2.*np.sqrt(b/(3.*r))*np.sinh(np.arcsinh(z)/3.)
 w-=(b*w+r*w*w*w-rho)/(b+3*r*w*w)
 return w

@njit(cache=True)
def inversion(y,t,P):
 n=len(y);K=len(P);w=np.empty((n,K));sig=np.empty((n,K));dw=np.empty((n,K,4));ds=np.empty((n,K,4))
 for i in range(n):
  for j in range(K):
   c,a,b,d=P[j];v=inverse_scalar(y[i]-c-a*t[i],b,d/3.);s=b+d*v*v
   w[i,j]=v;sig[i,j]=s;dw[i,j,0]=-1/s;dw[i,j,1]=-t[i]/s;dw[i,j,2]=-v/s;dw[i,j,3]=-v*v*v/(3*s)
   for q in range(4):ds[i,j,q]=2*d*v*dw[i,j,q]
   ds[i,j,2]+=1.;ds[i,j,3]+=v*v
 return w,sig,dw,ds

@njit(cache=True)
def pair_potentials(w,sig,t,rv,kappa,hard=True):
 n,K=w.shape;L=np.full((n-1,K,K),-np.inf);dq=np.empty((n-1,K,K));sw=np.exp(-kappa)
 for i in range(1,n):
  dt=t[i]-t[i-1]
  for k in range(K):
   den=0.
   for j in range(K):
    delta=w[i,j]-w[i-1,k];dq[i-1,k,j]=delta*delta
    ok=(not hard) or (abs(delta)<=8*np.sqrt(dt) and .25*rv[i]<=sig[i,j] and sig[i,j]<=4*rv[i])
    if ok:den+=1. if j==k else sw
   if den==0:continue
   for j in range(K):
    delta=w[i,j]-w[i-1,k]
    ok=(not hard) or (abs(delta)<=8*np.sqrt(dt) and .25*rv[i]<=sig[i,j] and sig[i,j]<=4*rv[i])
    if ok:L[i-1,k,j]=-.5*delta*delta/dt-.5*np.log(2*np.pi*dt)-np.log(sig[i,j])-np.log(den)-(kappa if k!=j else 0.)
 return L,dq

@njit(cache=True)
def pair_forward(L,dq,tilt=0.):
 n1,K,_=L.shape;af=np.zeros((n1+1,K));af[0,0]=1.;sc=np.empty(n1);off=np.empty(n1);ll=0.
 for i in range(n1):
  mx=-np.inf
  for k in range(K):
   for j in range(K):
    v=L[i,k,j]+tilt*dq[i,k,j]
    if v>mx:mx=v
  if not np.isfinite(mx):return -np.inf,af,sc,off
  off[i]=mx
  for j in range(K):
   val=0.
   for k in range(K):val+=af[i,k]*np.exp(L[i,k,j]+tilt*dq[i,k,j]-mx)
   af[i+1,j]=val
  s=af[i+1].sum()
  if s<=0 or not np.isfinite(s):return -np.inf,af,sc,off
  sc[i]=s;af[i+1]/=s;ll+=mx+np.log(s)
 return ll,af,sc,off

@njit(cache=True)
def pair_gradient(L,af,sc,off,w,sig,dw,ds,t):
 n,K=w.shape;g=np.zeros((K,4));beta=np.ones(K);gamma=np.empty((n,K));gamma[-1]=af[-1]
 for i in range(n-2,-1,-1):
  dt=t[i+1]-t[i];prevbeta=np.zeros(K)
  for k in range(K):
   for j in range(K):
    b=np.exp(L[i,k,j]-off[i])*beta[j]/sc[i];prevbeta[k]+=b;xi=af[i,k]*b;delta=w[i+1,j]-w[i,k]
    for q in range(4):
     g[j,q]+=xi*(-delta/dt*dw[i+1,j,q]-ds[i+1,j,q]/sig[i+1,j])
     g[k,q]+=xi*(delta/dt*dw[i,k,q])
  gamma[i]=af[i]*prevbeta;ss=gamma[i].sum()
  if ss>0:gamma[i]/=ss
  beta=prevbeta
 return g,gamma

@njit(cache=True)
def pair_viterbi(L):
 n1,K,_=L.shape;v=np.full((n1+1,K),-np.inf);v[0,0]=0.;ptr=np.zeros((n1+1,K),np.int64)
 for i in range(n1):
  for j in range(K):
   mx=-np.inf;arg=0
   for k in range(K):
    val=v[i,k]+L[i,k,j]
    if val>mx:mx=val;arg=k
   v[i+1,j]=mx;ptr[i+1,j]=arg
 z=np.empty(n1+1,np.int64);z[-1]=np.argmax(v[-1])
 for i in range(n1-1,-1,-1):z[i]=ptr[i+1,z[i+1]]
 return z,np.max(v[-1])

@njit(cache=True)
def evaluate(P,y,t,rv,kappa,hard=True,gradient=True):
 w,s,dw,ds=inversion(y,t,P);L,dq=pair_potentials(w,s,t,rv,kappa,hard);ll,af,sc,off=pair_forward(L,dq)
 if not np.isfinite(ll):return ll,np.zeros(P.shape)
 if gradient:
  g,ga=pair_gradient(L,af,sc,off,w,s,dw,ds,t);return ll,g
 return ll,np.zeros(P.shape)

def profile(P,y,t,rv,hard=True):
 w,s,_,_=inversion(y,t,P);lls=[]
 for kappa in KAPPAS:
  L,dq=pair_potentials(w,s,t,rv,kappa,hard);lls.append(pair_forward(L,dq)[0])
 a=int(np.argmax(lls));return float(lls[a]),float(KAPPAS[a]),np.array(lls)

@njit(cache=True)
def tilted_log_forward(L,dq,tilt):
 """Fully log-space recursion: a common probability-space scale is unsafe for
 large tilts, especially across long gaps left by censoring."""
 n1,K,_=L.shape;alpha=np.full(K,-np.inf);alpha[0]=0.
 for i in range(n1):
  nxt=np.full(K,-np.inf)
  for j in range(K):
   mx=-np.inf
   for k in range(K):
    v=alpha[k]+L[i,k,j]+tilt*dq[i,k,j]
    if v>mx:mx=v
   if np.isfinite(mx):
    total=0.
    for k in range(K):total+=np.exp(alpha[k]+L[i,k,j]+tilt*dq[i,k,j]-mx)
    nxt[j]=mx+np.log(total)
  alpha=nxt
 mx=np.max(alpha)
 if not np.isfinite(mx):return -np.inf
 return mx+np.log(np.exp(alpha-mx).sum())


def qv_certificate(L,dq,T):
 """For posterior local path weights, P(Q out of [.7T,1.4T]) <= returned bound.
 Uses E exp(lambda Q)=Z(lambda)/Z(0). It is a conservative bound, not a sample.
 It certifies the local-vs-global log-score gap, NOT that an optimizer is global.
 """
 ll=pair_forward(L,dq)[0]
 if not np.isfinite(ll):return dict(excluded_mass_bound=1.,loglik_gap_bound=np.inf)
 if L.shape[1]==1:
  q=float(dq[:,0,0].sum()/T);p=0. if .7<=q<=1.4 else 1.
  return dict(excluded_mass_bound=p,loglik_gap_bound=0. if p==0 else np.inf,QV=q,kind='deterministic')
 mags=[1.,2.,5.,10.,20.,50.,100.,200.,500.,1000.,2000.,5000.,10000.]
 lower=0.;upper=0.;bestlo=0.;besthi=0.
 for m in mags:
  a=tilted_log_forward(L,dq,-m)-ll+m*.7*T;b=tilted_log_forward(L,dq,m)-ll-m*1.4*T
  if not np.isfinite(a) or not np.isfinite(b):raise FloatingPointError('Nonfinite tilted log sum')
  if a<lower:lower=a;bestlo=-m
  if b<upper:upper=b;besthi=m
 logp=min(0.,float(np.logaddexp(lower,upper)))
 # Round an underflowed positive bound UP, not to a falsely exact zero.
 p=float(np.exp(max(logp,np.log(1e-300))))
 return dict(excluded_mass_bound=p,loglik_gap_bound=float(-np.log1p(-p)) if p<1 else np.inf,
  log_excluded_mass_bound=logp,log_lower_tail_bound=lower,log_upper_tail_bound=upper,tilt_lower=bestlo,tilt_upper=besthi,kind='Chernoff tilted-forward upper bound')


def affine_start(y,t,model,drift=True):
 """Blind initialization: HMM volatility plus driver continuity at estimated switches."""
 K=model['K'];z0=np.r_[model['labels'][0],model['labels']];order=[int(z0[0])]+[j for j in range(K) if j!=z0[0]]
 remap=np.empty(K,int);remap[order]=np.arange(K);z=remap[z0];b=np.maximum(model['sigma'][order],.03);P=np.zeros((K,4));P[:,2]=b
 if K==1:
  P[0,1]=y[-1]/t[-1] if drift else 0.;return P,z
 changes=np.flatnonzero(z[1:]!=z[:-1])+1;A=[];rhs=[]
 for i in changes:
  old=z[i-1];new=z[i];tm=.5*(t[i-1]+t[i]);ym=.5*(y[i-1]+y[i]);row=np.zeros(2*(K-1))
  for k,sgn in [(new,1.),(old,-1.)]:
   if k>0:row[k-1]+=sgn;row[K-1+k-1]+=sgn*tm
  A.append(row);rhs.append(ym*(1/b[new]-1/b[old]))
 if A:
  A=np.array(A);rhs=np.array(rhs);coef=np.linalg.solve(A.T@A+1e-5*np.eye(2*(K-1)),A.T@rhs)
  P[1:,0]=b[1:]*coef[:K-1];P[1:,1]=b[1:]*coef[K-1:]
 if drift:
  end=z[-1];v=(y[-1]-P[end,0]-P[end,1]*t[-1])/(b[end]*t[-1]);P[:,1]+=b*v
 P[:,:2]=np.clip(P[:,:2],-12.,12.);return P,z


def make_bounds(K,family):
 out=[]
 for j in range(K):out.extend([(0.,0.) if j==0 else (-20.,20.),(-20.,20.),(.0005,20.),(0.,0.) if family=='affine' else (0.,60.)])
 return out


def optimize_start(P,y,t,rv,family,kappas=KAPPAS,maxiter=180,hard=True,profile_rounds=2):
 """Coordinate profile in discrete kappa, analytic gradient for continuous params.
 Every profile cycle checks all 14 kappa. Best visited parameters always retained,
 even after line-search failure caused by hard support boundaries.
 """
 K=len(P);bounds=make_bounds(K,family);P=np.array(P,float).copy();P[0,0]=0.
 if family=='affine':P[:,3]=0.
 flat=P.ravel();flat=np.array([np.clip(x,*b) for x,b in zip(flat,bounds)]);bestll,kappa,_=profile(flat.reshape(K,4),y,t,rv,hard)
 bestP=flat.reshape(K,4).copy();logs=[]
 for cycle in range(profile_rounds):
  cache={'ll':bestll,'P':bestP.copy()}
  def objective(x):
   Q=x.reshape(K,4);ll,g=evaluate(Q,y,t,rv,kappa,hard,True)
   if not np.isfinite(ll):return 1e20,np.zeros_like(x)
   if ll>cache['ll']:cache.update(ll=ll,P=Q.copy())
   return -ll,-g.ravel()
  res=minimize(objective,bestP.ravel(),jac=True,bounds=bounds,method='L-BFGS-B',options={'maxiter':maxiter,'maxls':30,'ftol':2e-10,'gtol':1e-4})
  Q=cache['P'];ll,newkappa,grid=profile(Q,y,t,rv,hard)
  logs.append(dict(cycle=cycle,ll=float(ll),kappa=float(newkappa),success=bool(res.success),message=str(res.message),iterations=int(res.nit),evaluations=int(res.nfev)))
  improved=ll>bestll+1e-7;changed=newkappa!=kappa
  if ll>=bestll:bestll=ll;bestP=Q.copy()
  kappa=newkappa
  if not changed and not improved:break
 return dict(P=bestP,ll=float(bestll),kappa=float(kappa),optimizer=logs)

@njit(cache=True)
def vol_objective(P,y,t,x2,weights):
 """Smooth, drift-free local-Gaussian auxiliary objective, only for starts."""
 w,s,dw,ds=inversion(y,t,P);g=np.zeros(P.shape);val=0.
 for i in range(len(y)):
  for j in range(len(P)):
   wt=weights[i,j];ss=s[i,j];v=x2[i]/(ss*ss);val+=wt*(np.log(ss)+.5*v)
   for q in range(4):g[j,q]+=wt*(1-v)/ss*ds[i,j,q]
 return val,g

def volatility_start(P,y,t,gamma,family,maxiter=160):
 if family=='affine':return P
 x2=np.r_[np.diff(y)[0]**2/np.diff(t)[0],np.diff(y)**2/np.diff(t)];K=len(P);bounds=make_bounds(K,family)
 def fun(flat):
  v,g=vol_objective(flat.reshape(K,4),y,t,x2,gamma);return v,g.ravel()
 res=minimize(fun,P.ravel(),jac=True,bounds=bounds,method='L-BFGS-B',options={'maxiter':maxiter,'ftol':1e-9,'maxls':25})
 return res.x.reshape(K,4)


def finalize(candidate,t,y,rv,mask,family):
 P=candidate['P'];tk=t[mask];yk=y[mask];rk=rv[mask]
 w,s,dw,ds=inversion(yk,tk,P);L,dq=pair_potentials(w,s,tk,rk,candidate['kappa'],True);ll,af,sc,off=pair_forward(L,dq)
 if not np.isfinite(ll):return None
 z,vl=pair_viterbi(L);ids=np.arange(len(z));wpath=w[ids,z];qv=float(np.sum(np.diff(wpath)**2)/(tk[-1]-tk[0]))
 mapping=nearest_indices(t,tk);zall=z[mapping];wall,sall,_,_=inversion(y,t,P);idx=np.arange(len(t));sigall=sall[idx,zall]
 cert=qv_certificate(L,dq,tk[-1]-tk[0]);p=3 if family=='affine' else 4
 out=dict(candidate);out.update(K=len(P),family=family,ll=float(ll),BIC=float(-2*ll+p*len(P)*np.log(mask.sum())),
   labels=zall,volatility=sigall,driver=wall[idx,zall],QV=qv,QV_valid=bool(.7<=qv<=1.4),certificate=cert,
   viterbi_ll=float(vl),mask=mask,retained_t=tk,retained_driver=wpath,occupied_states=int(len(np.unique(zall))))
 return out
