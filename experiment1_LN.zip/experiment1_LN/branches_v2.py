"""Audit revision: robust multistart optimization of the UNCHANGED §2.3 score.
No ground truth is imported. The geometric-support audit is in a separate module.
The objective is divided by n, parameter coordinates are scaled, and invalid
proposals return infinity (not a huge constant with a zero gradient).
"""
import numpy as np
from scipy.optimize import minimize,lsq_linear
from branches import (inversion,evaluate,profile,make_bounds,affine_start,
                      volatility_start,finalize,KAPPAS)


def refine(P,y,t,rv,family,maxiter=600,rounds=4,hard=True):
    P=np.array(P,dtype=float,copy=True);K=len(P);P[0,0]=0
    bounds=make_bounds(K,family)
    # Scale raw polynomial coefficients. d=3r is the increment sigma(1)-sigma(0).
    scales=np.tile([.15,.3,.5,1.5],K)
    lows=np.array([b[0] for b in bounds]);highs=np.array([b[1] for b in bounds])
    P=np.clip(P.ravel(),lows,highs).reshape(K,4)
    ll,kappa,_=profile(P,y,t,rv,hard)
    if not np.isfinite(ll):
        return None
    bestP=P.copy();bestll=ll;logs=[]
    for cycle in range(rounds):
        record=[bestll,bestP.copy()]
        def objective(x):
            Q=(x*scales).reshape(K,4)
            val,gradient=evaluate(Q,y,t,rv,kappa,hard,True)
            if not np.isfinite(val):
                return np.inf,np.zeros_like(x)
            if val>record[0]: record[:]=[float(val),Q.copy()]
            return -val/len(y),-gradient.ravel()*scales/len(y)
        res=minimize(objective,bestP.ravel()/scales,jac=True,
                     bounds=list(zip(lows/scales,highs/scales)),method='L-BFGS-B',
                     options={'maxiter':maxiter,'maxls':80,'maxcor':20,
                              'ftol':2e-14,'gtol':2e-7})
        Q=record[1];val,newkappa,_=profile(Q,y,t,rv,hard)
        logs.append(dict(cycle=cycle,ll=float(val),kappa=float(newkappa),
                         success=bool(res.success),message=str(res.message),
                         iterations=int(res.nit),evaluations=int(res.nfev)))
        improvement=val-bestll;changed=newkappa!=kappa
        if val>=bestll:bestll=float(val);bestP=Q.copy()
        kappa=newkappa
        if not changed and improvement<1e-6: break
    return dict(P=bestP,ll=bestll,kappa=float(kappa),optimizer=logs)


def driver_regression_starts(y,t,hmm,rv,family):
    """Data-only starts from de-volatilization, not final objective/estimates."""
    K=hmm['K'];_,labels=affine_start(y,t,hmm,False)
    wh=np.r_[0.,np.cumsum(np.diff(y)/rv[1:])]
    if family=='affine':return []
    starts=[]
    for drift in [-1.,-.5,0.,.5,1.]:
        w=wh-drift*t;X=np.column_stack([np.ones(len(y)),t,w,w**3/3])
        P=np.zeros((K,4))
        for j in range(K):
            idx=labels==j;free=[1,2,3] if j==0 else [0,1,2,3]
            bounds=([-20.,.0005,0.],[20.,20.,60.]) if j==0 else ([-20.,-20.,.0005,0.],[20.,20.,20.,60.])
            if np.sum(idx)<10:
                P[j]=[0.,0.,max(float(hmm['sigma'][j]),.03),0.]
            else:
                fit=lsq_linear(X[idx][:,free],y[idx],bounds=bounds,tol=1e-8,max_iter=150)
                P[j,free]=fit.x
        starts.append((P,f'devol-regression-drift-{drift}'))
    return starts


def blind_starts(y,t,rv,hmm,family,rng,nrandom=16):
    K=hmm['K'];P,z=affine_start(y,t,hmm,True);P0,_=affine_start(y,t,hmm,False)
    starts=[(P,'HMM-affine-drift'),(P0,'HMM-affine-no-drift')]
    if family=='cubic':
        starts+=driver_regression_starts(y,t,hmm,rv,family)
        for base,lab in [(P,'drift'),(P0,'no-drift')]:
            Q=volatility_start(base.copy(),y,t,np.eye(K)[z],family,maxiter=400)
            starts.append((Q,'volatility-aux-'+lab))
        # Random geometries are bounded in data-normalized units. No true c,a,b,r.
        for index in range(nrandom):
            Q=P0.copy()
            if index%3==0:
                Q[:,0]=rng.normal(0,.25,K);Q[:,1]=rng.normal(0,.3,K)
            elif index%3==1:
                Q[:,:2]*=rng.uniform(.2,1.2);Q[:,1]+=rng.normal(0,.3,K)
            else:
                Q[:,:2]=0;Q[:,0]=rng.normal(0,.15,K)
            Q[0,0]=0
            Q[:,3]=rng.choice([0.,.1,.4,1.,2.],size=K)
            Q[:,2]*=rng.uniform(.55,1.1,size=K)
            starts.append((Q,f'random-geometry-{index}'))
    else:
        for index in range(min(nrandom,6)):
            Q=P.copy();Q[:,0]+=rng.normal(0,.03,K);Q[0,0]=0
            Q[:,1]+=rng.normal(0,.1,K);Q[:,2]*=np.exp(rng.normal(0,.08,K))
            starts.append((Q,f'affine-geometry-{index}'))
    return starts

# A fully logarithmic pair recursion retains tiny, currently unlikely paths that
# can become relevant after a later hard-support change.
from numba import njit
from branches import pair_potentials

@njit(cache=True)
def logsumvec(x):
    mx=np.max(x)
    if not np.isfinite(mx):return -np.inf
    return mx+np.log(np.exp(x-mx).sum())

@njit(cache=True)
def log_forward(L):
    n1,K,_=L.shape;alpha=np.full((n1+1,K),-np.inf);alpha[0,0]=0.
    for i in range(n1):
        for j in range(K):alpha[i+1,j]=logsumvec(alpha[i]+L[i,:,j])
    return logsumvec(alpha[-1]),alpha

@njit(cache=True)
def log_backward_gradient(L,alpha,ll,w,s,dw,ds,t):
    n,K=w.shape;beta=np.zeros(K);g=np.zeros((K,4))
    for i in range(n-2,-1,-1):
        nextbeta=np.full(K,-np.inf);dt=t[i+1]-t[i]
        for k in range(K):
            nextbeta[k]=logsumvec(L[i,k]+beta)
            for j in range(K):
                xi=np.exp(alpha[i,k]+L[i,k,j]+beta[j]-ll)
                delta=w[i+1,j]-w[i,k]
                for q in range(4):
                    g[j,q]+=xi*(-delta/dt*dw[i+1,j,q]-ds[i+1,j,q]/s[i+1,j])
                    g[k,q]+=xi*(delta/dt*dw[i,k,q])
        beta=nextbeta
    return g

@njit(cache=True)
def log_evaluate(P,y,t,rv,kappa,hard=True,gradient=True):
    w,s,dw,ds=inversion(y,t,P);L,dq=pair_potentials(w,s,t,rv,kappa,hard)
    ll,alpha=log_forward(L)
    if not np.isfinite(ll):return ll,np.zeros(P.shape)
    if gradient:return ll,log_backward_gradient(L,alpha,ll,w,s,dw,ds,t)
    return ll,np.zeros(P.shape)

def log_profile(P,y,t,rv,hard=True):
    w,s,_,_=inversion(y,t,P);scores=[]
    for kappa in KAPPAS:
        L,_=pair_potentials(w,s,t,rv,kappa,hard);scores.append(log_forward(L)[0])
    a=int(np.argmax(scores));return float(scores[a]),float(KAPPAS[a]),np.array(scores)

# Same symbolic likelihood as v1, evaluated with a stable recursion.
evaluate=log_evaluate
profile=log_profile
