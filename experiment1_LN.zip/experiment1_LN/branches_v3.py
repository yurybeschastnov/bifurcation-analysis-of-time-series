"""Further numerical audit of the preprint's unchanged local path-score.

For every fixed K we optimize continuous parameters at EACH of the fourteen
kappa values, not only alternate a local fit with a grid scan at fixed parameters.
All starts below are earlier observation-only fits. No truth or validation scores
are imported. This remains a finite multistart search, not a global certificate.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize
from branches import make_bounds, KAPPAS
from branches_v2 import log_evaluate, log_profile
from stable_inference import finalize_stable


def refine_fixed(P, y, t, rv, family, kappa, maxiter=350):
    """One fixed-kappa fit, preserving the best admissible point evaluated."""
    P=np.array(P,dtype=float,copy=True); K=len(P)
    bounds=make_bounds(K,family)
    lo=np.array([v[0] for v in bounds]); hi=np.array([v[1] for v in bounds])
    scales=np.tile([.15,.3,.5,1.5],K)
    start=np.clip(P.ravel(),lo,hi)/scales
    baseline=log_evaluate((start*scales).reshape(K,4),y,t,rv,kappa,True,False)[0]
    if not np.isfinite(baseline):
        return None
    record=[float(baseline),(start*scales).reshape(K,4).copy()]
    def objective(x):
        Q=(x*scales).reshape(K,4)
        ll,g=log_evaluate(Q,y,t,rv,kappa,True,True)
        if not np.isfinite(ll):return np.inf,np.zeros_like(x)
        if ll>record[0]:record[:]=[float(ll),Q.copy()]
        return -ll/len(y),-g.ravel()*scales/len(y)
    result=minimize(objective,start,jac=True,method='L-BFGS-B',
                    bounds=list(zip(lo/scales,hi/scales)),
                    options={'maxiter':maxiter,'maxls':80,'maxcor':20,
                             'ftol':2e-14,'gtol':2e-7})
    return dict(P=record[1],ll=record[0],kappa=float(kappa),
                optimizer=[dict(success=bool(result.success),iterations=int(result.nit),
                                evaluations=int(result.nfev),message=str(result.message))])


def audit_profile(starts,t,y,rv,mask,family,maxiter=350):
    """Uniform fixed grid, no change to the score, constraints, or masking."""
    tk=t[mask];yk=y[mask];rk=rv[mask];candidates=[];trace=[]
    for origin,old in starts:
        if old is None:continue
        frozen=finalize_stable(old,t,y,rv,mask,family,exclude_impossible=False)
        if frozen is not None and frozen['QV_valid']:candidates.append(frozen)
        for kap in KAPPAS:
            fit=refine_fixed(old['P'],yk,tk,rk,family,kap,maxiter)
            if fit is None:
                trace.append(dict(start=origin,kappa=float(kap),status='inadmissible start'))
                continue
            fixed_score=fit['ll']
            fit['ll'],fit['kappa'],_=log_profile(fit['P'],yk,tk,rk)
            fit['source']=f'v3-full-kappa-grid/{origin}/{kap:g}'
            out=finalize_stable(fit,t,y,rv,mask,family,exclude_impossible=False)
            trace.append(dict(start=origin,kappa=float(kap),fixed_ll=fixed_score,
                              profiled_ll=fit['ll'],profiled_kappa=fit['kappa'],
                              QV_valid=False if out is None else out['QV_valid'],
                              optimizer=fit['optimizer'],P=fit['P']))
            if out is not None and out['QV_valid']:candidates.append(out)
    if not candidates:raise RuntimeError('No admissible fitted candidate')
    return max(candidates,key=lambda m:m['ll']),trace
