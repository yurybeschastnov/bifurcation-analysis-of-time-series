"""Deterministic rank-based censoring of the two empirical RV tails.

The paper requires about 2.5% removed (rounding at n=2500 gives 62 or 63).
Threshold comparisons alone remove too few points when rolling-window RV has
identical values near an edge. Stable time-order tie breaking uses NO labels.
The initial point is retained as a conditioning anchor, without its own density.
"""
import numpy as np


def ranked_mask(rv,lower=.02,upper=.005,keep_anchor=True):
    rv=np.asarray(rv,float)
    if rv.ndim!=1 or len(rv)<3 or not np.isfinite(rv).all():raise ValueError('Invalid RV')
    if lower<0 or upper<0 or lower+upper>=1:raise ValueError('Invalid tail fractions')
    n=len(rv);nlo=int(np.floor(lower*n));nhi=int(np.ceil(upper*n))
    order=np.argsort(rv,kind='stable');mask=np.ones(n,bool)
    if nlo:mask[order[:nlo]]=False
    if nhi:mask[order[-nhi:]]=False
    if keep_anchor:mask[0]=True
    return mask
