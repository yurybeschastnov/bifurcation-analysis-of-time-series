from pathlib import Path
import json
import numpy as np
from scipy.optimize import linear_sum_assignment
from sklearn.metrics import adjusted_rand_score
ROOT=Path(__file__).resolve().parent

def prepare(t,y):
 t=np.asarray(t,float);y=np.asarray(y,float)
 if len(t)!=len(y) or len(y)<3 or np.any(np.diff(t)<=0) or not np.all(np.isfinite(y)):raise ValueError('Invalid observations')
 T=t[-1]-t[0];scale=np.sqrt(np.sum(np.diff(y)**2))
 if scale<=0:raise ValueError('Zero QV')
 return (t-t[0])/T,(y-y[0])/scale,T,scale

def local_rv(y,t,window=40):
 v=np.diff(y)**2/np.diff(t);n=len(v);i=np.arange(n);lo=np.maximum(0,i-window//2);hi=np.minimum(n,lo+window);lo=np.maximum(0,hi-window)
 cs=np.r_[0.,np.cumsum(v)];rv=np.sqrt(np.maximum((cs[hi]-cs[lo])/(hi-lo),1e-14));return np.r_[rv[0],rv]
def censor_mask(rv):
 lo,hi=np.quantile(rv,[.02,.995]);return (rv>=lo)&(rv<=hi)
def nearest_indices(t,tkeep):
 j=np.searchsorted(tkeep,t);a=np.clip(j-1,0,len(tkeep)-1);b=np.clip(j,0,len(tkeep)-1);return np.where(abs(t-tkeep[a])<=abs(t-tkeep[b]),a,b)
def metrics(ztrue,zhat,strue,shat):
 ztrue=np.asarray(ztrue);zhat=np.asarray(zhat);strue=np.asarray(strue);shat=np.asarray(shat)
 ans={'EL2':float(np.linalg.norm(shat-strue)/np.linalg.norm(strue)),'Elog':float(np.sqrt(np.mean(np.log(np.maximum(shat,1e-300)/strue)**2)))}
 if zhat.size:
  _,u=np.unique(ztrue,return_inverse=True);_,v=np.unique(zhat,return_inverse=True);C=np.zeros((u.max()+1,v.max()+1),int);np.add.at(C,(u,v),1);a,b=linear_sum_assignment(-C)
  ans.update(ARI=float(adjusted_rand_score(u,v)),ACC=float(C[a,b].sum()/len(u)),purity=float(C.max(axis=0).sum()/len(u)),K_occupied=int(v.max()+1))
 return ans

def dumps(obj):
 def cv(x):
  if isinstance(x,np.ndarray):return x.tolist()
  if isinstance(x,np.generic):return x.item()
  raise TypeError(str(type(x)))
 return json.dumps(obj,indent=2,default=cv,ensure_ascii=False,allow_nan=True)
