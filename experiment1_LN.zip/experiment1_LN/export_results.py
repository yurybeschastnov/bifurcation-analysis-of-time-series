"""Portable NPZ predictions and secondary sensitivity audits.
Only trusted, locally generated pickle files should be loaded by this project.
"""
import json
import pickle
import hashlib
import platform
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests
from common import ROOT, prepare, dumps


def main():
    destination = ROOT / 'predictions'
    destination.mkdir(exist_ok=True)
    sensitivity = []
    occupancy = []
    generation = json.loads((ROOT/'truth'/'generation_audit.json').read_text())
    for g in generation:
        row = dict(series=g['series'], K=g['K'], attempts=g['attempts'],
                   switches=g['switches'], QV_true_driver=g['QV_W'],
                   max_balance_error=g['max_balance_error'],
                   seed_entropy=str(g['seed_entropy']))
        for j, (a, b) in enumerate(zip(g['occupancy_time'], g['occupancy_points'])):
            row[f'occupancy_time_{j}'] = a
            row[f'occupancy_observations_{j}'] = b
        occupancy.append(row)
    pd.DataFrame(occupancy).to_csv(ROOT/'results'/'balance_audit.csv', index=False)
    for path in sorted((ROOT/'data').glob('*.npz')):
        name = path.stem
        f = np.load(path)
        truth = np.load(ROOT/'truth'/f'{name}.npz')
        t, y, T, scale = prepare(f['t'], f['y'])
        with (ROOT/'results'/f'{name}_branches.pkl').open('rb') as handle:
            b = pickle.load(handle)
        with (ROOT/'results'/f'{name}_baselines.pkl').open('rb') as handle:
            models = pickle.load(handle)
        models = {'Branches': b['selected'], **models}
        mssv = ROOT/'results'/f'{name}_mssv.pkl'
        if mssv.exists():
            with mssv.open('rb') as handle:
                models['MSSV'] = pickle.load(handle)['selected']
        arrays = dict(t_original=f['t'], y_original=f['y'], t_normalized=t,
                      y_normalized=y, true_labels=truth['z'], true_sigma_original=truth['sigma'],
                      true_driver_original=truth['w'], branch_retained_mask=b['mask'])
        for method, m in models.items():
            arrays[f'{method}_labels'] = m['labels']
            arrays[f'{method}_sigma_original'] = m['volatility']*scale/np.sqrt(T)
            arrays[f'{method}_K'] = np.array(-1 if m['K'] is None else m['K'])
        arrays['Branches_parameters_original_c_a_b_r'] = np.column_stack([
            scale*b['selected']['P'][:, 0]+f['y'][0],
            scale*b['selected']['P'][:, 1]/T,
            scale*b['selected']['P'][:, 2]/np.sqrt(T),
            scale*b['selected']['P'][:, 3]/(3*T**1.5)])
        np.savez_compressed(destination/f'{name}.npz', **arrays)
        with (ROOT/'results'/f'{name}_hmm.pkl').open('rb') as handle:
            hmms = pickle.load(handle)
        n = len(hmms[0]['labels'])
        for criterion, penalty in [('BIC', np.log(n)), ('AIC', 2.), ('ICL', np.log(n))]:
            strict = min(hmms, key=lambda m:m[criterion])
            legacy = min(hmms, key=lambda m:m[criterion]-m['K']*penalty)
            sensitivity.append(dict(series=name, criterion=criterion,
                K_full_parameter_count=strict['K'], K_legacy_count=legacy['K'],
                changed=strict['K'] != legacy['K']))
    pd.DataFrame(sensitivity).to_csv(ROOT/'results'/'hmm_parameter_count_sensitivity.csv', index=False)
    d = pd.read_csv(ROOT/'results'/'driver_diagnostics_all_models.csv')
    d = d[d.selected].copy()
    p = np.r_[d.Ljung_Box_p.to_numpy(), d.Ljung_Box_squared_p.to_numpy()]
    corrected = multipletests(p, method='holm')[1]
    d['Ljung_Box_p_Holm_26'] = corrected[:len(d)]
    d['Ljung_Box_squared_p_Holm_26'] = corrected[len(d):]
    d.to_csv(ROOT/'results'/'driver_diagnostics_selected.csv', index=False)
    # Record observed environment, not a claim of cross-platform bitwise identity.
    import scipy, numba, sklearn, matplotlib, statsmodels, pytest
    environment = dict(python=sys.version, platform=platform.platform(),
        versions={m.__name__:m.__version__ for m in [np, scipy, numba, sklearn, pd, matplotlib, statsmodels, pytest]})
    (ROOT/'results'/'environment.json').write_text(dumps(environment))
    hashes = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(destination.glob('*.npz'))}
    (destination/'sha256.json').write_text(dumps(hashes))
    print('Exported', len(hashes), 'portable prediction files and audits.')


if __name__ == '__main__':
    main()
