"""Independent generator, Table 4 in the supplied preprint. No repository used.
Ground truth is confined to this module and truth/. Estimators see data/ only.
"""
from pathlib import Path
import json,hashlib,time
import numpy as np
from numba import njit
ROOT=Path(__file__).resolve().parent
CONFIGS={
'L1':[(0,.10,.90,0)],
'L2':[(0,.05,.50,0),(.30,-.40,1.10,0)],
'L3':[(0,.05,.40,0),(.20,-.35,.80,0),(-.16,-.11,1.20,0)],
'L4':[(0,.05,.70,0),(.25,-.30,.95,0)],
'L5':[(0,.05,.35,0),(.18,-.30,.75,0),(-.12,.10,1.30,0)],
'L6':[(0,.05,.30,0),(.12,-.20,.65,0),(-.10,.15,1.05,0),(.22,-.35,1.55,0)],
'N1':[(0,.05,.50,.20),(.30,-.25,1.10,.02)],
'N2':[(0,.05,.45,.25),(.22,-.20,.85,.05),(-.18,.10,1.25,.12)],
'N3':[(0,.05,.35,.45),(.25,-.20,1.15,.03)],
'N4':[(0,.05,.30,.50),(.20,-.25,.80,.20),(-.15,.10,1.40,.02)],
'N5':[(0,.05,.30,.55),(.28,-.25,.95,.15)],
'N6':[(0,.05,.55,0),(.30,-.25,.40,.60)],
'N7':[(0,.05,.35,0),(.20,-.22,.80,0),(-.15,.12,.60,.55)]}
PROTOCOL=dict(master_seed=20260910,n_observations=2500,fine_steps=50000,stride=20,
 observation_grid='t_i=i/2500, i=0,...,2499; observed T=0.9996',initial_regime=0,
 switch_probability=.5,refractory_time=.02,balance_abs_tolerance=.025,max_proposals=200000,
 acceptance='first whole proposal balanced on both exact event-time occupancy and observation grid',
 no_time_warp=True,no_off_intersection_switch=True,no_metric_based_acceptance=True,
 estimator_Kmax=6,known_family=True,true_K_supplied=False,local_RV_window=40,
 censor_lower=.02,censor_upper=.005,kappa_grid=list(np.arange(2.5,9.01,.5)),
 branch_BIC='-2 logZ + p*K*log(n_kept), p=3 affine,4 cubic; paper formula (21)',
 missing_settings_chosen='refractory duration, balance rule, seeds, initialization, optimization tolerances',
 scope='One independent realization of each of the 13 Table-4 configurations; not author seeds or repeated-run table.')
@njit(cache=True)
def branch(p,w,t):return p[0]+p[1]*t+p[2]*w+p[3]*w*w*w
@njit(cache=True)
def simulate_given_noise(params,W,U,refractory=.02):
 m=len(W)-1;K=len(params);dt=1./m;z=np.zeros(m+1,np.int64)
 times=np.empty(m);ws=np.empty(m);src=np.empty(m,np.int64);dst=np.empty(m,np.int64)
 st=0;allowed_at=0.;ne=0;ct=np.empty(K);cj=np.empty(K,np.int64)
 for i in range(1,m+1):
  t0=(i-1)*dt;t1=i*dt
  if K>1 and t1>allowed_at:
   l0=max(0.,(allowed_at-t0)/dt);w0=W[i-1]+l0*(W[i]-W[i-1]);tl=t0+l0*dt;ns=0
   for k in range(K):
    if k==st:continue
    f0=branch(params[st],w0,tl)-branch(params[k],w0,tl)
    f1=branch(params[st],W[i],t1)-branch(params[k],W[i],t1)
    if f0*f1<0.:
     lo=l0;hi=1.;flo=f0
     for _ in range(40):
      mid=.5*(lo+hi);wm=W[i-1]+mid*(W[i]-W[i-1]);tm=t0+mid*dt
      fm=branch(params[st],wm,tm)-branch(params[k],wm,tm)
      if flo*fm<=0:hi=mid
      else:lo=mid;flo=fm
     ct[ns]=t0+.5*(lo+hi)*dt;cj[ns]=k;ns+=1
   for a in range(ns):
    best=a
    for b in range(a+1,ns):
     if ct[b]<ct[best]:best=b
    tmp=ct[a];ct[a]=ct[best];ct[best]=tmp;itmp=cj[a];cj[a]=cj[best];cj[best]=itmp
    if U[i-1,cj[a]]<.5:
     te=ct[a];we=W[i-1]+(te-t0)/dt*(W[i]-W[i-1])
     times[ne]=te;ws[ne]=we;src[ne]=st;dst[ne]=cj[a];ne+=1
     st=cj[a];allowed_at=te+refractory;break
  z[i]=st
 return z,times[:ne],ws[:ne],src[:ne],dst[:ne]
def occupancy_events(K,times,dest,T):
 occ=np.zeros(K);last=0.;state=0
 for te,sd in zip(times,dest):
  if te>=T:break
  occ[state]+=te-last;last=te;state=int(sd)
 occ[state]+=T-last
 return occ/T
def generate_all():
 for sub in ['data','truth','results','logs']:(ROOT/sub).mkdir(exist_ok=True)
 (ROOT/'protocol.json').write_text(json.dumps(PROTOCOL,indent=2))
 (ROOT/'truth'/'configurations.json').write_text(json.dumps(CONFIGS,indent=2));audit=[]
 for cindex,(name,vals) in enumerate(CONFIGS.items()):
  p=np.array(vals,float);K=len(p);start=time.perf_counter()
  for attempt in range(PROTOCOL['max_proposals']):
   rng=np.random.default_rng(np.random.SeedSequence([PROTOCOL['master_seed'],cindex,attempt]))
   W=np.r_[0.,np.cumsum(rng.normal(size=50000))/np.sqrt(50000.)];U=rng.random((50000,K))
   z,te,we,src,dst=simulate_given_noise(p,W,U,PROTOCOL['refractory_time'])
   inds=np.arange(0,50000,20);t=inds/50000.;wo=W[inds];zo=z[inds]
   occ=occupancy_events(K,te,dst,t[-1]);occn=np.bincount(zo,minlength=K)/len(zo)
   if max(np.max(abs(occ-1/K)),np.max(abs(occn-1/K)))>PROTOCOL['balance_abs_tolerance']:continue
   Y=p[zo,0]+p[zo,1]*t+p[zo,2]*wo+p[zo,3]*wo**3;sig=p[zo,2]+3*p[zo,3]*wo**2
   np.savez_compressed(ROOT/'data'/f'{name}.npz',t=t,y=Y,family='affine' if name[0]=='L' else 'cubic')
   np.savez_compressed(ROOT/'truth'/f'{name}.npz',t=t,y=Y,w=wo,z=zo,sigma=sig,parameters=p,event_t=te,event_w=we,event_from=src,event_to=dst)
   er=max([abs(branch(p[int(s)],w,tt)-branch(p[int(d)],w,tt)) for tt,w,s,d in zip(te,we,src,dst)],default=0.)
   row=dict(series=name,K=K,attempts=attempt+1,seed_entropy=[PROTOCOL['master_seed'],cindex,attempt],
    occupancy_time=occ.tolist(),occupancy_points=occn.tolist(),max_balance_error=float(max(abs(occ-1/K))),
    switches=int(np.sum(te<t[-1])),observed_switches=int(np.count_nonzero(np.diff(zo))),QV_W=float(np.sum(np.diff(wo)**2)/t[-1]),
    intersection_residual=float(er),sigma_min=float(sig.min()),sigma_max=float(sig.max()),generation_seconds=time.perf_counter()-start,
    data_sha256=hashlib.sha256((ROOT/'data'/f'{name}.npz').read_bytes()).hexdigest())
   audit.append(row);(ROOT/'truth'/'generation_audit.json').write_text(json.dumps(audit,indent=2))
   print(name,'attempt',attempt+1,'occupancy',np.round(occ,4),'switches',row['switches'],flush=True);break
  else:raise RuntimeError(f'No balanced {name}; tolerance was not relaxed.')
 return audit
if __name__=='__main__':generate_all()
