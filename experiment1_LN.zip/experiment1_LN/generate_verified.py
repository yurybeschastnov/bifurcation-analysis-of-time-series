"""Rebuild the thirteen accepted paths from recorded seeds with all-root detection.

No observations are replaced by default. This verifies the approved realization,
not a fresh search through new seeds. Optional --output writes a standalone copy.
"""
from __future__ import annotations
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from common import ROOT,dumps
from geometry_audit import simulate_all_roots_given_noise
from generate import occupancy_events


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path);a=p.parse_args()
    records=json.loads((ROOT/'truth/generation_audit.json').read_text());config=json.loads((ROOT/'truth/configurations.json').read_text());checks=[]
    if a.output:
        (a.output/'data').mkdir(parents=True,exist_ok=True);(a.output/'truth').mkdir(parents=True,exist_ok=True)
    for row in records:
        name=row['series'];P=np.array(config[name],float);K=len(P)
        rng=np.random.default_rng(np.random.SeedSequence(row['seed_entropy']))
        W=np.r_[0.,np.cumsum(rng.normal(size=50000))/np.sqrt(50000.)]
        U=np.empty((50000,K,3));U[:,:,0]=rng.random((50000,K));U[:,:,1:]=rng.random((50000,K,2))
        z,te,we,src,dst=simulate_all_roots_given_noise(P,W,U,.02)
        ids=np.arange(0,50000,20);t=ids/50000.;wo=W[ids];zo=z[ids]
        y=P[zo,0]+P[zo,1]*t+P[zo,2]*wo+P[zo,3]*wo**3;s=P[zo,2]+3*P[zo,3]*wo**2
        obs=np.load(ROOT/'data'/f'{name}.npz',allow_pickle=False);truth=np.load(ROOT/'truth'/f'{name}.npz',allow_pickle=False)
        assert np.array_equal(t,obs['t']) and np.allclose(y,obs['y'],rtol=0,atol=1e-13)
        assert np.array_equal(zo,truth['z'])
        assert len(te)==len(truth['event_t']) and np.allclose(te,truth['event_t'],rtol=0,atol=1e-12)
        occ=occupancy_events(K,te,dst,t[-1]);pocc=np.bincount(zo,minlength=K)/len(zo)
        assert np.max(abs(occ-1/K))<=.025 and np.max(abs(pocc-1/K))<=.025
        residual=[]
        for tm,wm,j,k in zip(te,we,src,dst):
            delta=P[j]-P[k];residual.append(abs(delta[0]+delta[1]*tm+delta[2]*wm+delta[3]*wm**3))
        checks.append(dict(series=name,seed=row['seed_entropy'],labels_equal=True,max_observation_error=float(abs(y-obs['y']).max()),max_event_residual=max(residual,default=0.),balance_time=occ,balance_points=pocc))
        if a.output:
            np.savez_compressed(a.output/'data'/f'{name}.npz',t=t,y=y,family=str(obs['family']))
            np.savez_compressed(a.output/'truth'/f'{name}.npz',t=t,y=y,w=wo,z=zo,sigma=s,parameters=P,event_t=te,event_w=we,event_from=src,event_to=dst)
    (ROOT/'revision3'/'verified_generator.json').write_text(dumps(checks),encoding='utf-8')
    print('Verified complete-root replay of',len(checks),'balanced realizations')
if __name__=='__main__':main()
