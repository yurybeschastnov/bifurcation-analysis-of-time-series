"""Geometry checks distinct from the §2.3 likelihood.
P=(c,a,b,d=3r) for fitting; generator parameters are (c,a,b,r).
A straight-chord hit is NOT a necessary condition for a Brownian-bridge hit.
Accordingly chord_crosses is a diagnostic, never silently imposed in main fits.
"""
import numpy as np
from numba import njit

@njit(cache=True)
def cubic_value(coef,x):
    return coef[0]+x*(coef[1]+x*(coef[2]+x*coef[3]))

@njit(cache=True)
def interval_roots(coef,lo=0.,hi=1.):
    """All isolated real roots in [lo,hi], including tangencies and endpoints.
    Partition the cubic at derivative roots, then bisect each monotone piece.
    An identically zero polynomial is represented by the left endpoint.
    """
    scale=np.max(np.abs(coef));roots=np.empty(3);nr=0
    if scale==0:roots[0]=lo;return roots[:1]
    tol=64*np.finfo(np.float64).eps*scale
    points=np.empty(4);points[0]=lo;npoints=1
    a=3*coef[3];b=2*coef[2];c=coef[1]
    if abs(a)>tol:
        disc=b*b-4*a*c
        if disc>=0:
            sq=np.sqrt(disc)
            u=(-b-sq)/(2*a);v=(-b+sq)/(2*a)
            if lo<u<hi:points[npoints]=u;npoints+=1
            if lo<v<hi and abs(v-u)>1e-13:points[npoints]=v;npoints+=1
    elif abs(b)>tol:
        u=-c/b
        if lo<u<hi:points[npoints]=u;npoints+=1
    points[npoints]=hi;npoints+=1
    points[:npoints]=np.sort(points[:npoints])
    for k in range(npoints):
        x=points[k];fx=cubic_value(coef,x)
        if abs(fx)<=tol:
            if nr==0 or abs(x-roots[nr-1])>1e-10:
                if nr<3:roots[nr]=x;nr+=1
        if k==npoints-1:continue
        xx=points[k+1];ff=cubic_value(coef,xx)
        if fx*ff<0 and abs(fx)>tol and abs(ff)>tol:
            left=x;right=xx;fl=fx
            for _ in range(48):
                mid=(left+right)/2;fm=cubic_value(coef,mid)
                if fl*fm<=0:right=mid
                else:left=mid;fl=fm
            root=(left+right)/2
            if nr==0 or abs(root-roots[nr-1])>1e-10:
                if nr<3:roots[nr]=root;nr+=1
    return roots[:nr]

@njit(cache=True)
def chord_coefficients(p,q,w0,w1,t0,t1):
    dc=p[0]-q[0];da=p[1]-q[1];db=p[2]-q[2];dr=p[3]-q[3]
    dw=w1-w0;dt=t1-t0
    return np.array([dc+da*t0+db*w0+dr*w0**3,
                     da*dt+db*dw+3*dr*w0*w0*dw,
                     3*dr*w0*dw*dw,dr*dw**3])

@njit(cache=True)
def simulate_all_roots_given_noise(params,W,U,refractory=.02):
    """Audit replacement for v1's endpoint-sign-only event detector.
    On a fine cell shorter than refractory, at most one accepted switch occurs.
    U may have shape (steps,K,3): independent uniforms for up to 3 roots.
    """
    m=len(W)-1;K=len(params);dt=1./m
    if dt>=refractory and K>1:
        raise ValueError('Fine cell must be shorter than the refractory period')
    z=np.zeros(m+1,np.int64);times=np.empty(m);ws=np.empty(m)
    src=np.empty(m,np.int64);dst=np.empty(m,np.int64)
    state=0;allowed_at=0.;ne=0;cts=np.empty(3*K);cjs=np.empty(3*K,np.int64);crs=np.empty(3*K,np.int64)
    for i in range(1,m+1):
        t0=(i-1)*dt;t1=i*dt
        if K>1 and t1>allowed_at:
            lower=max(0.,(allowed_at-t0)/dt);nc=0
            for j in range(K):
                if j==state:continue
                coef=chord_coefficients(params[state],params[j],W[i-1],W[i],t0,t1)
                roots=interval_roots(coef,lower,1.)
                for rindex,root in enumerate(roots):
                    if root==0 and i>1:continue  # endpoint was already visited
                    cts[nc]=t0+root*dt;cjs[nc]=j;crs[nc]=rindex;nc+=1
            for a in range(nc):
                best=a
                for b in range(a+1,nc):
                    if cts[b]<cts[best]:best=b
                cts[a],cts[best]=cts[best],cts[a];cjs[a],cjs[best]=cjs[best],cjs[a];crs[a],crs[best]=crs[best],crs[a]
                if U[i-1,cjs[a],crs[a]]<.5:
                    te=cts[a];we=W[i-1]+(te-t0)/dt*(W[i]-W[i-1])
                    times[ne]=te;ws[ne]=we;src[ne]=state;dst[ne]=cjs[a];ne+=1
                    state=cjs[a];allowed_at=te+refractory;break
        z[i]=state
    return z,times[:ne],ws[:ne],src[:ne],dst[:ne]


def switch_chord_diagnostics(params,w,t,z):
    changes=np.flatnonzero(z[1:]!=z[:-1])+1;rows=[]
    for i in changes:
        k=int(z[i-1]);j=int(z[i]);coef=chord_coefficients(params[k],params[j],w[i-1],w[i],t[i-1],t[i])
        roots=interval_roots(coef)
        rows.append(dict(index=int(i),source=k,destination=j,time0=float(t[i-1]),time1=float(t[i]),
                         straight_chord_has_intersection=bool(len(roots)),
                         endpoint_gap_before=float(coef[0]),endpoint_gap_after=float(cubic_value(coef,1.))))
    return rows

if __name__=='__main__':
    import json,pickle,hashlib
    from pathlib import Path
    from common import ROOT,prepare,local_rv,dumps
    from branches import inversion,pair_potentials,profile
    from generate import simulate_given_noise
    out=ROOT/'revision2';out.mkdir(exist_ok=True);rows=[];detail={}
    for item in json.loads((ROOT/'truth/generation_audit.json').read_text()):
        name=item['series'];truth=np.load(ROOT/'truth'/f'{name}.npz');params=truth['parameters'];K=len(params)
        rng=np.random.default_rng(np.random.SeedSequence(item['seed_entropy']))
        W=np.r_[0.,np.cumsum(rng.normal(size=50000))/np.sqrt(50000.)]
        first=rng.random((50000,K));U=np.empty((50000,K,3));U[:,:,0]=first;U[:,:,1:]=rng.random((50000,K,2))
        new=simulate_all_roots_given_noise(params,W,U)
        original=simulate_given_noise(params,W,first)
        a=switch_chord_diagnostics(params,truth['w'],truth['t'],truth['z'])
        prior=pickle.load(open(ROOT/'results'/f'{name}_branches.pkl','rb'));m=prior['selected']
        f=np.load(ROOT/'data'/f'{name}.npz');t,y,T,scale=prepare(f['t'],f['y']);mask=prior['mask']
        P=m['P'].copy();P[:,3]/=3
        b=switch_chord_diagnostics(P,m['retained_driver'],t[mask],m['labels'][mask])
        rows.append(dict(series=name,fine_labels_identical=bool(np.array_equal(new[0],original[0])),
                         fine_events_identical=bool(len(new[1])==len(original[1]) and np.max(np.abs(new[1]-original[1]),initial=0)<1e-12),
                         true_observed_switches=len(a),true_switches_without_chord_hit=sum(not r['straight_chord_has_intersection'] for r in a),
                         old_decoded_switches=len(b),old_decoded_switches_without_chord_hit=sum(not r['straight_chord_has_intersection'] for r in b),
                         max_event_residual=item['intersection_residual']))
        detail[name]=dict(true_observation_chords=a,old_fitted_retained_chords=b)
        print(rows[-1],flush=True)
    P=np.array([[0.,0.,1.,0.],[.01,0.,1.,0.]])
    t=np.array([0.,.001]);y=np.array([0.,.01]);w,s,_,_=inversion(y,t,P)
    L,_=pair_potentials(w,s,t,np.ones(2),4.,True)
    counter=dict(branches='g0(w,t)=w; g1(w,t)=w+0.01',intersection_exists=False,
                 old_switch_log_weight=float(L[0,0,1]),old_switch_weight=float(np.exp(L[0,0,1])))
    (out/'geometry_audit.json').write_text(dumps(dict(rows=rows,counterexample=counter,details=detail)))
