"""Weak-limit sticky HDP-HMM. Exact CRT/diagonal-override beta update.
This corrects the noncanonical beta update explicitly acknowledged on p.105
of the preprint; it does not claim to inspect or modify the author's code.
"""
import numpy as np
from numba import njit
from hmm import fb_scaled
@njit(cache=True)
def categorical(p):
 u=np.random.random()*p.sum();s=0.
 for j in range(len(p)):
  s+=p[j]
  if u<=s:return j
 return len(p)-1
@njit(cache=True)
def dirichlet(a):
 v=np.empty(len(a))
 for i in range(len(a)):v[i]=max(np.random.gamma(max(a[i],1e-12),1.),1e-300)
 return v/v.sum()
@njit(cache=True)
def ffbs_hmm(af,A):
 n,K=af.shape;z=np.empty(n,np.int64);z[-1]=categorical(af[-1]);p=np.empty(K)
 for i in range(n-2,-1,-1):
  for k in range(K):p[k]=af[i,k]*A[k,z[i+1]]
  z[i]=categorical(p)
 return z
@njit(cache=True)
def gibbs_hdp(x,L=10,iterations=500,burn=200,seed=123):
 np.random.seed(seed);n=len(x);vx=np.var(x);alpha=3.;gamma=3.;sticky=50.;beta=np.ones(L)/L;A=np.ones((L,L))*.005/L+.995*np.eye(L)
 var=np.exp(np.linspace(-2.,1.,L))*vx;mu=np.zeros(L);z=np.random.randint(0,L,n);B=np.empty((n,L));off=np.empty(n)
 samples=np.empty((iterations-burn,n),np.int16);vols=np.empty((iterations-burn,n));ktrace=np.empty(iterations,np.int64);lltrace=np.empty(iterations)
 for it in range(iterations):
  for i in range(n):
   mx=-1e300
   for k in range(L):
    B[i,k]=-.5*(np.log(2*np.pi*var[k])+(x[i]-mu[k])**2/var[k])
    if B[i,k]>mx:mx=B[i,k]
   off[i]=mx
   for k in range(L):B[i,k]=np.exp(B[i,k]-mx)
  ll,ga,xi,af=fb_scaled(B,A,beta);lltrace[it]=ll+off.sum();z=ffbs_hmm(af,A)
  counts=np.zeros(L);sx=np.zeros(L);sxx=np.zeros(L);trans=np.zeros((L,L),np.int64)
  for i in range(n):
   k=z[i];counts[k]+=1;sx[k]+=x[i];sxx[k]+=x[i]*x[i]
   if i>0:trans[z[i-1],k]+=1
  ktrace[it]=np.sum(counts>.01*n)
  if it>=burn:
   samples[it-burn]=z
   for i in range(n):vols[it-burn,i]=np.sqrt(var[z[i]])
  for k in range(L):
   nk=counts[k];kp=.01+nk;ap=2.+.5*nk;mean=sx[k]/max(nk,1.);bp=vx+.5*(sxx[k]-sx[k]*mean)+.5*.01*nk/kp*mean*mean
   var[k]=max(bp/np.random.gamma(ap,1.),vx*1e-10);mu[k]=sx[k]/kp+np.sqrt(var[k]/kp)*np.random.normal()
  tables=np.zeros(L)
  for j in range(L):
   for k in range(L):
    conc=alpha*beta[k]+(sticky if j==k else 0.)
    for customer in range(trans[j,k]):
     if np.random.random()<conc/(conc+customer):
      if j!=k or np.random.random()<alpha*beta[k]/conc:tables[k]+=1
  tables[z[0]]+=1;beta=dirichlet(gamma/L+tables)
  for j in range(L):
   v=alpha*beta+trans[j];v[j]+=sticky;A[j]=dirichlet(v)
 return samples,vols,ktrace,lltrace

def fit_hdp(x,seed=0):
 samples,vols,ktrace,lltrace=gibbs_hdp(np.asarray(x,float),seed=seed);vals,cnt=np.unique(ktrace[200:],return_counts=True);K=int(vals[np.argmax(cnt)]);meanvol=vols.mean(axis=0)
 eligible=np.flatnonzero(ktrace[200:]==K);score=np.mean((vols[eligible]-meanvol)**2,axis=1);idx=int(eligible[np.argmin(score)])
 return dict(K=K,labels=samples[idx].astype(int),volatility=meanvol,K_trace=ktrace,ll_trace=lltrace,representative_draw=idx,
  posterior_mode_frequency=float(np.max(cnt)/300),description='weak-limit HDP, CRT beta; 500/200 one chain, mixing not guaranteed')
