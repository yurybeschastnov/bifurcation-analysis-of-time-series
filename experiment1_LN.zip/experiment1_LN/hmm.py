"""Independent float64 Gaussian / mixture HMM. Exact scaled forward-backward.
Restarts are selected by likelihood, never by external validation labels.
"""
import numpy as np
from numba import njit
@njit(cache=True)
def fb_scaled(B,A,pi):
 n,K=B.shape;af=np.empty((n,K));sc=np.empty(n);af[0]=pi*B[0];sc[0]=max(af[0].sum(),1e-300);af[0]/=sc[0]
 for i in range(1,n):
  for j in range(K):
   v=0.
   for k in range(K):v+=af[i-1,k]*A[k,j]
   af[i,j]=v*B[i,j]
  sc[i]=max(af[i].sum(),1e-300);af[i]/=sc[i]
 be=np.ones((n,K));xi=np.zeros((K,K))
 for i in range(n-2,-1,-1):
  for k in range(K):
   v=0.
   for j in range(K):
    w=A[k,j]*B[i+1,j]*be[i+1,j]/sc[i+1];v+=w;xi[k,j]+=af[i,k]*w
   be[i,k]=v
 ga=af*be
 for i in range(n):ga[i]/=max(ga[i].sum(),1e-300)
 return np.log(sc).sum(),ga,xi,af
@njit(cache=True)
def viterbi(logB,A,pi):
 n,K=logB.shape;d=np.empty((n,K));ptr=np.zeros((n,K),np.int64);d[0]=np.log(pi+1e-300)+logB[0]
 for i in range(1,n):
  for j in range(K):
   best=-1e300;arg=0
   for k in range(K):
    z=d[i-1,k]+np.log(A[k,j]+1e-300)
    if z>best:best=z;arg=k
   d[i,j]=best+logB[i,j];ptr[i,j]=arg
 z=np.empty(n,np.int64);z[-1]=np.argmax(d[-1])
 for i in range(n-2,-1,-1):z[i]=ptr[i+1,z[i+1]]
 return z,float(np.max(d[-1]))
@njit(cache=True)
def emissions(x,mu,var,weights):
 n=len(x);K,M=mu.shape;raw=np.empty((n,K,M));lb=np.empty((n,K));off=np.empty(n)
 for i in range(n):
  for k in range(K):
   best=-1e300
   for m in range(M):
    r=-.5*(np.log(2*np.pi*var[k,m])+(x[i]-mu[k,m])**2/var[k,m])+np.log(weights[k,m]+1e-300);raw[i,k,m]=r
    if r>best:best=r
   s=0.
   for m in range(M):s+=np.exp(raw[i,k,m]-best)
   lb[i,k]=best+np.log(s)
  off[i]=np.max(lb[i])
 return raw,lb,off
@njit(cache=True)
def em_fit(x,mu,var,weights,A,pi,maxiter=400,tol=1e-7):
 n=len(x);K,M=mu.shape;floor=max(np.var(x)*1e-6,1e-10);prev=-1e300;hist=np.empty(maxiter)
 for it in range(maxiter):
  raw,lb,off=emissions(x,mu,var,weights);B=np.exp(lb-off.reshape((n,1)));ll,ga,xi,af=fb_scaled(B,A,pi);ll+=off.sum();hist[it]=ll
  if it>0 and ll-prev<tol*(1+abs(ll)) and ll-prev>-1e-5:break
  if it==maxiter-1:break
  prev=ll;A=xi+1e-10
  for k in range(K):A[k]/=A[k].sum()
  pi=ga[0]+1e-10;pi/=pi.sum()
  for k in range(K):
   counts=np.zeros(M)
   for m in range(M):
    count=0.;sx=0.;sxx=0.
    for i in range(n):
     w=ga[i,k]*np.exp(raw[i,k,m]-lb[i,k]);count+=w;sx+=w*x[i];sxx+=w*x[i]*x[i]
    counts[m]=count
    if count>1e-6:mu[k,m]=sx/count;var[k,m]=max(sxx/count-mu[k,m]**2,floor)
   weights[k]=np.maximum(counts,1e-10);weights[k]/=weights[k].sum()
 return mu,var,weights,A,pi,ll,ga,lb,hist[:it+1]
def fit_hmm(x,K,M=1,restarts=10,seed=0,maxiter=400):
 x=np.ascontiguousarray(x,float);rng=np.random.default_rng(seed);n=len(x);sd=np.std(x);cs=np.r_[0.,np.cumsum(x*x)];ids=np.arange(n)
 rv=np.sqrt((cs[np.minimum(ids+40,n)]-cs[ids])/np.minimum(40,n-ids));levels=np.quantile(rv,(np.arange(K)+.5)/K);best=None;log=[]
 for s in range(restarts):
  lv=np.maximum(levels*(np.exp(rng.normal(0,.25,K)) if s else 1),sd*.02);mu=np.zeros((K,M));var=np.empty((K,M))
  for k in range(K):
   var[k]=lv[k]**2*np.exp(np.linspace(-.5,.5,M))
   if M>1:mu[k]=rng.normal(0,sd*.08,M)
  weights=np.ones((K,M))/M;stay=[.99,.98,.995,.95,.999][s%5];A=np.ones((K,K))*(1-stay)/K+stay*np.eye(K);pi=np.ones(K)/K
  res=em_fit(x,mu,var,weights,A,pi,maxiter)
  log.append(dict(restart=s,ll=float(res[5]),iterations=len(res[8]),minimum_LL_step=float(np.min(np.diff(res[8]))) if len(res[8])>1 else 0.))
  if best is None or res[5]>best[5]:best=res
 mu,var,weights,A,pi,ll,ga,lb,hist=best;labels,vll=viterbi(lb,A,pi);avg=(weights*mu).sum(axis=1);sig=np.sqrt((weights*(var+mu*mu)).sum(axis=1)-avg*avg)
 p=(K-1)+K*(K-1)+K*(3*M-1);ent=-np.sum(ga*np.log(np.maximum(ga,1e-300)))
 return dict(K=K,M=M,mu=mu,var=var,weights=weights,A=A,pi=pi,ll=float(ll),gamma=ga,labels=labels,sigma=sig,BIC=float(-2*ll+p*np.log(n)),AIC=float(-2*ll+2*p),ICL=float(-2*ll+p*np.log(n)+2*ent),parameters=p,restart_log=log,history=hist)
def fit_range(x,Kmax=6,M=1,restarts=10,seed=0,maxiter=400):return [fit_hmm(x,k,M,restarts,seed+1009*k,maxiter) for k in range(1,Kmax+1)]
