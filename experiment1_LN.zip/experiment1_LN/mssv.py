"""Independent switching stochastic volatility (So-Lam-Li form, preprint p.44).
KSC seven-normal approximation for log chi-square; table means MUST be shifted
by -1.2704 (Kim, Shephard & Chib 1998, equation 10/Table 4, printed p.371).
Gibbs: mixture indicators -> Gaussian FFBS h -> pair-potential FFBS z -> conjugate
mu, phi, variance, A. BIC uses an exact-observation bootstrap particle likelihood.

Explicit completion of settings missing in the preprint: mu~N(0,100), rows A~Dir(1),
z0 uniform, h0|z0~N(mu_z0,1), Kmax=4, posterior-mean parameter plug-in, log(x^2)
floor 1e-12. The mixture posterior is approximate and a single short chain is not
claimed to establish convergence. No repository or external implementation used.
"""
import numpy as np
from numba import njit
from scipy.special import logsumexp
from hdp import categorical,dirichlet
MIX_Q=np.array([.00730,.10556,.00002,.04395,.34001,.24566,.25750])
MIX_M=np.array([-10.12999,-3.97281,-8.56686,2.77786,.61942,1.79518,-1.08819])-1.2704
MIX_V=np.array([5.79596,2.61369,5.17950,.16735,.64009,.34023,1.26261])

@njit(cache=True)
def truncated_normal(mean,sd,lower=-.999,upper=.999):
 a=(lower-mean)/sd;b=(upper-mean)/sd;sgn=1.
 if b<0:a,b=-b,-a;sgn=-1.
 if a>0:
  rate=.5*(a+np.sqrt(a*a+4.))
  while True:
   z=a+np.random.exponential(1/rate)
   if z<=b and np.random.random()<=np.exp(-.5*(z-rate)**2):return mean+sd*sgn*z
 while True:
  z=np.random.normal()
  if a<=z<=b:return mean+sd*sgn*z

@njit(cache=True)
def sample_h(ylog,z,mu,phi,veta,mixture):
 n=len(z);m=np.empty(n);C=np.empty(n);pred=np.empty(n);R=np.empty(n)
 for i in range(n):
  if i==0:pred[i]=mu[z[i]];R[i]=1.
  else:pred[i]=mu[z[i]]+phi*(m[i-1]-mu[z[i-1]]);R[i]=phi*phi*C[i-1]+veta
  v=MIX_V[mixture[i]];obs=ylog[i]-MIX_M[mixture[i]];gain=R[i]/(R[i]+v)
  m[i]=pred[i]+gain*(obs-pred[i]);C[i]=max(R[i]*v/(R[i]+v),1e-14)
 h=np.empty(n);h[-1]=m[-1]+np.sqrt(C[-1])*np.random.normal()
 for i in range(n-2,-1,-1):
  J=C[i]*phi/R[i+1];mm=m[i]+J*(h[i+1]-pred[i+1]);vv=max(C[i]-J*J*R[i+1],1e-14);h[i]=mm+np.sqrt(vv)*np.random.normal()
 return h

@njit(cache=True)
def latent_pair_potentials(h,mu,phi,veta,A):
 n=len(h);K=len(mu);L=np.empty((n-1,K,K));init=np.empty(K)
 for j in range(K):init[j]=-.5*(h[0]-mu[j])**2-.5*np.log(2*np.pi)-np.log(K)
 for i in range(1,n):
  for j in range(K):
   for k in range(K):
    resid=h[i]-mu[k]-phi*(h[i-1]-mu[j]);L[i-1,j,k]=np.log(max(A[j,k],1e-300))-.5*(np.log(2*np.pi*veta)+resid*resid/veta)
 return L,init

@njit(cache=True)
def latent_ffbs(L,init):
 n1,K,_=L.shape;af=np.empty((n1+1,K));off=np.empty(n1);sc=np.empty(n1)
 mx=np.max(init);af[0]=np.exp(init-mx);ss=af[0].sum();af[0]/=ss;ll=mx+np.log(ss)
 for i in range(n1):
  mx=np.max(L[i]);off[i]=mx
  for k in range(K):
   v=0.
   for j in range(K):v+=af[i,j]*np.exp(L[i,j,k]-mx)
   af[i+1,k]=v
  ss=max(af[i+1].sum(),1e-300);sc[i]=ss;af[i+1]/=ss;ll+=mx+np.log(ss)
 z=np.empty(n1+1,np.int64);z[-1]=categorical(af[-1]);prob=np.empty(K)
 for i in range(n1-1,-1,-1):
  mx=-1e300
  for j in range(K):
   val=np.log(max(af[i,j],1e-300))+L[i,j,z[i+1]]
   if val>mx:mx=val
   prob[j]=val
  for j in range(K):prob[j]=np.exp(prob[j]-mx)
  z[i]=categorical(prob)
 return z,ll

@njit(cache=True)
def gibbs_mssv(x,zinit,muinit,iterations=1800,burn=800,seed=123):
 np.random.seed(seed);n=len(x);K=len(muinit);mu=muinit.copy();z=zinit.copy();phi=.95;veta=1./60
 A=np.ones((K,K))*.01/K+.99*np.eye(K);ylog=np.log(np.maximum(x*x,1e-12));h=np.empty(n)
 for i in range(n):h[i]=mu[z[i]]
 mixture=np.empty(n,np.int64);prob=np.empty(7);trace=np.empty((iterations,K+2));samplesA=np.empty((iterations-burn,K,K))
 sumsigma=np.zeros(n);sumh=np.zeros(n);counts=np.zeros((n,K));Ktrace=np.empty(iterations,np.int64)
 for it in range(iterations):
  for i in range(n):
   mx=-1e300
   for m in range(7):
    val=np.log(MIX_Q[m])-.5*np.log(MIX_V[m])-.5*(ylog[i]-h[i]-MIX_M[m])**2/MIX_V[m];prob[m]=val
    if val>mx:mx=val
   for m in range(7):prob[m]=np.exp(prob[m]-mx)
   mixture[i]=categorical(prob)
  h=sample_h(ylog,z,mu,phi,veta,mixture)
  L,init=latent_pair_potentials(h,mu,phi,veta,A);z,ll=latent_ffbs(L,init)
  # Joint Gaussian conditional of the regime means (not independent updates).
  precision=np.eye(K)/100.;rhs=np.zeros(K);precision[z[0],z[0]]+=1.;rhs[z[0]]+=h[0]
  for i in range(1,n):
   a=z[i];b=z[i-1];target=h[i]-phi*h[i-1]
   precision[a,a]+=1/veta;precision[b,b]+=phi*phi/veta;precision[a,b]-=phi/veta;precision[b,a]-=phi/veta
   rhs[a]+=target/veta;rhs[b]-=phi*target/veta
  chol=np.linalg.cholesky(precision);mean=np.linalg.solve(precision,rhs);noise=np.random.normal(0.,1.,K);mu=mean+np.linalg.solve(chol.T,noise)
  sxx=0.;sxy=0.
  for i in range(1,n):
   lag=h[i-1]-mu[z[i-1]];target=h[i]-mu[z[i]];sxx+=lag*lag;sxy+=lag*target
  vphi=1/(16.+sxx/veta);mphi=vphi*(.9*16.+sxy/veta);phi=truncated_normal(mphi,np.sqrt(vphi))
  sse=0.
  for i in range(1,n):
   e=h[i]-mu[z[i]]-phi*(h[i-1]-mu[z[i-1]]);sse+=e*e
  veta=(1.+.5*sse)/np.random.gamma(60.+.5*(n-1),1.)
  trans=np.ones((K,K))
  for i in range(1,n):trans[z[i-1],z[i]]+=1.
  for k in range(K):A[k]=dirichlet(trans[k])
  order=np.argsort(mu);inv=np.empty(K,np.int64)
  for k in range(K):inv[order[k]]=k
  mu=mu[order];Anew=np.empty((K,K))
  for j in range(K):
   for k in range(K):Anew[j,k]=A[order[j],order[k]]
  A=Anew;occ=np.zeros(K)
  for i in range(n):z[i]=inv[z[i]];occ[z[i]]+=1.
  Ktrace[it]=np.sum(occ>.01*n);trace[it,:K]=mu;trace[it,K]=phi;trace[it,K+1]=veta
  if it>=burn:
   samplesA[it-burn]=A
   for i in range(n):sumsigma[i]+=np.exp(h[i]/2);sumh[i]+=h[i];counts[i,z[i]]+=1.
 return trace,samplesA,sumsigma/(iterations-burn),sumh/(iterations-burn),counts/(iterations-burn),Ktrace

@njit(cache=True)
def particle_loglik(x,mu,phi,veta,A,nparticles=1200,seed=1):
 np.random.seed(seed);n=len(x);K=len(mu);h=np.empty(nparticles);z=np.empty(nparticles,np.int64);logw=np.empty(nparticles);weights=np.empty(nparticles)
 for p in range(nparticles):z[p]=np.random.randint(K);h[p]=mu[z[p]]+np.random.normal()
 ll=0.;esssum=0.;essmin=float(nparticles)
 for i in range(n):
  if i>0:
   hh=np.empty(nparticles);zz=np.empty(nparticles,np.int64);offset=np.random.random()/nparticles;parent=0;cum=weights[0]
   for p in range(nparticles):
    target=offset+p/nparticles
    while parent<nparticles-1 and cum<target:parent+=1;cum+=weights[parent]
    zz[p]=categorical(A[z[parent]]);hh[p]=mu[zz[p]]+phi*(h[parent]-mu[z[parent]])+np.sqrt(veta)*np.random.normal()
   h=hh;z=zz
  mx=-1e300
  for p in range(nparticles):
   logw[p]=-.5*np.log(2*np.pi)-.5*h[p]-.5*x[i]*x[i]*np.exp(-h[p])
   if logw[p]>mx:mx=logw[p]
  total=0.
  for p in range(nparticles):weights[p]=np.exp(logw[p]-mx);total+=weights[p]
  ll+=mx+np.log(total/nparticles);weights/=total;ess=1./np.sum(weights*weights);esssum+=ess
  if ess<essmin:essmin=ess
 return ll,esssum/n,essmin

def fit_mssv(x,hmm_model,seed=0,repeats=8):
 K=hmm_model['K'];order=np.argsort(hmm_model['sigma']);remap=np.empty(K,int);remap[order]=np.arange(K);zinit=remap[hmm_model['labels']].astype(np.int64);muinit=2*np.log(hmm_model['sigma'][order])
 trace,As,sig,hmean,gamma,Ktrace=gibbs_mssv(np.asarray(x,float),zinit,np.asarray(muinit,float),seed=seed)
 pp=trace[800:].mean(axis=0);mu=pp[:K];phi=float(pp[K]);veta=float(pp[K+1]);A=As.mean(axis=0)
 pf=np.array([particle_loglik(x,mu,phi,veta,A,1200,seed+90000+j) for j in range(repeats)])
 ll=float(logsumexp(pf[:,0])-np.log(repeats));p=K+2+K*(K-1)
 return dict(K=K,labels=gamma.argmax(axis=1),volatility=sig,hmean=hmean,mu=mu,phi=phi,veta=veta,A=A,
  BIC=-2*ll+p*np.log(len(x)),ll=ll,particle_LL=pf[:,0],particle_LL_sd=float(pf[:,0].std(ddof=1)),
  ESS_mean=float(pf[:,1].mean()),ESS_min=float(pf[:,2].min()),trace=trace,K_trace=Ktrace,
  parameter_point_estimate='posterior mean after 800 of 1800 iterations; one approximate-posterior chain',seed=seed)
