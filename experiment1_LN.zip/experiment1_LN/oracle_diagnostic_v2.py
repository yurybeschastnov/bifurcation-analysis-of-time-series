"""Ground-truth-assisted diagnostic, NEVER a candidate for blind model selection."""
import sys,pickle,json
from pathlib import Path
import numpy as np
from common import *
from branches import finalize
from branches_v2 import refine
rows=[]
for name in [f'N{i}' for i in range(1,8)]:
 f=np.load(ROOT/'data'/f'{name}.npz');tr=np.load(ROOT/'truth'/f'{name}.npz');old=pickle.load(open(ROOT/'results'/f'{name}_branches.pkl','rb'))
 t,y,T,scale=prepare(f['t'],f['y']);rv=local_rv(y,t,40);mask=old['mask']
 P=tr['parameters'].copy();P[:,0]/=scale;P[:,1]*=T/scale;P[:,2]*=np.sqrt(T)/scale;P[:,3]*=3*T**1.5/scale
 m=refine(P,y[mask],t[mask],rv[mask],'cubic',maxiter=1500,rounds=5)
 out=finalize(m,t,y,rv,mask,'cubic');me=metrics(tr['z'],out['labels'],tr['sigma'],out['volatility']*scale/np.sqrt(T))
 row=dict(series=name,ll=m['ll'],kappa=m['kappa'],P=m['P'],metrics=me,optimizer=m['optimizer']);rows.append(row)
 print(name,m['ll'],me,flush=True)
(ROOT/'revision2/oracle_refinement_diagnostic.json').write_text(dumps(rows))
