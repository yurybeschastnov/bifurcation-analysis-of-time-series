"""Create every plot from the final arrays: one plot per figure, default colors.
No plot or metric is used to select seeds, branch estimates, or benchmark fits.
"""
from __future__ import annotations
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).resolve().parent/'.mplconfig'))
import json,pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment
from common import ROOT,prepare,local_rv
OUT=ROOT/'revision3'/'final';FIG=OUT/'figures'
NAMES=[f'L{i}' for i in range(1,7)]+[f'N{i}' for i in range(1,8)]
TITLES={'Branches_final':'Метод ветвей','HMM_BIC_paper_count':'HMM / BIC: счёт основной таблицы',
        'Kernel_HMM_paper_count':'Ядерная σ / HMM: счёт основной таблицы','PELT_cluster':'PELT + кластеризация',
        'sticky_HDP':'HDP-HMM: CRT, средняя σ'}


def ru(name):return name.replace('L','Л').replace('N','Н')


def finish(fig,ax,name):
    ax.grid(True,alpha=.22)
    fig.tight_layout()
    fig.savefig(FIG/name,dpi=160,bbox_inches='tight')
    plt.close(fig)


def mapping(true,pred):
    C=np.zeros((int(true.max())+1,int(pred.max())+1),int);np.add.at(C,(true,pred),1)
    a,b=linear_sum_assignment(-C);mp={int(k):int(j) for j,k in zip(a,b)}
    return np.array([mp.get(int(j),C.shape[0]+int(j)) for j in pred]),mp


def main():
    FIG.mkdir(parents=True,exist_ok=True)
    scores=pd.read_csv(OUT/'metrics_all.csv');scores=scores[scores.grid=='full'];allk=pd.read_csv(OUT/'all_K.csv')
    oldk=pd.read_csv(ROOT/'revision2'/'model_selection_all_K.csv')
    inventory=[]
    for prefix in ['L','N']:
        names=[n for n in NAMES if n.startswith(prefix)];group=ru(prefix)
        for metric,factor,ylabel in [('ARI',1.,'Скорректированный индекс Ранда'),('EL2',100.,'Относительная ошибка σ, %')]:
            fig,ax=plt.subplots(figsize=(11,5))
            for method in ['Branches_final','HMM_BIC_paper_count','Kernel_HMM_paper_count','PELT_cluster','sticky_HDP']:
                if metric=='ARI' and method=='Kernel_HMM_paper_count':continue
                vals=scores[scores.method==method].set_index('series').loc[names,metric]
                ax.plot([ru(n) for n in names],factor*vals,marker='o',linewidth=1.8,label=TITLES[method])
            ax.set(title=f'Группа {group}: '+('разметка' if metric=='ARI' else 'волатильность'),xlabel='Конфигурация',ylabel=ylabel)
            ax.set_ylim(bottom=0.,top=1.04 if metric=='ARI' else None);ax.legend(fontsize=8)
            filename=f'{prefix}_{metric}.png';finish(fig,ax,filename);inventory.append(dict(file=filename,kind='summary'))
    fig,ax=plt.subplots(figsize=(11,5))
    truth=scores[scores.method=='Branches_final'].set_index('series').loc[NAMES,'K_true']
    ax.plot([ru(n) for n in NAMES],truth,marker='s',linestyle='--',label='Истинное K',linewidth=2)
    for method in ['Branches_final','HMM_BIC_paper_count','PELT_cluster','sticky_HDP']:
        val=scores[scores.method==method].set_index('series').loc[NAMES,'K_hat']
        ax.plot([ru(n) for n in NAMES],val,marker='o',label=TITLES[method],alpha=.8)
    ax.set(title='Число режимов: самостоятельный выбор каждой процедуры',ylabel='K',xlabel='Конфигурация');ax.set_yticks(range(1,7));ax.legend(fontsize=8)
    finish(fig,ax,'all_K_selection.png');inventory.append(dict(file='all_K_selection.png',kind='summary'))
    for name in NAMES:
        f=np.load(OUT/'predictions'/f'{name}.npz',allow_pickle=False)
        t=f['t'];y=f['y'];zt=f['true_labels'];zp=f['Branches_final_labels'];za,mp=mapping(zt,zp);bad=zt!=za
        own=scores[(scores.series==name)&(scores.method=='Branches_final')].iloc[0]
        label=f'{ru(name)}: K={int(own.K_hat)}, ARI={own.ARI:.3f}, ошибка σ={100*own.EL2:.2f}%'
        fig,ax=plt.subplots(figsize=(10.5,4.6))
        for j in np.unique(zt):ax.plot(t,np.where(zt==j,y,np.nan),linewidth=1.,label=f'Истинная ветвь {j+1}')
        if bad.any():ax.scatter(t[bad],y[bad],marker='x',s=17,label='Ошибочная метка',zorder=4)
        ax.set(title=label,xlabel='Время',ylabel='Наблюдение Y');ax.legend(fontsize=8)
        finish(fig,ax,f'{name}_trajectory.png')
        fig,ax=plt.subplots(figsize=(10.5,3.8))
        ax.step(t,zt+1,where='post',label='Истинные режимы',linewidth=1.8)
        ax.step(t,za+1,where='post',label='Восстановленные: взаимно-однозначное сопоставление',linestyle='--',linewidth=1.2)
        ax.set(title=f'{ru(name)}: разметка на полной сетке',xlabel='Время',ylabel='Номер ветви');ax.set_yticks(range(1,max(zt.max(),za.max())+2));ax.legend(fontsize=8)
        finish(fig,ax,f'{name}_labels.png')
        fig,ax=plt.subplots(figsize=(10.5,4.8))
        ax.plot(t,f['true_sigma'],linewidth=2.0,label='Истинная σ')
        for method in ['Branches_final','HMM_BIC_paper_count','Kernel_HMM_paper_count']:
            ax.plot(t,f[method+'_sigma'],linewidth=1.1,alpha=.85,label=TITLES[method])
        ax.set(title=f'{ru(name)}: восстановление волатильности',xlabel='Время',ylabel='σ в исходных единицах');ax.legend(fontsize=8)
        finish(fig,ax,f'{name}_volatility.png')
        fig,ax=plt.subplots(figsize=(8.5,4.8))
        a=allk[allk.series==name];b=oldk[oldk.series==name]
        ax.plot(a.K,a.BIC-a.BIC.min(),marker='o',label='Текущая версия')
        ax.plot(b.K,b.BIC-b.BIC.min(),marker='.',linestyle='--',label='Версия 2: собственный минимум')
        ax.axvline(int(own.K_true),linestyle=':',label='Истинное K: только для оценки')
        ax.set(title=f'{ru(name)}: выбор числа ветвей',xlabel='K',ylabel='BIC − минимум BIC');ax.set_xticks(range(1,7));ax.legend(fontsize=8)
        finish(fig,ax,f'{name}_BIC.png')
        fig,ax=plt.subplots(figsize=(9,4.8))
        _,_,T,scale=prepare(t,y);W=f['true_driver'];P=f['P_c_a_b_d'];Wfit=f['driver_working']*np.sqrt(T)
        for j,p in enumerate(f['true_parameters']):
            ix=zt==j;grid=np.linspace(W[ix].min(),W[ix].max(),150)
            ax.plot(grid,p[2]+3*p[3]*grid**2,label=f'Истинная σ: ветвь {j+1}')
        for k,p in enumerate(P):
            ix=zp==k
            if not ix.any():continue
            grid=np.linspace(Wfit[ix].min(),Wfit[ix].max(),150)
            b=p[2]*scale/np.sqrt(T);r=p[3]*scale/(3*T**1.5)
            ax.plot(grid,b+3*r*grid**2,linestyle='--',label=f'Оценка: ветвь {mp.get(k,k)+1}')
        ax.set(title=f'{ru(name)}: профили σ по собственным координатам драйвера',xlabel='W; без выравнивания по истинному пути',ylabel='σ');ax.legend(fontsize=8,ncol=2)
        finish(fig,ax,f'{name}_profiles.png')
        fig,ax=plt.subplots(figsize=(10.5,4.3))
        ax.plot(t,W,label='Истинный драйвер',linewidth=1.5)
        ax.plot(t,Wfit,label='Восстановленный драйвер, без оракульного выравнивания',linewidth=1.,alpha=.85)
        ax.set(title=f'{ru(name)}: общий драйвер',xlabel='Время',ylabel='W');ax.legend(fontsize=8)
        finish(fig,ax,f'{name}_driver.png')
        for kind in ['trajectory','labels','volatility','BIC','profiles','driver']:
            inventory.append(dict(file=f'{name}_{kind}.png',series=name,kind=kind))
    # Zoomed singular transitions in the actual fine-grid generator.
    seeds={r['series']:r for r in json.loads((ROOT/'truth/generation_audit.json').read_text())}
    for name in ['N2','N7']:
        q=np.load(ROOT/'truth'/f'{name}.npz');te=float(q['event_t'][0]);src=int(q['event_from'][0]);dst=int(q['event_to'][0]);P=q['parameters']
        rng=np.random.default_rng(np.random.SeedSequence(seeds[name]['seed_entropy']));W=np.r_[0.,np.cumsum(rng.normal(size=50000))/np.sqrt(50000.)];t=np.arange(50001)/50000.;ix=abs(t-te)<.002
        fig,ax=plt.subplots(figsize=(10,4.5))
        for j in [src,dst]:
            p=P[j];ax.plot(t[ix],p[0]+p[1]*t[ix]+p[2]*W[ix]+p[3]*W[ix]**3,label=f'Ветвь {j+1} на мелкой сетке')
        wo=float(q['event_w'][0]);p=P[src];yy=p[0]+p[1]*te+p[2]*wo+p[3]*wo**3
        ax.scatter([te],[yy],marker='o',s=60,label='Переключение при равенстве ветвей',zorder=5)
        io=abs(q['t']-te)<.002;ax.scatter(q['t'][io],q['y'][io],marker='x',s=40,label='Наблюдаемые отсчёты')
        ax.set(title=f'{ru(name)}: сингулярное переключение без скачка Y',xlabel='Время: увеличенный фрагмент',ylabel='Y');ax.legend(fontsize=8)
        filename=f'{name}_singular_switch.png';finish(fig,ax,filename);inventory.append(dict(file=filename,series=name,kind='singularity'))
    f=np.load(OUT/'predictions'/'N5.npz');rv=local_rv(f['y_working'],f['t_working'],40)
    fig,ax=plt.subplots(figsize=(10.5,4.5));ax.plot(f['t'],rv,label='Локальная RV, окно 40')
    ix=~f['mask'];ax.scatter(f['t'][ix],rv[ix],marker='x',s=30,label='63 исключённые точки после разрешения равенств')
    ax.set(title='Н5: детерминированное цензурирование двух хвостов RV',xlabel='Время',ylabel='RV в рабочих единицах');ax.legend(fontsize=8)
    finish(fig,ax,'N5_censoring.png');inventory.append(dict(file='N5_censoring.png',kind='censoring'))
    pd.DataFrame(inventory).to_csv(OUT/'figure_index.csv',index=False)
    print(f'Created {len(inventory)} separate figures in {FIG}')
if __name__=='__main__':main()
