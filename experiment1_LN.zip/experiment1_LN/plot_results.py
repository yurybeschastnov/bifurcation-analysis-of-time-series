"""Separate figures, default matplotlib colors; all scores are full-grid scores."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR', str(Path(__file__).resolve().parent / '.mplconfig'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
from common import ROOT


def main():
    scores = pd.read_csv(ROOT / 'results' / 'metrics_all.csv')
    scores = scores[scores.grid == 'full']
    series = [f'L{i}' for i in range(1, 7)] + [f'N{i}' for i in range(1, 8)]
    labels = [s.replace('L', 'Л').replace('N', 'Н') for s in series]
    specifications = [
        ('ARI', 1., 'regime_accuracy.png', 'Качество режимной разметки', 'ARI',
         [('Branches', 'Метод ветвей'), ('HMM_BIC', 'Гауссова HMM / BIC'), ('sticky_HDP', 'Липкая HDP-HMM')]),
        ('EL2', 100., 'volatility_error.png', 'Ошибка восстановления волатильности', 'Относительная ошибка L₂, %',
         [('Branches', 'Метод ветвей'), ('Kernel_HMM', 'Ядерная оценка / HMM'), ('sticky_HDP', 'Липкая HDP-HMM')]),
    ]
    for metric, factor, filename, title, ylabel, methods in specifications:
        fig, ax = plt.subplots(figsize=(11, 4.8))
        for method, label in methods:
            values = scores[scores.method == method].set_index('series').loc[series, metric]
            ax.plot(labels, factor*values, marker='o', linewidth=1.7, label=label)
        ax.set(title=title, xlabel='Конфигурация', ylabel=ylabel)
        ax.set_ylim(bottom=0, top=1.05 if metric == 'ARI' else None)
        ax.grid(True, alpha=.25)
        ax.legend()
        fig.tight_layout()
        fig.savefig(ROOT / 'figures' / filename, dpi=180)
        plt.close(fig)


if __name__ == '__main__':
    main()
