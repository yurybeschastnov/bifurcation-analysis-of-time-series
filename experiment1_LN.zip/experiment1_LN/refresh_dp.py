"""Resume only variational fits with a failed convergence flag; never read truth.
This audit utility records the effect of the numerical stopping-rule correction.
The normal run_baselines.py already contains the corrected procedure.
"""
import argparse
import json
import pickle
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from baselines import dp_hmm
from common import ROOT, dumps, prepare


def refresh_one(path):
    name = path.stem
    seed = 502000 + sum((j + 1) * ord(c) for j, c in enumerate(name))
    f = np.load(path)
    t, y, _, _ = prepare(f['t'], f['y'])
    x = np.diff(y) / np.sqrt(np.diff(t))
    model_path = ROOT / 'results' / f'{name}_hmm.pkl'
    output_path = ROOT / 'results' / f'{name}_baselines.pkl'
    audit_path = ROOT / 'results' / f'{name}_baseline_audit.json'
    with model_path.open('rb') as h:
        models = pickle.load(h)
    with output_path.open('rb') as h:
        results = pickle.load(h)
    audit = json.loads(audit_path.read_text())
    before = audit['DP']
    if before['converged']:
        return dict(series=name, changed=False, before=before, after=before)
    m, after = dp_hmm(x, models, seed + 1)
    z = m['labels']
    results['DP_HMM'] = dict(K=m['K'], labels=np.r_[z[0], z],
                            volatility=np.r_[m['sigma'][z[0]], m['sigma'][z]])
    with output_path.open('wb') as h:
        pickle.dump(results, h)
    audit['DP_before_continuation'] = before
    audit['DP'] = after
    audit_path.write_text(dumps(audit))
    print(name, 'DP', before['K'], '->', after['K'],
          'converged', after['converged'], 'iterations', after['iterations'], flush=True)
    return dict(series=name, changed=True, before=before, after=after)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        records = list(pool.map(refresh_one, sorted((ROOT / 'data').glob('*.npz'))))
    (ROOT / 'results' / 'dp_convergence_correction.json').write_text(dumps(records))
