"""Refresh only post-fit QV bounds. Parameters, labels, local scores are immutable."""
import pickle,json
import numpy as np
from common import ROOT,prepare,local_rv,dumps
from branches import inversion,pair_potentials,qv_certificate

def main():
 log=[]
 for path in sorted((ROOT/'results').glob('*_branches.pkl')):
  name=path.stem.replace('_branches','');f=np.load(ROOT/'data'/f'{name}.npz');t,y,_,_=prepare(f['t'],f['y']);rv=local_rv(y,t,40)
  with open(path,'rb') as h:b=pickle.load(h)
  oldP=b['selected']['P'].copy();oldz=b['selected']['labels'].copy();mask=b['mask'];a=json.loads((ROOT/'results'/f'{name}_branch_audit.json').read_text())
  old=b['selected']['certificate']['excluded_mass_bound']
  for m in b['candidates']:
   if m is None:continue
   w,s,_,_=inversion(y[mask],t[mask],m['P']);L,dq=pair_potentials(w,s,t[mask],rv[mask],m['kappa']);m['certificate']=qv_certificate(L,dq,t[mask][-1]-t[mask][0])
  sel=b['selected'];sel['certificate']=b['candidates'][sel['K']-1]['certificate']
  others=[m['BIC'] for m in b['candidates'] if m is not None and m['K']!=sel['K']];upper=sel['BIC']+2*sel['certificate']['loglik_gap_bound']
  sel['QV_selection_certified_at_fitted_candidates']=bool(not others or upper<min(others))
  assert np.array_equal(sel['P'],oldP) and np.array_equal(sel['labels'],oldz)
  with open(path,'wb') as h:pickle.dump(b,h)
  a['certificate']=sel['certificate'];a['QV_selection_certified_at_fitted_candidates']=sel['QV_selection_certified_at_fitted_candidates']
  for c,m in zip(a['candidates'],b['candidates']):
   if m is not None:c['certificate']=m['certificate']
  a['postfit_numeric_correction']='Tilted forward switched to full log space; positive mass bounds floored upward at 1e-300. No refitting or label change.'
  (ROOT/'results'/f'{name}_branch_audit.json').write_text(dumps(a));log.append(dict(series=name,old_bound=old,new_bound=sel['certificate']['excluded_mass_bound'],selected_K=sel['K'],labels_parameters_unchanged=True,selection_certified=sel['QV_selection_certified_at_fitted_candidates']))
 (ROOT/'results'/'qv_numerical_correction.json').write_text(dumps(log));print(dumps(log))
if __name__=='__main__':main()
