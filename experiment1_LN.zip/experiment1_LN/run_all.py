"""Run the independent experiment, or audit the supplied frozen results.
Tested with Python 3.13.5. All paths are relative to this script, not the shell.
No network requests and no access to an author's repository are made.
"""
from pathlib import Path
import argparse
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def run_step(name: str, arguments: list[str], environment: dict[str, str]) -> None:
    start = time.perf_counter()
    log_path = ROOT / 'logs' / f'{name}.log'
    print(f'{name}: running; log={log_path}', flush=True)
    with log_path.open('w', encoding='utf-8') as log:
        result = subprocess.run([sys.executable, *arguments], cwd=ROOT,
                                env=environment, stdout=log,
                                stderr=subprocess.STDOUT, check=False)
    if result.returncode:
        tail = '\n'.join(log_path.read_text(errors='replace').splitlines()[-40:])
        raise RuntimeError(f'{name} failed (exit {result.returncode}).\n{tail}')
    print(f'{name}: completed in {time.perf_counter()-start:.1f} s', flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--validate-only', action='store_true',
                        help='Do not generate or refit; audit the supplied estimates.')
    args = parser.parse_args()
    if args.workers < 1:
        parser.error('--workers must be positive')
    for name in ['data', 'truth', 'results', 'logs', 'figures', 'predictions']:
        (ROOT / name).mkdir(exist_ok=True)
    environment = os.environ.copy()
    for variable in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
        environment[variable] = '1'
    environment['MPLCONFIGDIR'] = str(ROOT / '.mplconfig')
    if not args.validate_only:
        for name, arguments in [
            ('generation', ['generate.py']),
            ('hmm', ['run_hmm.py', '--workers', str(args.workers)]),
            ('branches', ['run_branches.py', '--workers', str(args.workers)]),
            ('baselines', ['run_baselines.py', '--workers', str(args.workers)]),
            ('mssv', ['run_mssv.py', '--workers', str(args.workers)]),
        ]:
            run_step(name, arguments, environment)
    for name, arguments in [
        ('unit_tests', ['-m', 'pytest', 'tests', '-q']),
        ('attestation', ['attest.py']),
        ('validation', ['validate.py']),
        ('export', ['export_results.py']),
        ('plots', ['plot_results.py']),
        ('report', ['build_report.py']),
    ]:
        run_step(name, arguments, environment)
    print(f'Finished. Report: {ROOT / "REPORT_RU.html"}', flush=True)


if __name__ == '__main__':
    main()
