"""One-command audit; by default validates the included frozen fits only."""
from pathlib import Path
import argparse,subprocess,sys
ROOT=Path(__file__).resolve().parent

def run(*args):
    subprocess.run([sys.executable,*args],cwd=ROOT,check=True)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--refit',action='store_true',help='Repeat the data-only search for all 78 models')
    p.add_argument('--workers',type=int,default=4)
    a=p.parse_args()
    if a.workers<1: p.error('--workers must be positive')
    if a.refit:run('run_revision2.py','--workers',str(a.workers))
    run('validate_revision2.py')
    run('geometry_audit.py')
    run('-m','pytest','tests','-q')
    run('build_revision2_report.py')
if __name__=='__main__':main()
