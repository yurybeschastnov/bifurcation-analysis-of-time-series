import numpy as np,time,pickle,argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
from common import ROOT,prepare,local_rv,dumps
from hmm import fit_range
from baselines import pelt_cluster,dp_hmm,kernel_sigma
from hdp import fit_hdp

def run_one(path):
 name=path.stem;seed=502000+sum((j+1)*ord(c) for j,c in enumerate(name));start=time.perf_counter();f=np.load(path);t,y,T,scale=prepare(f['t'],f['y']);x=np.diff(y)/np.sqrt(np.diff(t));results={};meta={}
 with open(ROOT/'results'/f'{name}_hmm.pkl','rb') as h:models=pickle.load(h)
 for crit in ['BIC','AIC','ICL']:
  m=min(models,key=lambda a:a[crit]);z=m['labels'];results['HMM_'+crit]=dict(K=m['K'],labels=np.r_[z[0],z],volatility=np.r_[m['sigma'][z[0]],m['sigma'][z]])
 meta['HMM_candidates']=[{k:m[k] for k in ['K','BIC','AIC','ICL','ll','parameters','restart_log']} for m in models]
 m=pelt_cluster(x,seed=seed);z=m['labels'];results['PELT_cluster']=dict(K=m['K'],labels=np.r_[z[0],z],volatility=np.r_[m['sigma'][z[0]],m['sigma'][z]]);meta['PELT']=dict(segment_edges=m['segment_edges'],candidate_BIC=m['models_summary'])
 m,dpmeta=dp_hmm(x,models,seed+1);z=m['labels'];results['DP_HMM']=dict(K=m['K'],labels=np.r_[z[0],z],volatility=np.r_[m['sigma'][z[0]],m['sigma'][z]]);meta['DP']=dpmeta
 mb=min(models,key=lambda a:a['BIC']);s,kmeta=kernel_sigma(y,t,mb['labels']);results['Kernel_HMM']=dict(K=mb['K'],labels=np.r_[mb['labels'][0],mb['labels']],volatility=np.r_[s[0],s]);meta['Kernel']={'bandwidths':kmeta['bandwidths']}
 m=fit_hdp(x,seed+2);z=m['labels'];s=m['volatility'];results['sticky_HDP']=dict(K=m['K'],labels=np.r_[z[0],z],volatility=np.r_[s[0],s]);meta['HDP']={k:m[k] for k in ['K_trace','ll_trace','representative_draw','posterior_mode_frequency','description']}
 if name[0]=='N':
  gm=fit_range(x,4,M=3,restarts=4,seed=seed+3,maxiter=600);m=min(gm,key=lambda a:a['BIC']);z=m['labels'];s=m['sigma'][z]
  results['GMM_HMM']=dict(K=m['K'],labels=np.r_[z[0],z],volatility=np.r_[s[0],s]);meta['GMM_candidates']=[{k:m[k] for k in ['K','BIC','ll','parameters','restart_log']} for m in gm]
 for h in [10,20,40,80]:results[f'RV_h{h}']=dict(K=None,labels=np.array([],int),volatility=local_rv(y,t,2*h))
 with open(ROOT/'results'/f'{name}_baselines.pkl','wb') as h:pickle.dump(results,h)
 (ROOT/'results'/f'{name}_baseline_audit.json').write_text(dumps(meta));print(name,'baselines',round(time.perf_counter()-start,1),'seconds',{k:v['K'] for k,v in results.items() if v['K'] is not None},flush=True)
 return name
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=4);p.add_argument('--series',nargs='*');a=p.parse_args();paths=sorted((ROOT/'data').glob('*.npz'))
 if a.series:paths=[f for f in paths if f.stem in a.series]
 with ProcessPoolExecutor(max_workers=a.workers) as ex:
  fs=[ex.submit(run_one,f) for f in paths]
  for future in as_completed(fs):future.result()
