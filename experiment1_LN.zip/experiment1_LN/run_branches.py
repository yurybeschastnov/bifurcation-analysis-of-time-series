"""Blind independent branch fits. Never opens truth/, CONFIGS, or author code."""
import argparse,pickle,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from common import ROOT,prepare,local_rv,censor_mask,dumps
from branches import affine_start,volatility_start,profile,optimize_start,finalize,inversion,pair_potentials,pair_viterbi

def fit_one(path,maxiter=180):
 name=path.stem;seed=730000+sum((j+1)*ord(c) for j,c in enumerate(name));rng=np.random.default_rng(seed);begin=time.perf_counter()
 f=np.load(path);t,y,T,scale=prepare(f['t'],f['y']);family=str(f['family']);rv=local_rv(y,t,40);mask=censor_mask(rv)
 # Initial point is a conditioning anchor; preserving it adds no observation density.
 mask[0]=True;tk=t[mask];yk=y[mask];rk=rv[mask]
 with open(ROOT/'results'/f'{name}_hmm.pkl','rb') as h:hmms=pickle.load(h)
 models=[];audit=[]
 def attempt(P,source,K):
  ll,kap,_=profile(P,yk,tk,rk)
  if not np.isfinite(ll):
   rescue=optimize_start(P,yk,tk,rk,family,maxiter=min(100,maxiter),hard=False,profile_rounds=1)
   P=rescue['P'];ll,kap,_=profile(P,yk,tk,rk)
  if not np.isfinite(ll):
   audit.append(dict(K=K,source=source,status='no locally admissible path after soft initialization'));return None
  cand=optimize_start(P,yk,tk,rk,family,maxiter=maxiter,hard=True,profile_rounds=3)
  cand['source']=source
  out=finalize(cand,t,y,rv,mask,family)
  if out is not None:
   audit.append(dict(K=K,source=source,ll=out['ll'],BIC=out['BIC'],QV=out['QV'],QV_valid=out['QV_valid'],
    omitted_QV_mass_bound=out['certificate']['excluded_mass_bound'],optimizer=out['optimizer']))
  return out
 def choose(candidates):
  finite=[m for m in candidates if m is not None and m['QV_valid']]
  return max(finite,key=lambda m:m['ll']) if finite else None
 for K in range(1,7):
  P,z=affine_start(y,t,hmms[K-1],True);Pzero,_=affine_start(y,t,hmms[K-1],False)
  starts=[(P,'HMM-continuity/drift'),(Pzero,'HMM-continuity/no-drift')]
  if family=='cubic':
   gamma=np.eye(K)[z]
   starts.extend([(volatility_start(P.copy(),y,t,gamma,family),'smooth-vol/drift'),(volatility_start(Pzero.copy(),y,t,gamma,family),'smooth-vol/no-drift')])
   Q=Pzero.copy();Q[:,3]=.15;Q[:,2]*=.9;starts.append((Q,'curved-small'))
   Q=Pzero.copy();Q[:,3]=.8;Q[:,2]*=.7;starts.append((Q,'curved-large'))
  else:
   # Perturb geometry, never use true parameters or estimated metric quality.
   for s in range(2):
    Q=P.copy();Q[:,0]+=rng.normal(0,.015,K);Q[0,0]=0.;Q[:,1]+=rng.normal(0,.04,K);Q[:,2]*=np.exp(rng.normal(0,.05,K));starts.append((Q,f'geometry-jitter-{s}'))
  candidates=[]
  if K>1 and models[-1] is not None:
   prev=models[-1];Q=np.vstack([prev['P'],[0.,0.,max(20.,8*rv.max()),0.]])
   emb=finalize(dict(P=Q,ll=prev['ll'],kappa=prev['kappa'],optimizer=[],source='nested dormant branch'),t,y,rv,mask,family)
   if emb is not None:candidates.append(emb)
   # Split the most occupied branch without giving the estimator any true labels.
   j=int(np.argmax(np.bincount(prev['labels'],minlength=K-1)));Q=np.vstack([prev['P'],prev['P'][j]])
   Q[-1,0]+=.025;Q[-1,2]*=1.12;Q[j,2]*=.92;starts.append((Q,'split lower-K fit'))
  for Q,source in starts:
   candidates.append(attempt(Q,source,K))
  best=choose(candidates);models.append(best)
  print(name,family,'K',K,'ll',None if best is None else round(best['ll'],3),'QV',None if best is None else round(best['QV'],4),flush=True)
  with open(ROOT/'results'/f'{name}_branches.partial.pkl','wb') as h:pickle.dump(models,h)
 # Backward deletion/merging, as in algorithm 2. Each candidate reoptimized.
 for K in range(5,0,-1):
  parent=models[K]
  if parent is None:continue
  P=parent['P'];occ=np.bincount(parent['labels'],minlength=K+1);starts=[]
  # Deletion excludes state 0 because it is the initial conditioning state.
  for j in np.argsort(occ[1:])[:2]+1:starts.append((np.delete(P,j,0),f'backward deletion {j}'))
  distances=[]
  for a in range(K+1):
   for b in range(a+1,K+1):distances.append((np.linalg.norm((P[a]-P[b])*[.1,.1,1.,.3]),a,b))
  for _,a,b in sorted(distances)[:2]:
   Q=P.copy();weight=occ[a]+occ[b];Q[a]=(occ[a]*P[a]+occ[b]*P[b])/max(weight,1);Q=np.delete(Q,b,0);Q[0,0]=0.;starts.append((Q,f'backward merge {a},{b}'))
  candidates=[models[K-1]]
  for Q,source in starts:candidates.append(attempt(Q,source,K))
  models[K-1]=choose(candidates)
 # Enforce numerical nesting with an explicit admissibly dormant branch.
 for K in range(2,7):
  prev=models[K-2]
  if prev is None:continue
  Q=np.vstack([prev['P'],[0.,0.,max(20.,8*rv.max()),0.]])
  emb=finalize(dict(P=Q,kappa=prev['kappa'],optimizer=[],source='nested dormant branch after merging'),t,y,rv,mask,family)
  models[K-1]=choose([models[K-1],emb])
 valid=[m for m in models if m is not None]
 if not valid:raise RuntimeError(f'{name}: no admissible fitted model; not replacing it with an oracle.')
 best=min(valid,key=lambda m:m['BIC']);bics=sorted(m['BIC'] for m in valid);gap=bics[1]-bics[0] if len(bics)>1 else np.inf
 best['BIC_gap']=gap;best['seconds']=time.perf_counter()-begin
 # Bounds on globally QV-constrained score at the fitted parameter candidates.
 competitor_lowers=[m['BIC'] for m in valid if m is not best]
 best_upper=best['BIC']+2*best['certificate']['loglik_gap_bound']
 best['QV_selection_certified_at_fitted_candidates']=bool(not competitor_lowers or best_upper<min(competitor_lowers))
 payload=dict(selected=best,candidates=models,seed=seed,normalization={'T':T,'scale':scale},mask=mask)
 with open(ROOT/'results'/f'{name}_branches.pkl','wb') as h:pickle.dump(payload,h)
 summary=dict(series=name,family=family,seed=seed,selected_K=best['K'],selected_BIC=best['BIC'],BIC_gap=gap,
   selected_source=best['source'],selected_parameters_c_a_b_d=best['P'],QV=best['QV'],certificate=best['certificate'],
   QV_selection_certified_at_fitted_candidates=best['QV_selection_certified_at_fitted_candidates'],seconds=best['seconds'],
   candidates=[None if m is None else {k:m[k] for k in ['K','ll','BIC','QV','certificate','source','P','occupied_states']} for m in models],attempts=audit)
 (ROOT/'results'/f'{name}_branch_audit.json').write_text(dumps(summary))
 print(name,'DONE branch K',best['K'],'gap',round(gap,3),'seconds',round(best['seconds'],1),flush=True)
 return name
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=4);p.add_argument('--series',nargs='*');p.add_argument('--maxiter',type=int,default=180);args=p.parse_args()
 paths=sorted((ROOT/'data').glob('*.npz'))
 if args.series:paths=[f for f in paths if f.stem in args.series]
 with ProcessPoolExecutor(max_workers=args.workers) as ex:
  fs=[ex.submit(fit_one,f,args.maxiter) for f in paths]
  for future in as_completed(fs):future.result()
