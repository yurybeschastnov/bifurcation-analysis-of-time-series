"""One-realization L/N experiment: current entry point for audit version 3.

Default: verify included observations/fits, run tests, recompute metrics and plots.
--refit: recompute every estimator on the SAME frozen observations, then audit.
No network access, repository access, or selection by true labels is performed.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def run_step(label: str, command: list[str], env: dict[str, str]) -> None:
    directory = ROOT / 'revision3' / 'logs'
    directory.mkdir(parents=True, exist_ok=True)
    logfile = directory / f'pipeline_{label}.log'
    start = time.perf_counter()
    print(f'{label}: started; log={logfile.relative_to(ROOT)}', flush=True)
    with logfile.open('w', encoding='utf-8') as handle:
        result = subprocess.run([sys.executable, *command], cwd=ROOT,
                                stdout=handle, stderr=subprocess.STDOUT,
                                env=env, check=False)
    if result.returncode:
        tail = '\n'.join(logfile.read_text(encoding='utf-8', errors='replace').splitlines()[-35:])
        raise RuntimeError(f'{label} failed, exit={result.returncode}\n{tail}')
    print(f'{label}: passed in {time.perf_counter()-start:.1f} s', flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--refit', action='store_true', help='Re-estimate all methods on the frozen observations. Slow; replaces working estimates.')
    mode.add_argument('--figures-only', action='store_true', help='Only rebuild figures and HTML from final numerical arrays.')
    mode.add_argument('--validate-only', action='store_true', help='Explicit name for the default audit mode.')
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    if args.workers < 1:
        parser.error('--workers must be at least 1')
    env = os.environ.copy()
    env['PYTHONUTF8'] = '1'
    for key in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS']:
        env[key] = '1'
    env['MPLCONFIGDIR'] = str(ROOT / '.mplconfig')
    for directory in ['results','revision2','revision3','logs']:
        (ROOT/directory).mkdir(exist_ok=True)
    steps: list[tuple[str,list[str]]] = []
    if not args.figures_only:
        # Check frozen input against its generation manifest before any scoring.
        steps.extend([('input_replay', ['generate_verified.py']),
                      ('unit_tests', ['-m','pytest','tests','-q'])])
        if args.refit:
            workers = ['--workers',str(args.workers)]
            steps.extend([
                ('hmm_refit', ['run_hmm.py',*workers]),
                ('branches_initial_refit', ['run_branches.py',*workers]),
                ('baselines_refit', ['run_baselines.py',*workers]),
                ('mssv_refit', ['run_mssv.py',*workers]),
                ('initial_validation', ['validate.py']),
                ('initial_export', ['export_results.py']),
                ('branches_expanded_refit', ['run_revision2.py',*workers]),
                ('branches_kappa_refit', ['run_revision3.py',*workers]),
                ('benchmark_variants_refit', ['audit_baseline_fairness.py',*workers]),
                ('mask_ties_refit', ['audit_censoring.py',*workers]),
            ])
        else:
            steps.extend([('mask_audit', ['audit_censoring.py','--validate-only']),
                          ('benchmark_variant_scores', ['audit_baseline_fairness.py','--score-only'])])
        steps.append(('final_independent_validation', ['validate_final.py']))
    steps.extend([('figures', ['plot_atlas.py']),('report', ['build_final_report.py'])])
    for name, command in steps:
        run_step(name,command,env)
    print(f'Finished. Open {ROOT / "START_HERE.html"}',flush=True)
    print('Final tables: revision3/final/. Earlier results/ and revision2/ are historical stages.')


if __name__ == '__main__':
    main()
