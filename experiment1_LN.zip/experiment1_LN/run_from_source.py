"""Source-only launcher: rebuild data and outputs removed from the small ZIP.

The original estimator and generator source files are not changed. This launcher
only orders their execution and creates the output directories they expect.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def run_step(name: str, command: list[str], env: dict[str, str]) -> None:
    log_path = ROOT / "logs" / ("source_" + name + ".log")
    start = time.perf_counter()
    print(f"{name}: started; log={log_path}", flush=True)
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.run(
            [sys.executable, *command], cwd=ROOT, env=env,
            stdout=log, stderr=subprocess.STDOUT, check=False,
        )
    if process.returncode:
        tail = "\n".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-40:])
        raise RuntimeError(f"{name} failed (exit {process.returncode}).\n{tail}")
    print(f"{name}: completed in {time.perf_counter() - start:.1f} s", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--run", action="store_true", help="Generate data, refit all stages and rebuild outputs. Computationally expensive.")
    mode.add_argument("--tests-only", action="store_true", help="Run numerical unit tests; no saved data or estimates required.")
    mode.add_argument("--prepare-only", action="store_true", help="Generate the balanced observations and verify intersections; do not fit models.")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--no-figures", action="store_true", help="Skip PNG and HTML generation after numerical calculation.")
    parser.add_argument("--overwrite-generated", action="store_true", help="Allow a complete rerun in a directory already containing data/ or fitted results.")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    if not args.tests_only and not args.overwrite_generated:
        occupied = [d for d in ("data", "truth", "results", "revision2", "revision3")
                    if (ROOT / d).is_dir() and any((ROOT / d).iterdir())]
        if occupied:
            parser.error("Generated files already exist in " + ", ".join(occupied)
                         + ". Use a fresh extraction, or explicitly pass --overwrite-generated.")
    for name in ("data", "truth", "results", "logs", "figures", "predictions", "revision2", "revision3"):
        (ROOT / name).mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["MPLCONFIGDIR"] = str(ROOT / ".mplconfig")
    for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        env[variable] = "1"
    run_step("unit_tests", ["-m", "pytest", "tests", "-q"], env)
    if args.tests_only:
        return
    run_step("generation", ["generate.py"], env)
    run_step("complete_root_replay", ["generate_verified.py"], env)
    if args.prepare_only:
        print("Prepared data/ and truth/. No estimator has been run.", flush=True)
        return
    workers = ["--workers", str(args.workers)]
    steps = [
        ("hmm", ["run_hmm.py", *workers]),
        ("branches_initial", ["run_branches.py", *workers]),
        ("baselines", ["run_baselines.py", *workers]),
        ("mssv", ["run_mssv.py", *workers]),
        ("initial_validation", ["validate.py"]),
        ("initial_export", ["export_results.py"]),
        ("branches_expanded", ["run_revision2.py", *workers]),
        ("expanded_validation", ["validate_revision2.py"]),
        ("branches_kappa", ["run_revision3.py", *workers]),
        ("baseline_variants", ["audit_baseline_fairness.py", *workers]),
        ("censoring", ["audit_censoring.py", *workers]),
        ("final_validation", ["validate_final.py"]),
    ]
    if not args.no_figures:
        steps += [("figures", ["plot_atlas.py"]), ("report", ["build_final_report.py"])]
    for name, command in steps:
        run_step(name, command, env)
    print("Finished. Current numerical outputs: " + str(ROOT / "revision3" / "final"), flush=True)


if __name__ == "__main__":
    main()
