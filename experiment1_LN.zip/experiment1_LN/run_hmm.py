import pickle,time,argparse
import numpy as np
from concurrent.futures import ProcessPoolExecutor,as_completed
from common import ROOT,prepare,dumps
from hmm import fit_range

def run(path):
 name=path.stem;f=np.load(path);t,y,_,_=prepare(f['t'],f['y']);seed=502000+sum((j+1)*ord(c) for j,c in enumerate(name));st=time.perf_counter()
 models=fit_range(np.diff(y)/np.sqrt(np.diff(t)),6,restarts=10,seed=seed)
 with open(ROOT/'results'/f'{name}_hmm.pkl','wb') as h:pickle.dump(models,h)
 print(name, 'HMM BIC', min(models,key=lambda m:m['BIC'])['K'],'seconds',round(time.perf_counter()-st,1),flush=True)
 return name
if __name__=='__main__':
 parser=argparse.ArgumentParser(description='Fit frozen observations; no truth input.')
 parser.add_argument('--workers',type=int,default=4)
 args=parser.parse_args()
 if args.workers<1:parser.error('--workers must be positive')
 with ProcessPoolExecutor(max_workers=args.workers) as ex:
  fs=[ex.submit(run,f) for f in sorted((ROOT/'data').glob('*.npz'))]
  for f in as_completed(fs):f.result()
