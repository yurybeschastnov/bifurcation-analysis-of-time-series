import pickle,time,argparse
import numpy as np
from concurrent.futures import ProcessPoolExecutor,as_completed
from common import ROOT,prepare,dumps
from mssv import fit_mssv

def run_one(name):
 st=time.perf_counter();f=np.load(ROOT/'data'/f'{name}.npz');t,y,_,_=prepare(f['t'],f['y']);x=np.diff(y)/np.sqrt(np.diff(t))
 with open(ROOT/'results'/f'{name}_hmm.pkl','rb') as h:models=pickle.load(h)
 seed=970000+sum((j+1)*ord(c) for j,c in enumerate(name));fits=[]
 for K in range(1,5):
  m=fit_mssv(x,models[K-1],seed+K*101);fits.append(m);print(name,'MSSV K',K,'BIC',round(m['BIC'],2),'PF SD',round(m['particle_LL_sd'],3),flush=True)
 best=min(fits,key=lambda m:m['BIC']);z=best['labels'];s=best['volatility'];result=dict(K=best['K'],labels=np.r_[z[0],z],volatility=np.r_[s[0],s])
 with open(ROOT/'results'/f'{name}_mssv.pkl','wb') as h:pickle.dump(dict(selected=result,candidates=fits),h)
 (ROOT/'results'/f'{name}_mssv_audit.json').write_text(dumps(dict(series=name,selected_K=best['K'],seconds=time.perf_counter()-st,
  settings='K1..4; 1800/800; 8 particle repeats at 1200 particles; mu N(0,100); rows Dir(1); h0 variance1; z0 uniform',
  candidates=[{k:m[k] for k in ['K','BIC','ll','particle_LL_sd','particle_LL','ESS_mean','ESS_min','mu','phi','veta','A','seed','parameter_point_estimate']} for m in fits])))
 print(name,'MSSV DONE',best['K'],'seconds',round(time.perf_counter()-st,1),flush=True)
 return name
if __name__=='__main__':
 parser=argparse.ArgumentParser(description='Fit frozen observations; no truth input.')
 parser.add_argument('--workers',type=int,default=4)
 args=parser.parse_args()
 if args.workers<1:parser.error('--workers must be positive')
 with ProcessPoolExecutor(max_workers=args.workers) as ex:
  fs=[ex.submit(run_one,name) for name in ['N1','N2','N3','N6']]
  for f in as_completed(fs):f.result()
