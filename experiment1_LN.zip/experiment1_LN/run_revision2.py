"""Rerun improved search on frozen v1 observations; NO access to truth files.
Retains K=1..6 and old fitted candidates, uniform starts and stopping criteria.
Results and audits are written to revision2/, never over the v1 evidence.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
from pathlib import Path
import argparse,pickle,time,hashlib
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from common import ROOT,prepare,local_rv,dumps
from branches import finalize
from branches_v2 import refine,blind_starts,profile
OUT=ROOT/'revision2';OUT.mkdir(exist_ok=True)

def fit_one(name):
    begin=time.perf_counter();f=np.load(ROOT/'data'/f'{name}.npz')
    prior=pickle.load(open(ROOT/'results'/f'{name}_branches.pkl','rb'))
    hmms=pickle.load(open(ROOT/'results'/f'{name}_hmm.pkl','rb'))
    t,y,T,scale=prepare(f['t'],f['y']);family=str(f['family']);rv=local_rv(y,t,40)
    mask=prior['mask'].copy();tk=t[mask];yk=y[mask];rk=rv[mask]
    audit=[];models=[]
    def attempt(P,source):
        m=refine(P,yk,tk,rk,family)
        if m is None:
            rescue=refine(P,yk,tk,rk,family,maxiter=240,rounds=2,hard=False)
            if rescue is not None:m=refine(rescue['P'],yk,tk,rk,family)
        if m is None:
            audit.append(dict(K=len(P),source=source,status='no admissible path'));return None
        m['source']=source;out=finalize(m,t,y,rv,mask,family)
        audit.append(dict(K=len(P),source=source,ll=m['ll'],kappa=m['kappa'],
                          P=m['P'],QV=out['QV'],optimizer=m['optimizer']))
        return out
    def choose(candidates):
        candidates=[c for c in candidates if c is not None and c['QV_valid']]
        return max(candidates,key=lambda c:c['ll']) if candidates else None
    for K in range(1,7):
        old=prior['candidates'][K-1];candidates=[old]
        # Identical random optimizer sequence for each (series,K): all starts are
        # observation-dependent; no regime metadata or true branch parameters.
        starts=blind_starts(y,t,rv,hmms[K-1],family,np.random.default_rng(98134),nrandom=36)
        if old is not None:starts.insert(0,(old['P'],'saved-v1'))
        if K>1 and models[-1] is not None:
            lower=models[-1]
            for j in range(K-1):
                P=np.vstack([lower['P'],lower['P'][j]])
                P[j,2]*=.93;P[-1,2]*=1.08;P[-1,0]+=.02
                starts.append((P,f'split-v2-{j}'))
        for P,source in starts:
            candidate=attempt(P,source);candidates.append(candidate)
        best=choose(candidates);models.append(best)
        print(name,K,'ll',None if best is None else round(best['ll'],4),
              'source',None if best is None else best['source'],
              'seconds',round(time.perf_counter()-begin,1),flush=True)
        with open(OUT/f'{name}_partial.pkl','wb') as fp:pickle.dump(models,fp)
    # Backward branch deletion: explore merging even when a larger K lost by BIC.
    for K in range(5,0,-1):
        parent=models[K]
        if parent is None:continue
        P=parent['P'];occ=np.bincount(parent['labels'],minlength=K+1)
        starts=[(np.delete(P,j,axis=0),f'v2-delete-{j}') for j in range(1,K+1)]
        distances=sorted((np.linalg.norm((P[a]-P[b])*[.1,.1,1.,.3]),a,b)
                         for a in range(K+1) for b in range(a+1,K+1))
        for _,a,b in distances[:2]:
            Q=P.copy();Q[a]=(occ[a]*P[a]+occ[b]*P[b])/max(occ[a]+occ[b],1)
            Q=np.delete(Q,b,axis=0);Q[0,0]=0;starts.append((Q,f'v2-merge-{a}-{b}'))
        candidates=[models[K-1]]
        for P,source in starts:candidates.append(attempt(P,source))
        models[K-1]=choose(candidates)
    # Enforce nesting, without using the true K.
    for K in range(2,7):
        previous=models[K-2]
        if previous is None:continue
        P=np.vstack([previous['P'],[0,0,max(20.,8*rv.max()),0.]])
        candidate=finalize(dict(P=P,kappa=previous['kappa'],source='v2-nested-dormant',optimizer=[]),t,y,rv,mask,family)
        models[K-1]=choose([models[K-1],candidate])
    valid=[m for m in models if m is not None];best=min(valid,key=lambda c:c['BIC'])
    best['BIC_gap']=sorted(m['BIC'] for m in valid)[1]-best['BIC']
    record=dict(selected=best,candidates=models,attempts=audit,mask=mask,
                normalization={'T':T,'scale':scale},seconds=time.perf_counter()-begin,
                data_sha256=hashlib.sha256((ROOT/'data'/f'{name}.npz').read_bytes()).hexdigest(),
                optimizer_seed=98134,nrandom=36,ground_truth_access=False)
    with open(OUT/f'{name}_branches.pkl','wb') as fp:pickle.dump(record,fp)
    (OUT/f'{name}_audit.json').write_text(dumps({k:v for k,v in record.items() if k not in ['selected','candidates','mask']}))
    print('DONE',name,'K',best['K'],'ll',best['ll'],'sec',record['seconds'],flush=True)
    return name
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--series',nargs='*');p.add_argument('--workers',type=int,default=4);a=p.parse_args()
    names=a.series or [p.stem for p in sorted((ROOT/'data').glob('*.npz'))]
    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        futures=[ex.submit(fit_one,name) for name in names]
        for f in as_completed(futures):f.result()
