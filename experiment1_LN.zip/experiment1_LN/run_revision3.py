"""Observation-only, full-kappa numerical sensitivity check on frozen data."""
from __future__ import annotations
import os
for var in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[var]='1'
import argparse, pickle, time, hashlib
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
from common import ROOT, prepare, local_rv, dumps
from branches_v3 import audit_profile
from stable_inference import finalize_stable
OUT=ROOT/'revision3'


def fit_model(name,K,maxiter=350):
    t0=time.perf_counter();f=np.load(ROOT/'data'/f'{name}.npz',allow_pickle=False)
    t,y,T,scale=prepare(f['t'],f['y']);family=str(f['family']);rv=local_rv(y,t,40)
    old=pickle.load(open(ROOT/'results'/f'{name}_branches.pkl','rb'))
    v2=pickle.load(open(ROOT/'revision2'/f'{name}_branches.pkl','rb'));mask=v2['mask']
    starts=[('v2',v2['candidates'][K-1]),('v1',old['candidates'][K-1])]
    if starts[1][1] is not None and starts[0][1] is not None and np.allclose(starts[1][1]['P'],starts[0][1]['P'],rtol=0,atol=1e-12):starts=starts[:1]
    model,trace=audit_profile(starts,t,y,rv,mask,family,maxiter)
    payload=dict(model=model,trace=trace,seconds=time.perf_counter()-t0,
                 input_sha256=hashlib.sha256((ROOT/'data'/f'{name}.npz').read_bytes()).hexdigest(),
                 K=K,series=name,mask=mask,normalization=dict(T=T,scale=scale),maxiter=maxiter)
    OUT.mkdir(exist_ok=True);(OUT/'fits').mkdir(exist_ok=True)
    with open(OUT/'fits'/f'{name}_K{K}.pkl','wb') as h:pickle.dump(payload,h)
    (OUT/'fits'/f'{name}_K{K}.json').write_text(dumps({k:v for k,v in payload.items() if k not in ['model','mask']}),encoding='utf-8')
    print(name,K,'ll',model['ll'],'gain',model['ll']-v2['candidates'][K-1]['ll'],'sec',round(payload['seconds'],1),flush=True)
    return name,K


def consolidate(name):
    f=np.load(ROOT/'data'/f'{name}.npz');t,y,T,scale=prepare(f['t'],f['y']);rv=local_rv(y,t,40);family=str(f['family'])
    payloads=[pickle.load(open(OUT/'fits'/f'{name}_K{K}.pkl','rb')) for K in range(1,7)]
    models=[p['model'] for p in payloads];mask=payloads[0]['mask']
    for i in range(1,6):
        prev=models[i-1];P=np.vstack([prev['P'],[0.,0.,max(20.,8*rv.max()),0.]])
        emb=finalize_stable(dict(P=P,kappa=prev['kappa'],source='v3-nested-dormant',optimizer=[]),t,y,rv,mask,family,False)
        if emb is not None and emb['QV_valid'] and emb['ll']>models[i]['ll']:models[i]=emb
    selected=min(models,key=lambda m:m['BIC'])
    selected['BIC_gap']=min(m['BIC'] for m in models if m['K']!=selected['K'])-selected['BIC']
    with open(OUT/f'{name}_branches.pkl','wb') as h:pickle.dump(dict(selected=selected,candidates=models,mask=mask,normalization=dict(T=T,scale=scale)),h)
    print('SELECTED',name,selected['K'],selected['ll'],selected['BIC_gap'],flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workers',type=int,default=4);p.add_argument('--series',nargs='*');p.add_argument('--K',nargs='*',type=int);p.add_argument('--maxiter',type=int,default=350);p.add_argument('--resume',action='store_true');a=p.parse_args()
    if a.workers<1:p.error('workers must be positive')
    names=a.series or [f'L{i}' for i in range(1,7)]+[f'N{i}' for i in range(1,8)];Ks=a.K or list(range(1,7))
    jobs=[(n,k) for n in names for k in Ks if not a.resume or not (OUT/'fits'/f'{n}_K{k}.pkl').exists()]
    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        fs=[ex.submit(fit_model,n,k,a.maxiter) for n,k in jobs]
        for f in as_completed(fs):f.result()
    for n in names:
        if all((OUT/'fits'/f'{n}_K{k}.pkl').exists() for k in range(1,7)):consolidate(n)
if __name__=='__main__':main()
