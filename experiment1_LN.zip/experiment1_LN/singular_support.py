"""A necessary singularity condition that does not invent a coarse-grid hit rule.
For g=c+at+bw+(d/3)w^3, differing b or d guarantees a real intersection
for every time. If b and d coincide, intersection can occur only at c_k+a_k t
= c_j+a_j t. Disjoint parallel branches must never exchange labels.

This fixes an exact counterexample. It DOES NOT integrate the probability of
hitting an intersection between observations, or introduce a refractory latent
state into the inference score. The latter are different likelihood models.
"""
import numpy as np
from numba import njit
from branches import pair_potentials

@njit(cache=True)
def intersection_possible(P,k,j,t0,t1):
    if k==j:return True
    # Exact algebraic test: a tiny nonzero cubic still has a real root.
    if P[k,2]!=P[j,2] or P[k,3]!=P[j,3]:return True
    dc=P[k,0]-P[j,0];da=P[k,1]-P[j,1]
    if da==0:return dc==0
    root=-dc/da
    return t0<=root<=t1

@njit(cache=True)
def singular_pair_potentials(P,w,sig,t,rv,kappa,hard=True):
    L,dq=pair_potentials(w,sig,t,rv,kappa,hard)
    n1,K,_=L.shape;switch=np.exp(-kappa)
    for i in range(n1):
        for k in range(K):
            oldden=0.;newden=0.
            for j in range(K):
                if np.isfinite(L[i,k,j]):
                    weight=1. if j==k else switch;oldden+=weight
                    if intersection_possible(P,k,j,t[i],t[i+1]):newden+=weight
            if newden==0:
                for j in range(K):L[i,k,j]=-np.inf
                continue
            correction=np.log(oldden/newden)
            for j in range(K):
                if not intersection_possible(P,k,j,t[i],t[i+1]):L[i,k,j]=-np.inf
                elif np.isfinite(L[i,k,j]):L[i,k,j]+=correction
    return L,dq
