"""Log-space finalization and QV error certificates; frozen parameters supported.
The optional impossible-transition exclusion is an exact necessary consequence
of g_k=g_j, not a straight-line or same-observation singularity test.
"""
import numpy as np
from common import nearest_indices
from branches import inversion,pair_potentials,pair_viterbi,tilted_log_forward
from branches_v2 import log_forward
from singular_support import singular_pair_potentials


def qv_certificate_stable(L,dq,T):
    ll=log_forward(L)[0]
    if not np.isfinite(ll):return dict(excluded_mass_bound=1.,loglik_gap_bound=np.inf)
    if L.shape[1]==1:
        QV=float(dq[:,0,0].sum()/T);outside=not (.7<=QV<=1.4)
        return dict(excluded_mass_bound=float(outside),loglik_gap_bound=np.inf if outside else 0.,QV=QV,kind='deterministic')
    lower=upper=0.;tilt_lower=tilt_upper=0.
    for m in [1.,2.,5.,10.,20.,50.,100.,200.,500.,1000.,2000.,5000.,10000.]:
        a=tilted_log_forward(L,dq,-m)-ll+m*.7*T
        b=tilted_log_forward(L,dq,m)-ll-m*1.4*T
        if not np.isfinite(a) or not np.isfinite(b):raise FloatingPointError('Nonfinite tilted recursion')
        if a<lower:lower=a;tilt_lower=-m
        if b<upper:upper=b;tilt_upper=m
    logp=min(0.,float(np.logaddexp(lower,upper)))
    p=float(np.exp(max(logp,np.log(1e-300))))
    return dict(excluded_mass_bound=p,loglik_gap_bound=float(-np.log1p(-p)) if p<1 else np.inf,
                log_excluded_mass_bound=logp,log_lower_tail_bound=lower,log_upper_tail_bound=upper,
                tilt_lower=tilt_lower,tilt_upper=tilt_upper,kind='log-space Chernoff bound')


def finalize_stable(candidate,t,y,rv,mask,family,exclude_impossible=True):
    P=candidate['P'];tk=t[mask];yk=y[mask];rk=rv[mask]
    w,s,_,_=inversion(yk,tk,P)
    L,dq=(singular_pair_potentials(P,w,s,tk,rk,candidate['kappa'],True)
          if exclude_impossible else pair_potentials(w,s,tk,rk,candidate['kappa'],True))
    ll,_=log_forward(L)
    if not np.isfinite(ll):return None
    labels,vl=pair_viterbi(L);driver=w[np.arange(len(labels)),labels]
    qv=float(np.sum(np.diff(driver)**2)/(tk[-1]-tk[0]))
    mapping=nearest_indices(t,tk);all_labels=labels[mapping]
    wall,sall,_,_=inversion(y,t,P);ix=np.arange(len(t));p=3 if family=='affine' else 4
    out=dict(candidate);out.update(K=len(P),family=family,ll=float(ll),
        BIC=float(-2*ll+p*len(P)*np.log(mask.sum())),labels=all_labels,
        volatility=sall[ix,all_labels],driver=wall[ix,all_labels],QV=qv,QV_valid=bool(.7<=qv<=1.4),
        certificate=qv_certificate_stable(L,dq,tk[-1]-tk[0]),viterbi_ll=float(vl),
        mask=mask,retained_t=tk,retained_driver=driver,occupied_states=int(len(np.unique(all_labels))),
        exclude_impossible=exclude_impossible)
    return out
