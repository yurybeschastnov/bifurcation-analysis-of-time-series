"""Additional tests for article fidelity, not tests requiring the method to win."""
import sys,itertools
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from scipy.special import logsumexp
from audit_reference import inverse_bisection,reference_score
from branches import inversion,pair_potentials,KAPPAS
from branches_v2 import log_evaluate,log_forward
from branches_v3 import refine_fixed
from censoring_exact import ranked_mask
from stable_inference import finalize_stable


def test_independent_inverse_including_linear_and_negative_driver():
    rng=np.random.default_rng(384);t=np.arange(40)/39;y=rng.normal(size=40)
    P=np.array([[0.,.1,.25,0.],[.2,-.1,.8,.9],[-.1,.2,1.3,1e-9]])
    w,s=inverse_bisection(y,t,P);wp,sp,*_=inversion(y,t,P)
    assert np.max(abs(w-wp))<1e-12 and np.max(abs(s-sp))<1e-12


def test_reference_local_score_equals_exhaustive_sum():
    t=np.arange(7)*.01;y=np.array([0,.02,-.01,.02,.01,.02,0]);rv=np.ones(7)
    P=np.array([[0.,.1,.7,.15],[.02,-.1,1.1,.1]])
    ll,L,*_=reference_score(y,t,rv,P,4.,True)
    values=[]
    for tail in itertools.product(range(2),repeat=6):
        z=(0,)+tail;values.append(sum(L[i,z[i],z[i+1]] for i in range(6)))
    assert abs(ll-logsumexp(values))<1e-11


def test_single_affine_score_matches_normal_increment_density():
    t=np.array([0.,.01,.04,.05,.10]);y=np.array([0.,.02,-.03,.01,.02]);b=.7;a=.12
    P=np.array([[0.,a,b,0.]])
    ll=reference_score(y,t,np.ones(5),P,9.)
    dy=np.diff(y)-a*np.diff(t)
    exact=np.sum(-.5*dy*dy/(b*b*np.diff(t))-.5*np.log(2*np.pi*b*b*np.diff(t)))
    assert abs(ll-exact)<1e-12


def test_rescaling_levels_preserves_score_up_to_jacobian_constant():
    t=np.linspace(0,.1,20);y=.1*np.sin(20*t);rv=np.ones(20);P=np.array([[0.,.1,.7,.2],[.03,-.1,1.,.1]])
    ll=reference_score(y,t,rv,P,4.);scale=2.3
    other=reference_score(scale*y,t,scale*rv,scale*P,4.)
    assert abs(other-(ll-(len(y)-1)*np.log(scale)))<1e-10


def test_ranked_mask_handles_identical_tail_values():
    rv=np.arange(2500,dtype=float)+1;rv[-30:]=rv[-1]
    old=(rv>=np.quantile(rv,.02))&(rv<=np.quantile(rv,.995))
    new=ranked_mask(rv,keep_anchor=False)
    assert (~old).sum()==50 and (~new).sum()==63
    assert np.array_equal(new,ranked_mask(rv,keep_anchor=False))


def test_ranked_mask_does_not_depend_on_model_or_labels():
    rng=np.random.default_rng(378);rv=rng.uniform(.1,2.,2500)
    m=ranked_mask(rv);assert m[0]
    assert 62<=(~m).sum()<=63


def test_all_fixed_kappa_fits_keep_start_score():
    rng=np.random.default_rng(218);t=np.arange(35)/35;y=np.r_[0,np.cumsum(rng.normal(size=34))*.04]
    P=np.array([[0.,0.,.6,.1]]);rv=np.ones(len(t))
    for k in KAPPAS:
        start=log_evaluate(P,y,t,rv,k,True,False)[0]
        m=refine_fixed(P,y,t,rv,'cubic',k,maxiter=10)
        assert m is not None and m['ll']>=start-1e-9


def test_stable_finalizer_uses_written_score_without_optional_geometry():
    t=np.linspace(0,1,100);y=np.r_[0,np.cumsum(np.random.default_rng(92).normal(size=99))*.08]
    P=np.array([[0.,0.,.8,0.]])
    mask=np.ones(100,bool);rv=np.ones(100)
    m=finalize_stable(dict(P=P,kappa=4.),t,y,rv,mask,'affine',False)
    assert m is not None and abs(m['ll']-reference_score(y,t,rv,P,4.))<1e-10
