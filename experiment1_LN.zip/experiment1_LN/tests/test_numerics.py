"""Numerical identities, not tests tuned to the desired scientific conclusion."""
import itertools,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from scipy.special import logsumexp
from scipy.optimize._numdiff import approx_derivative
from scipy.stats import norm
from branches import inverse_scalar,inversion,pair_potentials,pair_forward,pair_gradient,pair_viterbi,evaluate,qv_certificate
from hmm import fb_scaled,fit_hmm
from baselines import segment_variance
from common import local_rv,censor_mask,metrics
from mssv import MIX_Q,MIX_M,MIX_V,latent_pair_potentials,latent_ffbs

def test_inverse_and_affine_limit():
 rng=np.random.default_rng(150)
 for _ in range(2000):
  b=10**rng.uniform(-3,2);r=10**rng.uniform(-16,2);w=rng.uniform(-5,5);rho=b*w+r*w**3;hat=inverse_scalar(rho,b,r)
  assert abs(hat-w)<3e-12*(1+abs(w))
 assert abs(inverse_scalar(1.1,.8,1e-14)-1.1/.8)<1e-12
 assert inverse_scalar(-.7,.5,0)==-1.4

def example():
 rng=np.random.default_rng(171);t=np.arange(9)/8;y=np.r_[0,np.cumsum(rng.normal(size=8))*.12];P=np.array([[0,.1,.8,.2],[.15,-.1,1.2,.05],[.2,.1,.6,.3]]);rv=local_rv(y,t,5)
 return y,t,P,rv

def test_row_normalization_and_enumeration():
 y,t,P,rv=example();w,s,_,_=inversion(y,t,P);L,dq=pair_potentials(w,s,t,rv,4.,True);ll,af,sc,off=pair_forward(L,dq)
 dt=np.diff(t)
 for i in range(len(L)):
  for k in range(3):
   q=np.exp(L[i,k]+.5*dq[i,k]/dt[i]+.5*np.log(2*np.pi*dt[i])+np.log(s[i+1]))
   if np.any(np.isfinite(L[i,k])):assert abs(q.sum()-1)<1e-12
 vals=[]
 for tail in itertools.product(range(3),repeat=8):
  z=(0,)+tail;vals.append(sum(L[i,z[i],z[i+1]] for i in range(8)))
 assert abs(ll-logsumexp(vals))<1e-11
 z,vl=pair_viterbi(L);assert abs(vl-max(vals))<1e-11
 assert ll>=vl-1e-12 # A SUM of the same positive weights cannot be below their maximum.

def test_analytic_gradient():
 rng=np.random.default_rng(4);t=np.arange(80)/80;y=np.r_[0,np.cumsum(rng.normal(size=79))*.07];rv=local_rv(y,t,20);P=np.array([[0,.1,.8,.2],[.15,-.1,1.2,.05]])
 for hard in [False,True]:
  ll,g=evaluate(P,y,t,rv,4.,hard);num=approx_derivative(lambda q:evaluate(q.reshape(2,4),y,t,rv,4.,hard,False)[0],P.ravel(),method='3-point').ravel()
  assert np.linalg.norm(g.ravel()-num)/(1+np.linalg.norm(num))<1e-7

def test_irregular_time_after_censoring():
 t=np.array([0.,.01,.02,.3,.31,.8,1.]);y=np.array([0.,.03,.07,.16,.12,.31,.28]);P=np.array([[0.,.05,.9,0.]])
 w,s,_,_=inversion(y,t,P);L,dq=pair_potentials(w,s,t,np.ones(len(t)),4.,False);ll=pair_forward(L,dq)[0]
 expected=np.sum(norm.logpdf(np.diff(w[:,0]),scale=np.sqrt(np.diff(t)))-np.log(.9))
 assert abs(ll-expected)<1e-12
 wrong=np.sum(norm.logpdf(np.diff(w[:,0]),scale=np.sqrt(1/6))-np.log(.9));assert abs(wrong-expected)>.1

def test_qv_is_not_local_and_bound_is_conservative():
 L=np.zeros((2,2,2));dq=np.zeros_like(L);dq[:,:,1]=1.
 ll=pair_forward(L,dq)[0];vals=[];qs=[]
 for a,b in itertools.product(range(2),repeat=2):vals.append(L[0,0,a]+L[1,a,b]);qs.append(dq[0,0,a]+dq[1,a,b])
 vals=np.array(vals);qs=np.array(qs);ok=(qs>=.7)&(qs<=1.4);constrained=logsumexp(vals[ok]);bad=1-np.exp(constrained-ll)
 assert abs(ll-np.log(4))<1e-12 and abs(constrained-np.log(2))<1e-12
 cert=qv_certificate(L,dq,1.);assert cert['excluded_mass_bound']+1e-12>=bad

def test_chernoff_on_enumerated_paths():
 y,t,P,rv=example();w,s,_,_=inversion(y,t,P);L,dq=pair_potentials(w,s,t,rv,4.,True);ll=pair_forward(L,dq)[0];badlogs=[]
 for tail in itertools.product(range(3),repeat=8):
  z=(0,)+tail;v=sum(L[i,z[i],z[i+1]] for i in range(8));q=sum(dq[i,z[i],z[i+1]] for i in range(8))
  if q<.7 or q>1.4:badlogs.append(v)
 bad=float(np.exp(logsumexp(badlogs)-ll));assert bad<=qv_certificate(L,dq,1.)['excluded_mass_bound']+1e-12

def test_hmm_forward_against_enumeration():
 rng=np.random.default_rng(5);B=rng.uniform(.1,1.,(10,2));A=np.array([[.9,.1],[.2,.8]]);pi=np.array([.3,.7]);ll,ga,xi,af=fb_scaled(B,A,pi);weights=[]
 for z in itertools.product(range(2),repeat=10):weights.append(np.log(pi[z[0]])+np.log(B[0,z[0]])+sum(np.log(A[z[i-1],z[i]])+np.log(B[i,z[i]]) for i in range(1,10)))
 assert abs(ll-logsumexp(weights))<1e-12
 assert np.max(abs(ga.sum(axis=1)-1))<1e-12
 assert abs(xi.sum()-9)<1e-10

def test_em_monotonicity_and_mixture_variance():
 rng=np.random.default_rng(9);x=np.r_[rng.normal(0,.3,160),rng.normal(0,1.2,160)]
 m=fit_hmm(x,2,M=3,restarts=2,seed=82,maxiter=100)
 assert np.min(np.diff(m['history']))>=-1e-5
 expected=np.sum(m['weights']*(m['var']+m['mu']**2),axis=1)-np.sum(m['weights']*m['mu'],axis=1)**2
 assert np.max(abs(m['sigma']**2-expected))<1e-12

def test_change_point_dp_against_enumeration():
 rng=np.random.default_rng(183);x=rng.normal(size=18);pen=2*np.log(len(x));val,ptr=segment_variance(x,pen,3);best=np.inf
 def rec(edges):
  nonlocal best
  end=edges[-1]
  if end==len(x):
   costs=sum((b-a)*np.log(max(np.var(x[a:b]),np.var(x)*1e-8,1e-12)) for a,b in zip(edges[:-1],edges[1:]));best=min(best,costs+pen*(len(edges)-2));return
  for nxt in range(end+3,len(x)+1):
   if nxt<len(x) and len(x)-nxt<3:continue
   rec(edges+[nxt])
 rec([0]);assert abs(val[-1]-best)<1e-10

def test_hungarian_does_not_reward_oversegmentation():
 z=np.array([0,0,1,1]);p=np.array([0,1,2,3]);m=metrics(z,p,np.ones(4),np.ones(4))
 assert m['purity']==1. and m['ACC']==.5 and m['ARI']==0.
 m=metrics(z,1-z,np.ones(4),np.ones(4));assert m['ACC']==1. and m['ARI']==1.

def test_KSC_mixture_centering():
 assert abs(MIX_Q.sum()-1)<1e-12
 mean=np.sum(MIX_Q*MIX_M);variance=np.sum(MIX_Q*(MIX_V+MIX_M*MIX_M))-mean*mean
 assert abs(mean+1.270362845461)<.001
 assert abs(variance-np.pi**2/2)<.02
 assert abs(np.sum(MIX_Q*np.exp(MIX_M+MIX_V/2))-1)<.02

def test_mssv_pair_filter_against_enumeration():
 h=np.array([-.4,-.1,.1,.5,.2,-.1,.2]);mu=np.array([-.5,.6]);A=np.array([[.95,.05],[.03,.97]])
 L,init=latent_pair_potentials(h,mu,.9,.2,A);z,ll=latent_ffbs(L,init);v=[]
 for path in itertools.product(range(2),repeat=len(h)):v.append(init[path[0]]+sum(L[i,path[i],path[i+1]] for i in range(len(h)-1)))
 assert abs(ll-logsumexp(v))<1e-12

def test_large_tilt_log_recursion_against_enumeration():
 from branches import tilted_log_forward
 rng=np.random.default_rng(110);L=rng.normal(size=(6,2,2));dq=rng.uniform(0,1,(6,2,2));L[1,0,1]=-np.inf
 for tilt in [-10000.,-100.,0.,100.,10000.]:
  vals=[]
  for tail in itertools.product(range(2),repeat=6):
   z=(0,)+tail;vals.append(sum(L[i,z[i],z[i+1]]+tilt*dq[i,z[i],z[i+1]] for i in range(6)))
  assert abs(tilted_log_forward(L,dq,tilt)-logsumexp(vals))<1e-8
