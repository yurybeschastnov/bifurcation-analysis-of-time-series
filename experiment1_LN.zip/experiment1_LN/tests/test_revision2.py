"""Revision-2 tests: numerical identities and explicit model-support counterexamples.
Passing these tests does not certify a global optimum or validate strict
singular-only transitions for the local score defined in the paper's §2.3.
"""
import itertools,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from scipy.special import logsumexp
from scipy.optimize._numdiff import approx_derivative
from branches import inversion,pair_potentials,pair_forward,pair_viterbi,KAPPAS
from branches_v2 import log_forward,log_evaluate,log_profile,refine
from geometry_audit import interval_roots,chord_coefficients,cubic_value
from common import local_rv

def test_log_forward_rescues_tiny_path_after_support_change():
    L=np.full((3,2,2),-np.inf)
    L[0,0,0]=0;L[0,0,1]=-1000;L[1,0,0]=0;L[1,1,1]=0;L[2,1,1]=0
    old=pair_forward(L,np.zeros_like(L))[0]
    new,_=log_forward(L)
    assert not np.isfinite(old)
    assert new==-1000

def test_log_forward_matches_exhaustive_paths():
    rng=np.random.default_rng(901);L=rng.normal(size=(7,3,3));L[3,1,0]=-np.inf
    values=[]
    for tail in itertools.product(range(3),repeat=7):
        z=(0,)+tail;values.append(sum(L[i,z[i],z[i+1]] for i in range(7)))
    ll,_=log_forward(L)
    assert abs(ll-logsumexp(values))<1e-11
    assert ll>=pair_viterbi(L)[1]

def test_log_gradient_matches_finite_differences():
    rng=np.random.default_rng(902);t=np.arange(50)/50
    y=np.r_[0.,np.cumsum(rng.normal(size=49))*.04];rv=np.ones(len(t))
    P=np.array([[0.,.1,.7,.3],[.1,-.1,1.,.08]])
    for hard in [False,True]:
        ll,g=log_evaluate(P,y,t,rv,4.,hard)
        assert np.isfinite(ll)
        numerical=approx_derivative(lambda x:log_evaluate(x.reshape(2,4),y,t,rv,4.,hard,False)[0],P.ravel(),method='3-point').ravel()
        assert np.linalg.norm(g.ravel()-numerical)/(1+np.linalg.norm(numerical))<1e-7

def test_kappa_profile_exhausts_all_fourteen_values():
    t=np.arange(30)/30;y=.3*np.sin(4*t);rv=np.ones(len(t))
    P=np.array([[0.,0.,.7,.2],[.1,-.2,1.,.1]])
    ll,kap,grid=log_profile(P,y,t,rv)
    direct=np.array([log_evaluate(P,y,t,rv,k,True,False)[0] for k in KAPPAS])
    assert np.all(np.isfinite(grid))
    assert len(grid)==14
    assert np.max(abs(grid-direct))<1e-11
    assert ll==grid.max() and kap==KAPPAS[grid.argmax()]

def test_local_regularizers_do_not_imply_an_intersection():
    # This deliberately records a limitation of the UNCHANGED §2.3 score.
    P=np.array([[0.,0.,1.,0.],[.01,0.,1.,0.]])
    y=np.array([0.,.01]);t=np.array([0.,.001]);w,s,_,_=inversion(y,t,P)
    L,_=pair_potentials(w,s,t,np.ones(2),4.,True)
    assert np.isfinite(L[0,0,1])
    # Both branches have equal slopes and fixed distinct offsets: no intersection.
    assert len(interval_roots(np.array([-.01,0.,0.,0.])))==0

def test_all_root_detector_finds_double_crossing_missed_by_endpoint_sign():
    p=np.array([0.,0.,2.,0.]);q=np.array([.1,0.,1.,1.])
    coef=chord_coefficients(p,q,0.,1.2,0.,1.)
    assert coef[0]*cubic_value(coef,1.)>0
    roots=interval_roots(coef)
    assert len(roots)==2
    assert max(abs(cubic_value(coef,x)) for x in roots)<1e-12

def test_all_root_detector_includes_tangency_and_endpoint():
    # (x-.3)^2 * (x-1)
    coef=np.polynomial.polynomial.polymul([.09,-.6,1.],[-1.,1.])
    roots=interval_roots(coef)
    assert np.allclose(roots,[.3,1.],atol=1e-9)

def test_cubic_root_detector_against_numpy():
    rng=np.random.default_rng(906)
    for _ in range(300):
        targets=np.sort(rng.uniform(-.3,1.3,3))
        coef=np.polynomial.polynomial.polyfromroots(targets)
        got=interval_roots(coef)
        expected=targets[(targets>=0)&(targets<=1)]
        assert len(got)==len(expected)
        assert np.allclose(got,expected,atol=1e-8)

def test_coarse_no_sign_change_does_not_exclude_hidden_hit():
    # A fine path hits w=0 and returns to the same side before the next observation.
    fine=np.array([-.1,.02,-.1]);p=np.array([0.,0.,1.,0.]);q=np.array([0.,0.,2.,0.])
    coarse=chord_coefficients(p,q,fine[0],fine[-1],0.,1.)
    first=chord_coefficients(p,q,fine[0],fine[1],0.,.5)
    assert len(interval_roots(coarse))==0 and len(interval_roots(first))==1

def test_refinement_does_not_discard_better_start():
    rng=np.random.default_rng(907);t=np.arange(80)/80;y=np.r_[0,np.cumsum(rng.normal(size=79))*.05]
    rv=local_rv(y,t,20);P=np.array([[0.,0.,.8,0.]])
    initial=log_profile(P,y,t,rv)[0]
    result=refine(P,y,t,rv,'affine',maxiter=100)
    assert result is not None and result['ll']>=initial-1e-10

def test_impossible_parallel_switch_is_forbidden_by_singular_support_patch():
    from singular_support import singular_pair_potentials
    P=np.array([[0.,0.,1.,0.],[.01,0.,1.,0.]])
    y=np.array([0.,.01]);t=np.array([0.,.001]);w,s,_,_=inversion(y,t,P)
    L,dq=singular_pair_potentials(P,w,s,t,np.ones(2),4.,True)
    assert not np.isfinite(L[0,0,1])
    assert np.isfinite(L[0,0,0])
    expected=-.5*.01**2/.001-.5*np.log(2*np.pi*.001)
    assert abs(L[0,0,0]-expected)<1e-12

def test_parallel_time_intersection_is_not_automatically_forbidden():
    from singular_support import intersection_possible
    P=np.array([[0.,0.,1.,0.],[.01,-.02,1.,0.]])
    assert not intersection_possible(P,0,1,.1,.2)
    assert intersection_possible(P,0,1,.49,.51)

def test_geometric_exclusion_renormalizes_remaining_destinations():
    from singular_support import singular_pair_potentials
    P=np.array([[0.,0.,1.,0.],[.01,0.,1.,0.],[.02,0.,1.2,.1]])
    y=np.array([0.,.01,.02]);t=np.array([0.,.001,.002]);w,s,_,_=inversion(y,t,P)
    L,dq=singular_pair_potentials(P,w,s,t,np.ones(3),4.)
    logq=L+.5*dq/np.diff(t)[:,None,None]+.5*np.log(2*np.pi*np.diff(t))[:,None,None]+np.log(s[1:])[:,None,:]
    assert np.max(abs(np.exp(logq).sum(axis=2)-1.))<1e-12
    assert np.all(np.isneginf(L[:,0,1]))

def test_qv_certificate_uses_log_reference_for_tiny_reachable_path():
    from stable_inference import qv_certificate_stable
    L=np.full((3,2,2),-np.inf);L[0,0,0]=0;L[0,0,1]=-1000;L[1,0,0]=0;L[1,1,1]=0;L[2,1,1]=0
    dq=np.full_like(L,.5)
    cert=qv_certificate_stable(L,dq,2.)
    assert np.isfinite(cert['loglik_gap_bound'])
    assert cert['excluded_mass_bound']<1e-10

def test_log_forward_rescue_with_bounded_finite_local_weights():
    # Underflow can accumulate even when every finite local log weight is >= -20.
    L=np.full((60,2,2),-np.inf);L[0,0,0]=0.;L[0,0,1]=-20.
    for i in range(1,59):L[i,0,0]=0.;L[i,1,1]=-20.
    L[-1,1,1]=0.
    assert not np.isfinite(pair_forward(L,np.zeros_like(L))[0])
    assert log_forward(L)[0]==-1180.
