"""ONLY validation reads truth. No model is refitted or selected here.
Results on full grid are primary; common retained-grid scores are supplemental.
"""
import json,pickle,hashlib,sys
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment
from statsmodels.stats.diagnostic import acorr_ljungbox
from common import ROOT,prepare,metrics,dumps

def run_validation():
 # Freeze existing inference outputs before opening ground truth.
 files=sorted((ROOT/'results').glob('*_branches.pkl'))+sorted((ROOT/'results').glob('*_baselines.pkl'))+sorted((ROOT/'results').glob('*_mssv.pkl'))
 manifest={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
 (ROOT/'results'/'inference_frozen_sha256.json').write_text(dumps(manifest))
 rows=[];branches_summary=[];paramrows=[];driverrows=[];diagnostics=[];generation=json.loads((ROOT/'truth'/'generation_audit.json').read_text())
 for data in sorted((ROOT/'data').glob('*.npz')):
  name=data.stem;f=np.load(data);t,y,T,scale=prepare(f['t'],f['y']);truth=np.load(ROOT/'truth'/f'{name}.npz');zt=truth['z'];st=truth['sigma']*np.sqrt(T)/scale;K=len(truth['parameters'])
  with open(ROOT/'results'/f'{name}_branches.pkl','rb') as h:b=pickle.load(h)
  with open(ROOT/'results'/f'{name}_baselines.pkl','rb') as h:models=pickle.load(h)
  models={'Branches':b['selected'],**models}
  mp=ROOT/'results'/f'{name}_mssv.pkl'
  if mp.exists():
   with open(mp,'rb') as h:models['MSSV']=pickle.load(h)['selected']
  mask=b['mask']
  for method,m in models.items():
   for grid,sel in [('full',np.ones(len(t),bool)),('common_retained',mask)]:
    z=m['labels'][sel] if len(m['labels']) else np.array([],int);scores=metrics(zt[sel],z,st[sel],m['volatility'][sel])
    row=dict(series=name,family=str(f['family']),method=method,grid=grid,n=int(sel.sum()),K_true=K,K_hat=m['K'],K_correct=None if m['K'] is None else m['K']==K,**scores);rows.append(row)
  m=b['selected'];score=metrics(zt,m['labels'],st,m['volatility']);branches_summary.append(dict(series=name,K_true=K,K_hat=m['K'],**score,BIC_gap=m['BIC_gap'],QV=m['QV'],QV_excluded_mass_bound=m['certificate']['excluded_mass_bound'],QV_selection_certified=m['QV_selection_certified_at_fitted_candidates']))
  # Parameter comparison after ONE-TO-ONE label matching, in original units.
  C=np.zeros((K,m['K']),int);np.add.at(C,(zt,m['labels']),1);a,bb=linear_sum_assignment(-C);P=m['P'].copy();original=np.column_stack([scale*P[:,0]+f['y'][0],scale*P[:,1]/T,scale*P[:,2]/np.sqrt(T),scale*P[:,3]/(3*T**1.5)])
  for j,k in zip(a,bb):
   for q,key in enumerate(['c','a','b','r']):paramrows.append(dict(series=name,true_branch=int(j),estimated_branch=int(k),parameter=key,true=float(truth['parameters'][j,q]),estimated=float(original[k,q]),error=float(original[k,q]-truth['parameters'][j,q])))
  wt=truth['w']/np.sqrt(T);wh=m['driver'];design=np.column_stack([np.ones(len(t)),wh]);coef=np.linalg.lstsq(design,wt,rcond=None)[0];res=wt-design@coef
  design2=np.column_stack([np.ones(len(t)),wh,t]);coef2=np.linalg.lstsq(design2,wt,rcond=None)[0];res2=wt-design2@coef2
  driverrows.append(dict(series=name,correlation=float(np.corrcoef(wt,wh)[0,1]),relative_residual_shift_scale=float(np.linalg.norm(res)/np.linalg.norm(wt-wt.mean())),relative_residual_shift_scale_time=float(np.linalg.norm(res2)/np.linalg.norm(wt-wt.mean())),shift=float(coef[0]),scale=float(coef[1])))
  for cand in b['candidates']:
   if cand is None:continue
   inc=np.diff(cand['retained_driver'])/np.sqrt(np.diff(cand['retained_t']));lb=acorr_ljungbox(inc,lags=[10],return_df=True);lb2=acorr_ljungbox(inc*inc,lags=[10],return_df=True)
   diagnostics.append(dict(series=name,K=cand['K'],selected=cand['K']==m['K'],QV_retained=cand['QV'],QV_full=float(np.sum(np.diff(cand['driver'])**2)),Ljung_Box_p=float(lb['lb_pvalue'].iloc[0]),Ljung_Box_squared_p=float(lb2['lb_pvalue'].iloc[0]),QV_excluded_mass_bound=cand['certificate']['excluded_mass_bound'],loglik_gap_bound=cand['certificate']['loglik_gap_bound'],ll=cand['ll'],BIC=cand['BIC']))
 df=pd.DataFrame(rows);df.to_csv(ROOT/'results'/'metrics_all.csv',index=False)
 summ=pd.DataFrame(branches_summary);summ.to_csv(ROOT/'results'/'branch_summary.csv',index=False)
 pd.DataFrame(paramrows).to_csv(ROOT/'results'/'parameter_errors.csv',index=False);pd.DataFrame(driverrows).to_csv(ROOT/'results'/'driver_validation.csv',index=False);pd.DataFrame(diagnostics).to_csv(ROOT/'results'/'driver_diagnostics_all_models.csv',index=False)
 full=df[df.grid=='full'];agg=[]
 for (family,method),g in full.groupby(['family','method'],sort=False):agg.append(dict(family=family,method=method,n_series=len(g),K_correct=int(g.K_correct.eq(True).sum()) if g.K_hat.notna().any() else None,ARI_mean=g.ARI.mean(),ARI_median=g.ARI.median() if g.ARI.notna().any() else np.nan,ACC_mean=g.ACC.mean(),EL2_mean=g.EL2.mean(),EL2_median=g.EL2.median(),Elog_mean=g.Elog.mean()))
 pd.DataFrame(agg).to_csv(ROOT/'results'/'comparison_summary.csv',index=False)
 # All windows retained; the oracle best-RV window is not treated as a deployable competitor.
 bb=full[full.method=='Branches'].set_index('series');pairs=[]
 for meth,g in full[full.method!='Branches'].groupby('method'):
  for family,h in g.groupby('family'):
   for metric,direction in [('ARI',1),('EL2',-1)]:
    left=bb.loc[h.series,metric].to_numpy();right=h[metric].to_numpy();valid=np.isfinite(left)&np.isfinite(right);delta=direction*(left[valid]-right[valid]);pairs.append(dict(family=family,baseline=meth,metric=metric,n=len(delta),branch_wins=int(np.sum(delta>.001)),ties=int(np.sum(abs(delta)<=.001)),branch_losses=int(np.sum(delta<-.001)),mean_advantage=float(delta.mean()) if len(delta) else None))
 pd.DataFrame(pairs).to_csv(ROOT/'results'/'pairwise_comparison.csv',index=False)
 print(summ.to_string(index=False));print('\nAGGREGATE\n',pd.DataFrame(agg).to_string(index=False))
 return df,summ
if __name__=='__main__':run_validation()
