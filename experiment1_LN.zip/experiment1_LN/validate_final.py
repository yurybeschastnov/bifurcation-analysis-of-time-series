"""Independent recomputation, frozen-data audit, metrics, and portable exports.
Truth is first opened after the hashes of all numerical fits have been saved.
"""
from __future__ import annotations
import json,pickle,hashlib,sys,platform,ast
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment
from statsmodels.stats.diagnostic import acorr_ljungbox
from common import ROOT,prepare,local_rv,censor_mask,metrics,dumps
from branches import inversion,pair_potentials
from branches_v2 import log_forward,log_profile,log_evaluate
from audit_reference import reference_score
from censoring_exact import ranked_mask
from stable_inference import finalize_stable
BASE=ROOT/'revision3';OUT=BASE/'final';OUT.mkdir(exist_ok=True);MODEL=BASE/'final_models';NAMES=[f'L{i}' for i in range(1,7)]+[f'N{i}' for i in range(1,8)]
PAPER_SWITCHES=[0,8,10,9,12,20,13,12,11,13,11,8,15]


def main():
    (OUT/'predictions').mkdir(exist_ok=True)
    fs=[ROOT/'data'/f'{n}.npz' for n in NAMES]+[MODEL/f'{n}_branches.pkl' for n in NAMES]
    if any(not p.exists() for p in fs):raise RuntimeError('Incomplete estimation: run_revision3.py first')
    frozen={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in fs}
    (OUT/'frozen_before_scoring_sha256.json').write_text(dumps(frozen),encoding='utf-8')
    rows=[];models_rows=[];checkrows=[];params=[];dynamics=[];comparisons=[];schema=[];diagnostics=[]
    gen={g['series']:g for g in json.loads((ROOT/'truth/generation_audit.json').read_text())}
    for name,target_switches in zip(NAMES,PAPER_SWITCHES):
        f=np.load(ROOT/'data'/f'{name}.npz',allow_pickle=False)
        assert set(f.files)=={'t','y','family'}
        schema.append(dict(series=name,estimator_input_fields=f.files,truth_fields_in_input=False))
        assert frozen[f'data/{name}.npz']==gen[name]['data_sha256']
        t,y,T,scale=prepare(f['t'],f['y']);rv=local_rv(y,t,40);family=str(f['family'])
        fit=pickle.load(open(MODEL/f'{name}_branches.pkl','rb'));v2=pickle.load(open(ROOT/'revision2'/f'{name}_branches.pkl','rb'))
        mask=fit['mask'];expected=ranked_mask(rv);assert np.array_equal(mask,expected)
        truth=np.load(ROOT/'truth'/f'{name}.npz',allow_pickle=False);Ktrue=len(truth['parameters'])
        selected=fit['selected'];selected_v2=v2['selected']
        ll_sequence=[]
        for m,old in zip(fit['candidates'],v2['candidates']):
            ref,Lr,wr,sr,qr=reference_score(y[mask],t[mask],rv[mask],m['P'],m['kappa'],True)
            w,s,_,_=inversion(y[mask],t[mask],m['P']);L,_=pair_potentials(w,s,t[mask],rv[mask],m['kappa'],True)
            assert np.array_equal(np.isfinite(Lr),np.isfinite(L))
            lerr=abs(ref-m['ll']);assert lerr<1e-7
            ierr=float(np.max(np.abs(wr-w)));assert ierr<1e-8
            finite=np.isfinite(L);perr=float(np.max(abs(Lr[finite]-L[finite]),initial=0));assert perr<1e-6
            row_sum=qr.sum(axis=2);qerr=float(np.max(abs(row_sum[row_sum>0]-1),initial=0))
            pp,kap,grid=log_profile(m['P'],y[mask],t[mask],rv[mask]);assert abs(pp-m['ll'])<1e-7
            bic=-2*ref+(3 if family=='affine' else 4)*m['K']*np.log(mask.sum());assert abs(bic-m['BIC'])<1e-7
            ll_sequence.append(ref)
            met=metrics(truth['z'],m['labels'],truth['sigma'],m['volatility']*scale/np.sqrt(T))
            models_rows.append(dict(series=name,K=m['K'],ll=m['ll'],BIC=m['BIC'],kappa=m['kappa'],old_ll=old['ll'],same_mask_as_v2=bool(np.array_equal(mask,v2['mask'])),likelihood_gain=(m['ll']-old['ll']) if np.array_equal(mask,v2['mask']) else np.nan,**met))
            checkrows.append(dict(series=name,K=m['K'],independent_LL_error=lerr,independent_inverse_error=ierr,local_potential_error=perr,q_row_sum_error=qerr,QV=m['QV'],QV_valid=m['QV_valid'],QV_excluded_mass_bound=m['certificate']['excluded_mass_bound']))
            dw=np.diff(m['retained_driver'])/np.sqrt(np.diff(m['retained_t']))
            for square in [False,True]:
                x=dw*dw if square else dw
                pv=float(acorr_ljungbox(x,lags=[10],return_df=True).lb_pvalue.iloc[0])
                diagnostics.append(dict(series=name,K=m['K'],selected=m['K']==selected['K'],squared=square,Ljung_Box_p=pv))
        assert np.min(np.diff(ll_sequence))>-1e-7
        # Applying the paper's narrower K+2 search to the SAME candidates is a
        # diagnostic only; the actual estimator still does not see true K.
        restricted=min(fit['candidates'][:Ktrue+2],key=lambda m:m['BIC'])
        assert restricted['K']==selected['K']
        met=metrics(truth['z'],selected['labels'],truth['sigma'],selected['volatility']*scale/np.sqrt(T))
        met2=metrics(truth['z'],selected_v2['labels'],truth['sigma'],selected_v2['volatility']*scale/np.sqrt(T))
        comparisons.append(dict(series=name,K_true=Ktrue,K_v2=selected_v2['K'],K_v3=selected['K'],ARI_v2=met2['ARI'],ARI_v3=met['ARI'],ACC_v3=met['ACC'],EL2_v2=met2['EL2'],EL2_v3=met['EL2'],same_mask_as_v2=bool(np.array_equal(mask,v2['mask'])),ll_v2=selected_v2['ll'],ll_v3=selected['ll'],BIC_gap=selected['BIC_gap']))
        bases=pickle.load(open(ROOT/'results'/f'{name}_baselines.pkl','rb'))
        mpath=ROOT/'results'/f'{name}_mssv.pkl'
        if mpath.exists():bases['MSSV']=pickle.load(open(mpath,'rb'))['selected']
        variants=pickle.load(open(BASE/'baseline_variants'/f'{name}.pkl','rb'))['predictions']
        evaluated={'Branches_final':selected,**bases,**variants}
        arrays=dict(t=f['t'],y=f['y'],t_working=t,y_working=y,true_labels=truth['z'],true_sigma=truth['sigma'],true_driver=truth['w'],true_parameters=truth['parameters'],mask=mask,P_c_a_b_d=selected['P'],driver_working=selected['driver'])
        for method,m in evaluated.items():
            sigma=m['volatility']*scale/np.sqrt(T);z=m['labels']
            for grid,idx in [('full',np.ones(len(t),bool)),('common_retained',mask)]:
                rows.append(dict(series=name,family=family,method=method,grid=grid,K_true=Ktrue,K_hat=m['K'],K_correct=None if m['K'] is None else m['K']==Ktrue,**metrics(truth['z'][idx],z[idx] if len(z) else z,truth['sigma'][idx],sigma[idx])))
            arrays[f'{method}_labels']=z;arrays[f'{method}_sigma']=sigma;arrays[f'{method}_K']=np.array(-1 if m['K'] is None else m['K'])
        np.savez_compressed(OUT/'predictions'/f'{name}.npz',**arrays)
        C=np.zeros((Ktrue,selected['K']),int);np.add.at(C,(truth['z'],selected['labels']),1);a,b=linear_sum_assignment(-C)
        P=selected['P'];orig=np.column_stack([scale*P[:,0]+f['y'][0],scale*P[:,1]/T,scale*P[:,2]/np.sqrt(T),scale*P[:,3]/(3*T**1.5)])
        for j,k in zip(a,b):
            for q,key in enumerate(['c','a','b','r']):params.append(dict(series=name,true_branch=int(j),estimated_branch=int(k),parameter=key,true=truth['parameters'][j,q],estimated=orig[k,q]))
        for j in range(Ktrue):
            ix=truth['z']==j;s=truth['sigma'][ix];w=truth['w'][ix]
            dynamics.append(dict(series=name,branch=j,occupancy_time=gen[name]['occupancy_time'][j],occupancy_points=float(ix.mean()),switches_realization=gen[name]['switches'],switches_article=target_switches,sigma_min=float(s.min()),sigma_max=float(s.max()),sigma_coefficient_of_variation=float(s.std()/s.mean()),W_min=float(w.min()),W_max=float(w.max())))
    for filename,data in [('metrics_all.csv',rows),('comparison_v2_v3.csv',comparisons),('all_K.csv',models_rows),('numerical_reference.csv',checkrows),('parameter_estimates.csv',params),('trajectory_geometry.csv',dynamics),('driver_diagnostics_all_K.csv',diagnostics)]:pd.DataFrame(data).to_csv(OUT/filename,index=False)
    main=pd.DataFrame(rows);pairwise=[]
    for group in ['L','N']:
        part=main[(main.grid=='full')&main.series.str.startswith(group)];our=part[part.method=='Branches_final'].set_index('series')
        for method,sub in part[part.method!='Branches_final'].groupby('method'):
            other=sub.set_index('series');ids=our.index.intersection(other.index)
            for metric,sgn in [('ARI',1),('ACC',1),('EL2',-1)]:
                d=sgn*(our.loc[ids,metric]-other.loc[ids,metric]);d=d[np.isfinite(d)]
                pairwise.append(dict(group=group,method=method,metric=metric,n=len(d),wins=int((d>.001).sum()),ties=int((abs(d)<=.001).sum()),losses=int((d<-.001).sum())))
    pd.DataFrame(pairwise).to_csv(OUT/'pairwise.csv',index=False)
    checks=pd.DataFrame(checkrows);comp=pd.DataFrame(comparisons)
    (OUT/'input_schema.json').write_text(dumps(schema),encoding='utf-8')
    import scipy,numba,sklearn,matplotlib,statsmodels
    summary=dict(n_models=78,n_series=13,all_input_data_hashes_unchanged=True,censoring_policy="ranked empirical tails, anchor retained",number_of_changed_masks_vs_v2=1,
                 K_correct=int((comp.K_true==comp.K_v3).sum()),K_changed_vs_v2=int((comp.K_v2!=comp.K_v3).sum()),
                 max_independent_score_error=float(checks.independent_LL_error.max()),max_independent_inverse_error=float(checks.independent_inverse_error.max()),
                 max_local_potential_error=float(checks.local_potential_error.max()),max_transition_normalization_error=float(checks.q_row_sum_error.max()),
                 max_selected_likelihood_gain=float((comp.ll_v3-comp.ll_v2).max()),
                 extra_parameter_penalties=False,extra_geometry_filter_in_primary=False,
                 kappa_grid_optimized_separately=True,global_optimum_certified=False,
                 known_family=True,true_K_provided_to_fit=False,
                 narrower_Kplus2_diagnostic_changes_selection=False,
                 versions={m.__name__:m.__version__ for m in [np,scipy,numba,sklearn,pd,matplotlib,statsmodels]},python=sys.version)
    (OUT/'summary.json').write_text(dumps(summary),encoding='utf-8')
    print(comp.to_string(index=False));print(dumps(summary))
if __name__=='__main__':main()
