"""Post-fit audit. Freezes model and data hashes BEFORE reading ground truth.
Does not optimize parameters, tune hyperparameters or regenerate observations.
"""
from pathlib import Path
import json,pickle,hashlib,platform
import numpy as np
import pandas as pd
from common import ROOT,prepare,local_rv,metrics,dumps
from branches import inversion,pair_potentials,pair_forward
from branches_v2 import log_forward,log_evaluate
from singular_support import singular_pair_potentials
from stable_inference import finalize_stable

OUT=ROOT/'revision2'
NAMES=[f'L{i}' for i in range(1,7)]+[f'N{i}' for i in range(1,8)]

def main():
    paths=[ROOT/'data'/f'{n}.npz' for n in NAMES]+[OUT/f'{n}_branches.pkl' for n in NAMES]
    missing=[str(p) for p in paths if not p.exists()]
    if missing:raise RuntimeError('Unfinished fits: '+', '.join(missing))
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    codepaths=[ROOT/p for p in ['branches.py','branches_v2.py','run_revision2.py','singular_support.py','stable_inference.py','geometry_audit.py']]
    hashes.update({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in codepaths})
    (OUT/'frozen_before_validation_sha256.json').write_text(dumps(hashes))
    (OUT/'predictions').mkdir(exist_ok=True);(OUT/'stable_models').mkdir(exist_ok=True)
    comparisons=[];modelrows=[];regrows=[];newmetrics=[];max_kernel_diff=0.;max_log_vs_scaled=0.
    # All truth access begins here, after the parameter freeze.
    generation={v['series']:v for v in json.loads((ROOT/'truth/generation_audit.json').read_text())}
    baselines=pd.read_csv(ROOT/'results/metrics_all.csv');oldmain=baselines[(baselines.method=='Branches')&(baselines.grid=='full')].set_index('series')
    baseline_names=[m for m in baselines.method.unique() if m!='Branches' and not m.startswith('RV')]
    for name in NAMES:
        f=np.load(ROOT/'data'/f'{name}.npz');truth=np.load(ROOT/'truth'/f'{name}.npz')
        prior=pickle.load(open(ROOT/'results'/f'{name}_branches.pkl','rb'));raw=pickle.load(open(OUT/f'{name}_branches.pkl','rb'))
        t,y,T,scale=prepare(f['t'],f['y']);rv=local_rv(y,t,40);mask=raw['mask'];family=str(f['family'])
        assert hashes[f'data/{name}.npz']==generation[name]['data_sha256']
        assert np.array_equal(mask,prior['mask'])
        candidates=[]
        for old in raw['candidates']:
            if old is None:continue
            unguarded=finalize_stable(old,t,y,rv,mask,family,False)
            guarded=finalize_stable(old,t,y,rv,mask,family,True)
            if guarded is None:raise RuntimeError('Guard made a reported candidate impossible')
            max_kernel_diff=max(max_kernel_diff,abs(unguarded['ll']-guarded['ll']))
            if np.any(unguarded['labels']!=guarded['labels']):raise RuntimeError('Guard changed labels; requires explicit analysis')
            m=guarded;candidates.append(m)
            score=metrics(truth['z'],m['labels'],truth['sigma'],m['volatility']*scale/np.sqrt(T))
            modelrows.append(dict(series=name,K=m['K'],ll=m['ll'],BIC=m['BIC'],
                                  QV=m['QV'],kappa=m['kappa'],source=m['source'],
                                  excluded_QV_mass_bound=m['certificate']['excluded_mass_bound'],
                                  **score))
        selected=min(candidates,key=lambda m:m['BIC'])
        cert=selected['certificate'];gap=min(m['BIC'] for m in candidates if m['K']!=selected['K'])-selected['BIC']
        qv_certified=selected['BIC']+2*cert['loglik_gap_bound']<min(m['BIC'] for m in candidates if m['K']!=selected['K'])
        raw_ll_delta=selected['ll']-raw['selected']['ll']
        assert abs(raw_ll_delta)<1e-7 and selected['K']==raw['selected']['K']
        selected['BIC_gap']=gap
        with open(OUT/'stable_models'/f'{name}.pkl','wb') as fp:pickle.dump(dict(selected=selected,candidates=candidates),fp)
        sigma=selected['volatility']*scale/np.sqrt(T)
        met=metrics(truth['z'],selected['labels'],truth['sigma'],sigma)
        row=dict(series=name,K_true=len(truth['parameters']),old_K=int(oldmain.loc[name,'K_hat']),new_K=selected['K'],
                 old_ARI=float(oldmain.loc[name,'ARI']),new_ARI=met['ARI'],old_ACC=float(oldmain.loc[name,'ACC']),new_ACC=met['ACC'],
                 old_EL2=float(oldmain.loc[name,'EL2']),new_EL2=met['EL2'],old_ll=prior['selected']['ll'],new_ll=selected['ll'],
                 likelihood_gain=selected['ll']-prior['selected']['ll'],BIC_gap=gap,kappa=selected['kappa'],
                 balance_error=generation[name]['max_balance_error'],observed_switches=generation[name]['observed_switches'])
        et=baselines[(baselines.series==name)&(baselines.grid=='full')&(baselines.method.isin(baseline_names))]
        for metric,func in [('ARI','idxmax'),('ACC','idxmax'),('EL2','idxmin')]:
            best=et.loc[getattr(et[metric],func)()];row['best_baseline_'+metric]=best[metric];row['best_baseline_'+metric+'_name']=best['method']
        comparisons.append(row)
        for grid,ids in [('full',np.ones(len(t),bool)),('common_retained',mask)]:
            sc=metrics(truth['z'][ids],selected['labels'][ids],truth['sigma'][ids],sigma[ids])
            newmetrics.append(dict(series=name,family=family,method='Branches_v2',grid=grid,n=int(ids.sum()),
                                   K_true=len(truth['parameters']),K_hat=selected['K'],K_correct=selected['K']==len(truth['parameters']),**sc))
        w,s,_,_=inversion(y[mask],t[mask],selected['P']);L,dq=singular_pair_potentials(selected['P'],w,s,t[mask],rv[mask],selected['kappa'])
        logq=L+.5*dq/np.diff(t[mask])[:,None,None]+.5*np.log(2*np.pi*np.diff(t[mask]))[:,None,None]+np.log(s[1:])[:,None,:]
        sums=np.exp(logq).sum(axis=2);nonempty=sums>0
        qerr=float(abs(sums[nonempty]-1.).max(initial=0.))
        regrows.append(dict(series=name,K=selected['K'],n_retained=int(mask.sum()),censored_fraction=float(1-mask.mean()),
                            kappa=selected['kappa'],QV=selected['QV'],QV_valid=selected['QV_valid'],
                            QV_excluded_mass_bound=cert['excluded_mass_bound'],QV_loglik_gap_bound=cert['loglik_gap_bound'],
                            QV_selection_certified_at_found_candidates=qv_certified,
                            max_transition_row_sum_error=qerr,logsum_minus_max_path=selected['ll']-selected['viterbi_ll']))
        for old in prior['candidates']:
            if old is None:continue
            wo,so,_,_=inversion(y[mask],t[mask],old['P']);Lo,dqo=pair_potentials(wo,so,t[mask],rv[mask],old['kappa'])
            max_log_vs_scaled=max(max_log_vs_scaled,abs(log_forward(Lo)[0]-pair_forward(Lo,dqo)[0]))
        np.savez_compressed(OUT/'predictions'/f'{name}.npz',t=f['t'],y=f['y'],labels=selected['labels'],
                            sigma=sigma,P_c_a_b_d_working=selected['P'],mask=mask,K_hat=selected['K'],
                            true_labels=truth['z'],true_sigma=truth['sigma'],true_parameters=truth['parameters'])
    compare=pd.DataFrame(comparisons);allmodels=pd.DataFrame(modelrows);regs=pd.DataFrame(regrows)
    compare.to_csv(OUT/'comparison_all.csv',index=False)
    compare[compare.series.str.startswith('N')].to_csv(OUT/'comparison_N.csv',index=False)
    compare[compare.series.str.startswith('L')].to_csv(OUT/'comparison_L.csv',index=False)
    allmodels.to_csv(OUT/'model_selection_all_K.csv',index=False);regs.to_csv(OUT/'regularizer_audit.csv',index=False)
    main=pd.DataFrame(newmetrics);baselines['method']=baselines['method'].replace({'Branches':'Branches_v1'})
    combined=pd.concat([baselines,main],ignore_index=True);combined.to_csv(OUT/'metrics_all_v1_v2_baselines.csv',index=False)
    rows=[]
    for group in ['L','N']:
        part=combined[(combined.grid=='full')&combined.series.str.startswith(group)]
        for method,sub in part.groupby('method',sort=False):
            rows.append(dict(group=group,method=method,n_series=len(sub),K_correct=int(sub.K_correct.fillna(False).sum()),
                             mean_ARI=sub.ARI.mean(),median_ARI=sub.ARI.median(),mean_ACC=sub.ACC.mean(),mean_EL2=sub.EL2.mean(),median_EL2=sub.EL2.median()))
    pd.DataFrame(rows).to_csv(OUT/'aggregate_comparison.csv',index=False)
    pairwise=[]
    for group in ['L','N']:
        for method in baseline_names:
            ours=main[(main.grid=='full')&main.series.str.startswith(group)].set_index('series')
            other=combined[(combined.grid=='full')&combined.series.str.startswith(group)&(combined.method==method)].set_index('series')
            ids=ours.index.intersection(other.index)
            if not len(ids):continue
            for metric in ['ARI','ACC','EL2']:
                d=(ours.loc[ids,metric]-other.loc[ids,metric])*(1 if metric!='EL2' else -1)
                pairwise.append(dict(group=group,baseline=method,metric=metric,wins=int((d>.001).sum()),
                                     ties=int((abs(d)<=.001).sum()),losses=int((d<-.001).sum()),n=len(ids)))
    pd.DataFrame(pairwise).to_csv(OUT/'pairwise_comparison.csv',index=False)
    summary=dict(data_unchanged=True,seed_unchanged=True,censor_masks_unchanged=True,baseline_estimates_unchanged=True,
                 no_truth_access_in_fitting=True,geometric_guard_max_ll_change_at_reported_candidates=max_kernel_diff,
                 old_forward_vs_log_max_difference_at_old_candidates=max_log_vs_scaled,
                 all_QV_selection_certificates=bool(regs.QV_selection_certified_at_found_candidates.all()),
                 max_QV_loglik_gap_bound=float(regs.QV_loglik_gap_bound.max()),
                 max_q_row_sum_error=float(regs.max_transition_row_sum_error.max()),
                 correct_K=int((compare.new_K==compare.K_true).sum()),n_series=len(compare),
                 hypotheses='Debugging on the same observed sample; no independent out-of-sample scientific claim')
    (OUT/'validation_summary.json').write_text(dumps(summary))
    print(compare.to_string(index=False));print(dumps(summary))
if __name__=='__main__':main()
