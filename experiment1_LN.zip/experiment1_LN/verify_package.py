"""Verify the delivered archive against MANIFEST_SHA256.json, without pickle loads.
Run before regenerating reports or estimates, since those are intentionally mutable.
"""
from pathlib import Path
import hashlib
import json
import sys
ROOT = Path(__file__).resolve().parent

def main() -> None:
    manifest = ROOT/'MANIFEST_SHA256.json'
    if not manifest.is_file():
        raise SystemExit('MANIFEST_SHA256.json is missing; use the complete archive.')
    hashes = json.loads(manifest.read_text(encoding='utf-8'))['files']
    errors=[]
    for name, expected in hashes.items():
        path=ROOT/name
        if not path.is_file():
            errors.append(f'MISSING {name}')
        elif hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
            errors.append(f'CHANGED {name}')
    if errors:
        print('\n'.join(errors))
        print('Refitting/replotting modifies output files legitimately; use a fresh extraction to check delivery integrity.')
        sys.exit(1)
    print(f'PASS: {len(hashes)} files match the delivered SHA-256 manifest.')

if __name__=='__main__':
    main()
