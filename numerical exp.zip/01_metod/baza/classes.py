"""Три вложенных класса ветвей: аффинные, квадратичные, кубические (монотонные)."""
import numpy as np, sys
sys.path.insert(0,'/home/claude/work')
import msde as M, synth as S, synth3 as S3, pipeline as P
from scipy.optimize import minimize

SPEC={'aff':  dict(np_=3, deg=1, build=lambda br,B,N:(S.nu_from_branches(br,B,N)[0],1)),
      'skew': dict(np_=5, deg=3, build=lambda br,B,N: S3.nu_from_sbranches(br,B,N)),
      'quad': dict(np_=4, deg=2, build=lambda br,B,N: S3.nu_from_qbranches(br,B,N)),
      'cub':  dict(np_=4, deg=3, build=lambda br,B,N: S3.nu_from_cbranches(br,B,N))}

def budget(kind,N): return SPEC[kind]['deg']*N

def basis_of(kind,N):
    D=budget(kind,N); return M.basis(N,D),D

def nu_of(kind,br,B,N): return SPEC[kind]['build'](br,B,N)[0]

def crit_of(kind,Y,t,dt,br,N,keep=None,bref=None):
    B,D=basis_of(kind,N)
    nu,need=SPEC[kind]['build'](br,B,N)
    if need>D: return -np.inf,None
    return P.crit(Y,t,dt,nu,B,N,D=D,keep=keep,bref=bref),nu

def project(br,kind):
    """Проекция на допустимое множество кубического класса: b>0 и r>=0.
    Это обеспечивает монотонность каждой ветви на всей прямой. Общая смена знака
    всех b есть симметрия W -> -W, поэтому ограничение b>0 содержательно означает,
    что все режимы откликаются на общий шок в одну сторону."""
    if kind=='cub':
        out=[]
        for g in br:
            c_,a_,b_,r_=g
            out.append((c_,a_,abs(b_) if abs(b_)>1e-6 else 1e-6,max(r_,0.0)))
        return out
    if kind=='skew':
        # монотонность g на всей прямой: b>0, r>=0 и q^2 < 3 b r
        out=[]
        for g in br:
            c_,a_,b_,q_,r_=g
            b_=abs(b_) if abs(b_)>1e-6 else 1e-6
            r_=max(r_,0.0)
            lim=np.sqrt(max(3*b_*r_,0.0))*0.999
            q_=float(np.clip(q_,-lim,lim))
            out.append((c_,a_,b_,q_,r_))
        return out
    return [tuple(g) for g in br]


def to_kind(br,kind):
    """Расширение параметров ветви до нужного класса (высшие члены нулевые)."""
    p=SPEC[kind]['np_']
    return [tuple(list(g[:3])+[0.0]*(p-3)) for g in br]

def fit(kind,Y,t,dt,N,keep=None,br0=None,maxiter=110,grid=None,sweeps=2,verbose=False,bref=None):
    import init_branches as I
    B,D=basis_of(kind,N); p=SPEC[kind]['np_']
    if br0 is None:
        a0,_,_,_=I.init_from_data(Y,t,dt,N,h=40)
        br0=to_kind(a0,kind)
    def val(bs):
        v,_=crit_of(kind,Y,t,dt,bs,N,keep,bref); return v
    br=project(br0,kind); best=val(br)
    if p>=4 and grid is not None:
        for _ in range(sweeps):
            for j in range(N):
                cur=br[j]; loc=(best,cur[3])
                for r in grid:
                    if kind=='cub' and r<0: continue
                    cand=list(br); cand[j]=tuple(list(cur[:3])+[float(r)]+list(cur[4:])) if p==5 else (cur[0],cur[1],cur[2],float(r))
                    cand=project(cand,kind); v=val(cand)
                    if v>loc[0]: loc=(v,float(r))
                nb=list(cur); nb[3]=max(loc[1],0.0) if kind in ('cub','skew') else loc[1]
                br[j]=tuple(nb)
                br=project(br,kind); best=loc[0]
            br,best=_refine(kind,Y,t,dt,br,N,keep,maxiter,best,bref)
    else:
        br,best=_refine(kind,Y,t,dt,br,N,keep,maxiter,best,bref)
    br=project(br,kind); nu=nu_of(kind,br,B,N)
    n=len(Y)-1; k=p*N-1
    return dict(kind=kind,N=N,branches=br,nu=nu,B=B,D=D,ll=float(best),k=k,
                bic=float(-2*best+k*np.log(n)))

def _refine(kind,Y,t,dt,br,N,keep,maxiter,best,bref=None):
    p=SPEC[kind]['np_']
    sc=np.array(({3:[1.,3.,1.],4:[1.,3.,1.,1.],5:[1.,3.,1.,1.,1.]}[p])*N)
    x0=np.array([v for g in br for v in g])*sc
    def neg(x):
        bs=project([tuple(x[p*i:p*i+p]/sc[p*i:p*i+p]) for i in range(N)],kind)
        if min(abs(g[2]) for g in bs)<1e-3: return 1e6
        v,_=crit_of(kind,Y,t,dt,bs,N,keep,bref)
        return 1e6 if not np.isfinite(v) else -v/len(Y)
    g=P._Best(neg); g(x0)
    minimize(g,x0,method='Nelder-Mead',options=dict(maxiter=maxiter*4,maxfev=maxiter*8,xatol=1e-6,fatol=1e-9))
    minimize(g,g.x,method='L-BFGS-B',options=dict(maxiter=maxiter,eps=1e-5,ftol=1e-15))
    bs=project([tuple(g.x[p*i:p*i+p]/sc[p*i:p*i+p]) for i in range(N)],kind)
    v,_=crit_of(kind,Y,t,dt,bs,N,keep,bref)
    return (bs,v) if v>best else (br,best)
