import numpy as np, sys
sys.path.insert(0,'/home/claude/work')
import msde as M

def kmeans1d(x,q,iters=200,seed=0):
    rng=np.random.default_rng(seed)
    c=np.quantile(x,np.linspace(0.1,0.9,q))
    for _ in range(iters):
        lab=np.argmin(np.abs(x[:,None]-c[None,:]),axis=1)
        cn=np.array([x[lab==k].mean() if (lab==k).any() else c[k] for k in range(q)])
        if np.allclose(cn,c): break
        c=cn
    return np.sort(c), np.argmin(np.abs(x[:,None]-np.sort(c)[None,:]),axis=1)

def init_from_data(Y,t,dt,q,h=25):
    """Грубая инициализация ветвей: уровни локальной волатильности + регрессия."""
    b=M.local_vol(Y,dt,h); W=M.driver_from_vol(Y,b)
    lv,lab=kmeans1d(np.log(b),q)
    br=[]
    for k in range(q):
        m=lab==k
        bk=float(np.exp(lv[k]))
        if m.sum()<10:
            br.append((float(Y.mean()),0.0,bk)); continue
        A=np.c_[np.ones(m.sum()),t[m]]
        z=Y[m]-bk*W[m]
        coef,*_=np.linalg.lstsq(A,z,rcond=None)
        br.append((float(coef[0]),float(coef[1]),bk))
    return br,b,W,lab
