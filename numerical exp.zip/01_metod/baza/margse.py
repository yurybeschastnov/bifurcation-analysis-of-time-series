"""
Маргинальная ошибка оценки волатильности ветви и критерий различимости.

Условное профилирование (при замороженных прочих параметрах) не годится: у лишней
ветви оно даёт малую ошибку, поскольку сдвиг одного параметра при замороженных
остальных критерий всё-таки меняет. Плоское направление, о котором говорит теорема
о ядре, лежит в полном пространстве параметров ветви: у непосещаемой ветви сдвиг b_j
компенсируется сдвигом её же c_j и a_j. Поэтому профиль строится с перенастройкой
собственных параметров ветви.
"""
import numpy as np, sys
sys.path.insert(0,'/home/claude/work')
import classes as C
from scipy.optimize import minimize


def profile_b(Y, t, dt, fit, j, keep=None, bref=None, span=0.25, ng=9, maxiter=8):
    """Профиль критерия по b_j с перенастройкой прочих параметров той же ветви."""
    kind, N, br = fit['kind'], fit['N'], list(fit['branches'])
    p = C.SPEC[kind]['np_']
    b0 = abs(br[j][2])
    others = [i for i in range(p) if i != 2]

    def val(vec, bb):
        g = list(br[j]); g[2] = float(bb)
        for i, v in zip(others, vec): g[i] = float(v)
        bs = list(br); bs[j] = tuple(g)
        v, _ = C.crit_of(kind, Y, t, dt, C.project(bs, kind), N, keep, bref)
        return v if np.isfinite(v) and v > -1e5 else -np.inf

    grid = b0 * np.linspace(1 - span, 1 + span, ng)
    k0 = int(np.argmin(np.abs(grid - b0)))
    out = np.full(ng, -np.inf)
    x = np.array([br[j][i] for i in others], float)
    sc = np.maximum(np.abs(x), 0.05)
    for direction in (1, -1):
        xc = x.copy()
        idx = range(k0, ng) if direction == 1 else range(k0 - 1, -1, -1)
        for kk in idx:
            bb = grid[kk]
            f = lambda z: -val(z * sc, bb)
            r = minimize(f, xc / sc, method='Nelder-Mead',
                         options=dict(maxiter=maxiter * len(xc) * 4,
                                      maxfev=maxiter * len(xc) * 6, xatol=1e-4, fatol=1e-6))
            out[kk] = -r.fun
            xc = r.x * sc
    return grid, out


def se_marginal(Y, t, dt, fit, keep=None, bref=None, drop=2.0, **kw):
    """Стандартная ошибка: полуширина области падения критерия на drop, делённая на 2."""
    N = fit['N']
    se = np.zeros(N)
    for j in range(N):
        g, v = profile_b(Y, t, dt, fit, j, keep, bref, **kw)
        m = np.nanmax(v)
        ok = v >= m - drop
        if ok.sum() < 2:
            se[j] = (g[1] - g[0]) / 4.0          # уже профиля сетки
        elif ok.all():
            se[j] = (g[-1] - g[0])               # шире сетки: направление плоское
        else:
            w = g[ok]; se[j] = (w.max() - w.min()) / 2.0 / (2 * np.sqrt(drop / 2.0))
    return se


def tau(Y, t, dt, fit, keep=None, bref=None, **kw):
    se = se_marginal(Y, t, dt, fit, keep, bref, **kw)
    b = np.array([abs(g[2]) for g in fit['branches']])
    N = len(b)
    if N < 2:
        return np.inf, se
    T = np.inf
    for i in range(N):
        for j in range(i + 1, N):
            den = np.sqrt(se[i] ** 2 + se[j] ** 2)
            if den > 0:
                T = min(T, abs(b[i] - b[j]) / den)
    return float(T), se


def profile_r(Y, t, dt, fit, j, keep=None, bref=None, span=1.0, ng=9, maxiter=8):
    """Профиль критерия по кривизне r_j с перенастройкой прочих параметров той же ветви."""
    kind, N, br = fit['kind'], fit['N'], list(fit['branches'])
    if kind != 'cub':
        return None, None
    p = 4; others = [0, 1, 2]
    r0 = max(br[j][3], 1e-6)
    def val(vec, rr):
        g = list(br[j]); g[3] = float(max(rr, 0.0))
        for i, v in zip(others, vec): g[i] = float(v)
        bs = list(br); bs[j] = tuple(g)
        v, _ = C.crit_of(kind, Y, t, dt, C.project(bs, kind), N, keep, bref)
        return v if np.isfinite(v) and v > -1e5 else -np.inf
    hi = max(r0 * (1 + span), 0.05)
    grid = np.linspace(0.0, hi, ng)
    x = np.array([br[j][i] for i in others], float); sc = np.maximum(np.abs(x), 0.05)
    out = np.full(ng, -np.inf); xc = x.copy()
    for kk in range(ng):
        f = lambda z: -val(z * sc, grid[kk])
        r = minimize(f, xc / sc, method='Nelder-Mead',
                     options=dict(maxiter=maxiter*len(xc)*4, maxfev=maxiter*len(xc)*6,
                                  xatol=1e-4, fatol=1e-6))
        out[kk] = -r.fun; xc = r.x * sc
    return grid, out


def t_curvature(Y, t, dt, fit, keep=None, bref=None, **kw):
    """Отношение оценки кривизны к её погрешности: ветвь считается искривлённой при t>2."""
    N = fit['N']; res = []
    for j in range(N):
        g, v = profile_r(Y, t, dt, fit, j, keep, bref, **kw)
        if g is None: res.append(np.nan); continue
        m = np.nanmax(v); kbest = int(np.nanargmax(v))
        ok = v >= m - 2.0
        w = g[ok]
        se = (w.max() - w.min()) / 2.0 / 2.0 if ok.sum() > 1 else (g[1] - g[0]) / 4.0
        res.append((g[kbest] / se if se > 0 else np.inf, g[kbest], se))
    return np.array(res)
