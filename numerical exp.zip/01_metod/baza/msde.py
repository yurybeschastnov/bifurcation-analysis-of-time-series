"""
Многорежимные ряды как ветви неявного полиномиального стохастического уравнения.

    f(X, w, t; nu) = X^N + sum_{n=0}^{N-1} c_n(w,t) X^n = 0,
    c_n(w,t) = sum_{k+m <= D-n} nu_{n,k,m} w^k t^m,     D >= N (по умолчанию D = N).

Подход A: линейные условия инцидентности/касания по восстановленному драйверу.
Подход B: точное правдоподобие восстановленного драйвера.
"""
import numpy as np
from math import comb, lgamma

# ----------------------------------------------------------------------------- базис


def basis(N, D=None):
    """Список показателей (n,k,m). deg c_n <= D-n."""
    if D is None:
        D = N
    out = []
    for n in range(N):
        for k in range(D - n + 1):
            for m in range(D - n - k + 1):
                out.append((n, k, m))
    return out


def basis_free(N, D=None):
    """Базис с нормировкой nu_{0,0,0}=0 (начало отсчёта драйвера в первой точке)."""
    B = basis(N, D)
    return [b for b in B if b != (0, 0, 0)]


def expand(nu_free, B_free, B):
    """Вектор свободных параметров -> полный вектор по базису B."""
    full = np.zeros(len(B))
    idx = {b: i for i, b in enumerate(B)}
    for v, b in zip(nu_free, B_free):
        full[idx[b]] = v
    return full


# --------------------------------------------------------------------- значения f


def f_val(X, w, t, nu, B, N):
    X = np.asarray(X, float); w = np.asarray(w, float); t = np.asarray(t, float)
    out = X ** N
    for v, (n, k, m) in zip(nu, B):
        if v != 0.0:
            out = out + v * (w ** k) * (t ** m) * (X ** n)
    return out


def f_X(X, w, t, nu, B, N):
    out = N * X ** (N - 1)
    for v, (n, k, m) in zip(nu, B):
        if n >= 1 and v != 0.0:
            out = out + v * n * (w ** k) * (t ** m) * (X ** (n - 1))
    return out


def f_w(X, w, t, nu, B, N):
    out = np.zeros_like(np.asarray(X, float) * np.asarray(w, float))
    for v, (n, k, m) in zip(nu, B):
        if k >= 1 and v != 0.0:
            out = out + v * k * (w ** (k - 1)) * (t ** m) * (X ** n)
    return out


def x_coeffs(w, t, nu, B, N):
    """Коэффициенты c_n(w,t) многочлена по X (приведённый, c_N = 1). Возвращает (n_pts, N+1)."""
    w = np.atleast_1d(np.asarray(w, float)); t = np.atleast_1d(np.asarray(t, float))
    C = np.zeros((len(w), N + 1))
    C[:, N] = 1.0
    for v, (n, k, m) in zip(nu, B):
        if v != 0.0:
            C[:, n] += v * (w ** k) * (t ** m)
    return C


def w_coeffs(Y, t, nu, B, N, D=None):
    """Коэффициенты многочлена по w от f(Y,w,t). Возвращает (n_pts, D+1), по возрастанию степени."""
    if D is None:
        D = N
    Y = np.atleast_1d(np.asarray(Y, float)); t = np.atleast_1d(np.asarray(t, float))
    P = np.zeros((len(Y), D + 1))
    P[:, 0] += Y ** N
    for v, (n, k, m) in zip(nu, B):
        if v != 0.0:
            P[:, k] += v * (t ** m) * (Y ** n)
    return P


# ------------------------------------------------------------------- корни, выбор


def roots_batch(P, eps=1e-13):
    """
    Корни набора многочленов; P[i] — коэффициенты по возрастанию степени.
    Старший коэффициент может обращаться в нуль (эффективная степень падает),
    поэтому строки группируются по фактической степени; недостающие места — nan.
    """
    P = np.atleast_2d(np.asarray(P, float))
    npt, dp1 = P.shape
    dmax = dp1 - 1
    out = np.full((npt, dmax), np.nan, dtype=complex)
    scale = np.max(np.abs(P), axis=1)
    scale = np.where(scale > 0, scale, 1.0)
    nz = np.abs(P) > eps * scale[:, None]
    deg = np.where(nz.any(axis=1), dp1 - 1 - np.argmax(nz[:, ::-1], axis=1), 0)
    for dd in np.unique(deg):
        if dd < 1:
            continue
        sel = np.where(deg == dd)[0]
        Q = P[sel, :dd + 1]
        lead = Q[:, -1]
        C = np.zeros((len(sel), dd, dd))
        if dd > 1:
            C[:, 1:, :-1] = np.eye(dd - 1)[None, :, :]
        C[:, :, -1] = -Q[:, :-1] / lead[:, None]
        out[sel[:, None], np.arange(dd)[None, :]] = np.linalg.eigvals(C)
    return out


def select_continuous(R, w0=0.0, imtol=1e-6, wmax=1e6):
    """Непрерывный выбор вещественного корня: ближайший к предыдущему."""
    n, d = R.shape
    out = np.empty(n); ok = np.ones(n, bool)
    prev = w0
    re = R.real; im = np.abs(R.imag)
    good = (im <= imtol * (1.0 + np.abs(re))) & np.isfinite(re) & (np.abs(re) < wmax)
    for i in range(n):
        g = good[i]
        if not g.any():
            ok[i] = False; out[i] = prev; continue
        rr = re[i][g]
        out[i] = rr[np.argmin(np.abs(rr - prev))]
        prev = out[i]
    return out, ok


def real_roots_grid(w, t, nu, B, N, imtol=1e-6):
    """Все вещественные X-корни на сетке (w,t). Возвращает (n_pts, N) с nan на месте комплексных."""
    C = x_coeffs(w, t, nu, B, N)
    R = roots_batch(C)
    re = R.real; im = np.abs(R.imag)
    good = im <= imtol * (1.0 + np.abs(re))
    X = np.where(good, re, np.nan)
    return np.sort(X, axis=1)


# ------------------------------------------------ локальные оценки и драйвер (A)


def local_vol(Y, dt, h):
    """Оценка b(t) по квадратичной вариации в скользящем окне длины 2h."""
    dY = np.diff(Y, prepend=Y[0])
    q = dY ** 2
    ker = np.ones(2 * h) / (2 * h * dt)
    pad = np.r_[np.full(h, q[1:h + 1].mean()), q, np.full(h, q[-h:].mean())]
    v = np.convolve(pad, ker, mode='same')[h:h + len(Y)]
    return np.sqrt(np.maximum(v, 1e-12))


def driver_from_vol(Y, b):
    """Де-волатилизация: dW = dY / b, W(t_0) = 0."""
    dY = np.diff(Y)
    dW = dY / b[1:]
    return np.r_[0.0, np.cumsum(dW)]


# ---------------------------------------------------------------- подход A: система


def designA(Y, t, W, b, B, N, orders=None, weights=None):
    """
    Условия: коэффициенты Тейлора по u функции
        phi(u) = f(Y + b u, W + u, t; nu)
    порядков j = 0..J. j=0 — инцидентность, j=1 — касание.
    Возвращает M (n_cond*n_pts, S) и rho, так что M nu = rho.
    """
    n = len(Y)
    S = len(B)
    if orders is None:
        orders = list(range(N + 1))
    if weights is None:
        weights = {j: 1.0 for j in orders}
    Ms, rs = [], []
    for j in orders:
        M = np.zeros((n, S))
        for s, (nn, k, m) in enumerate(B):
            acc = np.zeros(n)
            for p in range(0, min(j, k) + 1):
                q = j - p
                if q > nn:
                    continue
                acc += comb(k, p) * W ** (k - p) * comb(nn, q) * Y ** (nn - q) * b ** q
            M[:, s] = acc * t ** m
        rho = -comb(N, j) * (Y ** (N - j) if N - j >= 0 else 0.0) * b ** j if j <= N else np.zeros(n)
        Ms.append(weights[j] * M)
        rs.append(weights[j] * np.asarray(rho, float) * np.ones(n))
    return np.vstack(Ms), np.concatenate(rs)


def solveA(M, rho, lam=0.0):
    A = M.T @ M
    xi = M.T @ rho
    S = A.shape[0]
    nu = np.linalg.solve(A + lam * np.eye(S) * np.trace(A) / S, xi) if lam > 0 else np.linalg.lstsq(A, xi, rcond=None)[0]
    return nu, A, xi


def spectrumA(M):
    """Нормированные сингулярные числа матрицы условий."""
    s = np.linalg.svd(M, compute_uv=False)
    return s / s[0]


# ------------------------------------------------------- подход B: правдоподобие


def reconstruct_driver(Y, t, nu, B, N, D=None, w0=0.0):
    """Алгебраическое восстановление драйвера: корень f(Y_t, w, t)=0 по непрерывности."""
    P = w_coeffs(Y, t, nu, B, N, D)
    R = roots_batch(P)
    return select_continuous(R, w0=w0)


def loglik(Y, t, dt, nu, B, N, D=None, w0=0.0, ret_all=False, floor=1e-10):
    What, ok = reconstruct_driver(Y, t, nu, B, N, D, w0)
    if not ok.all():
        val = -1e12 * (1 + (~ok).sum())
        return (val, What, ok, None) if ret_all else val
    dW = np.diff(What)
    fx = f_X(Y[1:], What[1:], t[1:], nu, B, N)
    fw = f_w(Y[1:], What[1:], t[1:], nu, B, N)
    bimp = -fw / np.where(np.abs(fx) < floor, np.sign(fx) * floor + floor, fx)   # b = dX/dw
    if not np.all(np.isfinite(bimp)) or np.any(np.abs(bimp) < floor):
        val = -1e12
        return (val, What, ok, bimp) if ret_all else val
    ll = -0.5 * np.sum(dW ** 2) / dt - np.sum(np.log(np.abs(bimp))) - 0.5 * len(dW) * np.log(2 * np.pi * dt)
    if not np.isfinite(ll):
        ll = -1e12
    return (ll, What, ok, bimp) if ret_all else ll



def _root_table(Y, t, nu, B, N, D=None, imtol=1e-6, wmax=1e4):
    """Таблица вещественных корней f(Y_t,w,t)=0 по w. Возвращает (n, dmax) с nan."""
    P = w_coeffs(Y, t, nu, B, N, D)
    R = roots_batch(P)
    re = R.real; im = np.abs(R.imag)
    good = (im <= imtol * (1.0 + np.abs(re))) & np.isfinite(re) & (np.abs(re) < wmax)
    return np.sort(np.where(good, re, np.nan), axis=1)


def _emission(Y, t, W, nu, B, N, band=None, eps=1e-9, bref=None, lo=0.25, hi=4.0,
              valid=None):
    """
    -log|b|, b = dX/dw = -f_w/f_X — вклад якобиана замены y -> w.
    Замена законна лишь в простом корне: f_X != 0, f_w != 0. Состояния, где корень
    кратный (|f_X| или |f_w| ниже относительного порога) или где подразумеваемая
    волатильность выходит из полосы band=(bmin,bmax), объявляются недопустимыми.
    """
    fx = f_X(Y, W, t, nu, B, N)
    fw = f_w(Y, W, t, nu, B, N)
    # пороги вырожденности берутся только по существующим корням: пустые ячейки
    # таблицы заполнены нулём и дали бы значения в фиктивной точке w = 0, из-за чего
    # критерий переставал быть инвариантным к сдвигу драйвера
    ax = np.abs(fx) if valid is None else np.where(valid, np.abs(fx), np.nan)
    aw = np.abs(fw) if valid is None else np.where(valid, np.abs(fw), np.nan)
    sx = np.nanmedian(ax) + 1e-300
    sw = np.nanmedian(aw) + 1e-300
    ok = (np.abs(fx) > eps * sx) & (np.abs(fw) > eps * sw)
    with np.errstate(divide='ignore', invalid='ignore'):
        b = np.abs(fw / fx)
    ok &= np.isfinite(b)
    if band is not None:
        ok &= (b >= band[0]) & (b <= band[1])
    if bref is not None:
        # состояние допустимо, лишь если подразумеваемая моделью волатильность
        # согласована с наблюдаемой квадратичной вариацией
        ok &= (b >= lo * bref) & (b <= hi * bref)
    em = np.where(ok, -np.log(np.where(ok, b, 1.0)), 0.0)
    return em, ok


def path_likelihood(Y, t, dt, nu, B, N, D=None, mode='max', w0=0.0, ret_table=False, band=None, tau=None, kappa=None,
                    keep=None, bref=None):
    """
    Точная логарифмическая плотность наблюдённого ряда:
        p(y_1..y_n | y_0) = sum_{все прообразы w} prod phi_dt(dw_i) * prod |dw_i/dy_i|.
    mode='sum'  — прямая рекурсия, точное правдоподобие;
    mode='max'  — Витерби, профильное правдоподобие и MAP-восстановление драйвера.
    """
    if keep is not None:
        keep = np.asarray(keep, bool)
        Y = Y[keep]; t = t[keep]
        if bref is not None:
            bref = np.asarray(bref, float)[keep]
    dts = np.diff(np.asarray(t, float))          # шаг может быть переменным:
    dts = np.where(dts > 0, dts, dt)             # вырезанные окрестности перескакиваются
    Rt = _root_table(Y, t, nu, B, N, D)
    n, K = Rt.shape
    NEG = -1e10
    fin = np.isfinite(Rt)
    if not fin[0].any() or not fin.any(axis=1).all():
        v = -1e6 * (1.0 + int(np.sum(~fin.any(axis=1))))
        return (v, None, None) if not ret_table else (v, None, None, Rt)
    Rz = np.nan_to_num(Rt)
    BR = None if bref is None else np.repeat(np.asarray(bref, float)[:, None], K, 1)
    EM, okem = _emission(np.repeat(Y[:, None], K, 1), np.repeat(t[:, None], K, 1), Rz, nu, B, N,
                         band=band, bref=BR, valid=fin)
    fin = fin & okem
    if not fin[0].any() or not fin.any(axis=1).all():
        v = -1e6 * (1.0 + int(np.sum(~fin.any(axis=1))))
        return (v, None, None) if not ret_table else (v, None, None, Rt)
    EM = np.where(fin, EM, NEG)
    nbad = int(np.sum(~okem))
    d = Rz[1:, :, None] - Rz[:-1, None, :]
    dd = dts[:, None, None]
    TR = -0.5 * d ** 2 / dd - 0.5 * np.log(2 * np.pi * dd)
    adm = fin[1:][:, :, None] & fin[:-1][:, None, :]
    if tau is not None:
        adm &= np.abs(d) <= tau * np.sqrt(dd)      # непрерывность драйвера
    if kappa is None:
        kappa = np.log(max(n, 2))
    same = np.eye(K, dtype=bool)[None, :, :]       # корни упорядочены: ранг непрерывен
    TR = TR - kappa * (~same)                      # штраф за смену ветви (только в слиянии)
    TR = np.where(adm, TR, NEG)
    # начальная ветвь неизвестна: все допустимые корни равноправны. Это делает
    # критерий точно инвариантным к сдвигу драйвера w -> w + s.
    alpha = np.where(fin[0], 0.0, NEG)
    back = np.zeros((n, K), np.int32)
    for i in range(1, n):
        z = TR[i - 1] + alpha[None, :]
        b = np.argmax(z, axis=1); back[i] = b
        mx = z[np.arange(K), b]
        if mode == 'max':
            a = mx
        else:
            a = mx + np.log(np.sum(np.exp(np.clip(z - mx[:, None], -700.0, 0.0)), axis=1))
        alpha = np.maximum(a + EM[i], NEG)
    if mode == 'max':
        ll = float(np.max(alpha)); j = int(np.argmax(alpha))
    else:
        mx = float(np.max(alpha))
        ll = mx + float(np.log(np.sum(np.exp(np.clip(alpha - mx, -700.0, 0.0)))))
        j = int(np.argmax(alpha))
    What = np.empty(n); What[-1] = Rz[n - 1, j]
    for i in range(n - 1, 0, -1):
        j = back[i, j]; What[i - 1] = Rz[i - 1, j]
    if ret_table:
        return ll, What, nbad, Rt
    return ll, What, nbad


def viterbi_driver(Y, t, dt, nu, B, N, D=None, w0=0.0):
    ll, What, bad = path_likelihood(Y, t, dt, nu, B, N, D, mode='max', w0=w0)
    return What, ll, bad

# --------------------------------------------------------------------- диагностика


def ljung_box(x, h=20):
    x = x - x.mean()
    n = len(x)
    c0 = np.dot(x, x) / n
    Q = 0.0
    for k in range(1, h + 1):
        rk = np.dot(x[:-k], x[k:]) / n / c0
        Q += rk ** 2 / (n - k)
    return n * (n + 2) * Q


def chi2_sf(q, df):
    from scipy.stats import chi2
    return float(chi2.sf(q, df))


def diagnostics(dW, dt, h=20):
    from scipy import stats
    z = dW / np.sqrt(dt)
    out = {}
    out['n'] = len(z)
    out['var_ratio'] = float(np.mean(z ** 2))
    out['skew'] = float(stats.skew(z))
    out['kurt'] = float(stats.kurtosis(z))
    ks = stats.kstest(z / np.std(z), 'norm')
    out['ks_stat'] = float(ks.statistic); out['ks_p'] = float(ks.pvalue)
    jb = stats.jarque_bera(z)
    out['jb'] = float(jb.statistic); out['jb_p'] = float(jb.pvalue)
    q1 = ljung_box(z, h); out['lb'] = float(q1); out['lb_p'] = chi2_sf(q1, h)
    q2 = ljung_box(z ** 2, h); out['lb2'] = float(q2); out['lb2_p'] = chi2_sf(q2, h)
    return out
