import numpy as np, sys, time, json
sys.path.insert(0, '/home/claude/work')
import msde as M, synth as S, init_branches as I
from scipy.optimize import minimize

TAU = None           # жёсткий порог не нужен: квадратичный член штрафует разрывы сам
BAND_LO, BAND_HI = 0.2, 5.0


def make_band(b_loc):
    """Полоса допустимой волатильности отключена: для аффинных ветвей она никогда
    не связывала, а при ветвях, нелинейных по w, отсекает подлинные состояния около
    точек поворота, где |dg/dw| законно обращается в нуль. Защиту от вырождения
    (кратный корень) даёт отдельная проверка f_X != 0 и f_w != 0 в _emission."""
    return None


def branch_usage(Y, t, dt, nu, B, N, D=None, band=None):
    """Доля времени, проведённая на каждой ветви (ранге w-корня), вдоль восстановленного драйвера."""
    ll, Wv, _ = M.path_likelihood(Y, t, dt, nu, B, N, D, mode='max', band=band,
                                  tau=TAU, kappa=np.log(max(len(Y), 2)), ret_table=False)[:3]
    if Wv is None:
        return None, None
    Rt = M._root_table(Y, t, nu, B, N, D)
    K = Rt.shape[1]
    rank = np.full(len(Y), -1)
    for i in range(len(Y)):
        r = Rt[i]
        ok = np.isfinite(r)
        if ok.any():
            rank[i] = int(np.argmin(np.where(ok, np.abs(r - Wv[i]), np.inf)))
    occ = np.array([np.mean(rank == j) for j in range(K)])
    return occ, rank


def censor_mask(Y, t, dt, h=40, alpha=0.02):
    """
    Окрестности бифуркаций вырезаются, а не объявляются недопустимыми.
    Около слияния корней якобиан замены |dg/dw| обращается в нуль или в бесконечность,
    и вклад -log|b| расходится. Такие моменты цензурируются: наблюдение исключается,
    а переход через пропуск учитывается по фактическому прошедшему времени.
    Маска строится по локальной оценке волатильности, поэтому одинакова для всех
    сравниваемых моделей и не мешает сопоставлять их правдоподобия.
    """
    b = M.local_vol(Y, dt, h)
    lo, hi = np.quantile(b, [alpha, 1 - alpha / 4])
    keep = (b >= lo) & (b <= hi)
    keep[0] = keep[-1] = True
    return keep


QV_LO, QV_HI = 0.70, 1.40


def crit(Y, t, dt, nu, B, N, D=None, band=None, ret=False, keep=None, bref=None):
    """Профильное правдоподобие: максимум по допустимым непрерывным драйверам."""
    out = M.path_likelihood(Y, t, dt, nu, B, N, D, mode='max', band=band,
                            tau=TAU, kappa=np.log(max(len(Y), 2)), keep=keep, bref=bref)
    ll, Wv = out[0], out[1]
    if Wv is not None and np.isfinite(ll):
        tt = np.asarray(t)[np.asarray(keep, bool)] if keep is not None else np.asarray(t)
        span = float(np.sum(np.diff(tt)))
        q = float(np.sum(np.diff(Wv) ** 2)) / span if span > 0 else np.nan
        # драйвер обязан быть винеровской траекторией: его квадратичная вариация
        # равна прошедшему времени. Нарушение означает вырождение модели, при котором
        # член -log|b| набирается за счёт занижения подразумеваемой волатильности.
        if not np.isfinite(q) or q < QV_LO or q > QV_HI:
            pen = 1e4 * (1.0 + abs(q - 1.0) if np.isfinite(q) else 10.0)
            out = (ll - pen,) + tuple(out[1:])
    return out if ret else out[0]


# ------------------------------------------------------------------ этап 0 и A

def stage0(Y, t, dt, h):
    b = M.local_vol(Y, dt, h)
    W = M.driver_from_vol(Y, b)
    return b, W


def stageA(Y, t, W, b, N, D=None, orders=(0, 1), lam=0.0):
    B = M.basis(N, D)
    Mm, rho = M.designA(Y, t, W, b, B, N, orders=list(orders))
    nu, A, xi = M.solveA(Mm, rho, lam=lam)
    res = float(np.linalg.norm(Mm @ nu - rho) / np.sqrt(len(rho)))
    s = M.spectrumA(Mm)
    return nu, B, res, s


# ------------------------------------------------------------------- этап B

def _pack_br(br):
    return np.array([v for g in br for v in g], float)


def _unpack_br(x):
    return [tuple(x[3 * i:3 * i + 3]) for i in range(len(x) // 3)]


class _Best:
    """Критерий кусочно-гладкий: путь драйвера меняется скачком, поэтому численный
    градиент ненадёжен и оптимизатор может уйти в худшую точку. Запоминаем лучшую."""

    def __init__(self, fun):
        self.fun = fun; self.best = np.inf; self.x = None; self.calls = 0

    def __call__(self, x):
        v = self.fun(np.asarray(x, float)); self.calls += 1
        if np.isfinite(v) and v < self.best:
            self.best = float(v); self.x = np.array(x, float)
        return v


def fit_branches(Y, t, dt, br0, N, maxiter=200, verbose=True, band=None):
    """Оценка в классе произведений аффинных ветвей: f = prod (X - c_j - a_j t - b_j w)."""
    B = M.basis(N)
    sc = np.array([1.0, 3.0, 1.0] * N)
    x0 = _pack_br(br0) * sc

    def neg(x):
        br = _unpack_br(x / sc)
        if min(abs(g[2]) for g in br) < 1e-3:
            return 1e6
        nu, _ = S.nu_from_branches(br, B, N)
        return -crit(Y, t, dt, nu, B, N, band=band) / len(Y)

    t0 = time.time(); g = _Best(neg); g(x0)
    minimize(g, x0, method='Nelder-Mead',
             options=dict(maxiter=maxiter * 3, maxfev=maxiter * 6, xatol=1e-6, fatol=1e-9))
    minimize(g, g.x, method='L-BFGS-B',
             options=dict(maxiter=maxiter, eps=1e-5, ftol=1e-15, gtol=1e-12))
    br = _unpack_br(g.x / sc)
    nu, _ = S.nu_from_branches(br, B, N)
    ll = crit(Y, t, dt, nu, B, N, band=band)
    assert ll >= -g.best * len(Y) - 1e-6, 'несогласованность критерия'
    if verbose:
        print('    произведение ветвей: ll=%.1f  (%.0f c, %d вызовов)' % (ll, time.time() - t0, g.calls))
    return br, nu, float(ll)


def relax_full(Y, t, dt, nu0, N, D=None, maxiter=50, verbose=True, band=None):
    """
    Релаксация к полному многочлену. Ни один коэффициент не фиксируется: сдвиг
    w -> w + s есть точная симметрия критерия и порождает одно плоское направление,
    безвредное для оптимизации; оно учитывается только в числе параметров (dim nu - 1).
    """
    B = M.basis(N, D)
    sc = np.array([max(abs(v), 1e-2) for v in nu0])
    x0 = np.asarray(nu0, float) / sc

    def unpack(x):
        return np.asarray(x, float) * sc

    def neg(x):
        return -crit(Y, t, dt, unpack(x), B, N, D, band=band) / len(Y)

    t0 = time.time(); g = _Best(neg); g(x0)
    minimize(g, x0, method='L-BFGS-B',
             options=dict(maxiter=maxiter, eps=1e-4, ftol=1e-15, gtol=1e-12))
    minimize(g, g.x, method='Powell',
             options=dict(maxiter=maxiter, maxfev=max(8, 25 - len(x0) // 4) * len(x0),
                          xtol=1e-6, ftol=1e-10))
    nu = unpack(g.x)
    ll = crit(Y, t, dt, nu, B, N, D, band=band)
    ll0 = crit(Y, t, dt, np.asarray(nu0, float), B, N, D, band=band)
    if ll < ll0:                      # гарантия монотонности
        nu, ll = np.asarray(nu0, float), ll0
    if verbose:
        print('    полный многочлен: %.1f -> %.1f  (%.0f c, %d вызовов)'
              % (ll0, ll, time.time() - t0, g.calls))
    return nu, float(ll), len(B) - 1


def far_branch(Y, b_loc):
    """Ветвь, заведомо не посещаемая траекторией: используется для вложения класса N в N+1."""
    rng = float(np.max(Y) - np.min(Y)) + 1e-3
    return (float(np.max(Y)) + 5 * rng, 0.0, float(np.median(b_loc)))


def fit_ladder(Y, t, dt, degrees=(1, 2, 3, 4), h=40, verbose=True):
    """
    Оценивание по возрастанию степени. Класс степени N вложен в класс степени N+1
    (добавлением непосещаемой ветви), поэтому решение степени N служит стартом для N+1;
    это обеспечивает неубывание критерия по степени.
    """
    b, W = stage0(Y, t, dt, h)
    band = make_band(b)
    n = len(Y) - 1
    out = {}
    prev = None
    for N in degrees:
        B = M.basis(N)
        nuA, _, resA, sA = stageA(Y, t, W, b, N)
        llA = crit(Y, t, dt, nuA, B, N, band=band)
        starts = []
        br0, _, _, _ = I.init_from_data(Y, t, dt, N, h=h)
        starts.append(('кластеры', br0))
        if prev is not None and len(prev) == N - 1:
            starts.append(('лестница', list(prev) + [far_branch(Y, b)]))
        best = (-np.inf, None, None)
        for tag, s0 in starts:
            br, nu_p, ll_p = fit_branches(Y, t, dt, s0, N, verbose=False, band=band)
            if ll_p > best[0]:
                best = (ll_p, br, nu_p)
        ll_p, br, nu_p = best
        cands = [(ll_p, nu_p)] + ([(llA, nuA)] if llA > -1e5 else [])
        bf = (-np.inf, None)
        for ll0, nu0 in sorted(cands, key=lambda z: -z[0])[:2]:
            nu_f, ll_f, kf = relax_full(Y, t, dt, nu0, N, verbose=False, band=band)
            if ll_f > bf[0]:
                bf = (ll_f, nu_f)
        ll_f, nu_f = bf
        kp, kf = 3 * N - 1, len(B) - 1
        out[N] = dict(N=N, band=band, resA=resA, sA=sA, llA=llA, b_loc=b, W_dv=W,
                      prod=dict(nu=nu_p, branches=br, ll=ll_p, k=kp, bic=-2 * ll_p + kp * np.log(n)),
                      full=dict(nu=nu_f, ll=ll_f, k=kf, bic=-2 * ll_f + kf * np.log(n)))
        prev = br
        if verbose:
            print('  N=%d | произв.: ll=%9.1f k=%2d BIC=%10.1f | полный: ll=%9.1f k=%2d BIC=%10.1f'
                  % (N, ll_p, kp, out[N]['prod']['bic'], ll_f, kf, out[N]['full']['bic']))
            sys.stdout.flush()
    return out
