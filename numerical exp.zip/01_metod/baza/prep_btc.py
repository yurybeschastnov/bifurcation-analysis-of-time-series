import numpy as np, pandas as pd

# Три непересекающихся участка с разными режимами рынка
WINDOWS = {
    'btcA': ('2026-01-25', '2026-03-08'),   # основной
    'btcB': ('2025-03-01', '2025-04-12'),   # ранний, иной уровень цен
    'btcC': ('2025-09-15', '2025-10-27'),   # осенний
}

def load(freq='15min', start='2026-01-25', end='2026-03-08'):
    d=pd.read_csv('/home/claude/btcmin.csv')
    d['dt']=pd.to_datetime(d['timestamp'],unit='s',utc=True)
    d=d.set_index('dt').sort_index()['close']
    b=d.resample(freq).last().ffill()
    b=b[(b.index>=start)&(b.index<end)]
    P=b.values.astype(float); ts=b.index
    Y0=np.log(P)
    n=len(Y0)-1
    T=1.0
    t=np.linspace(0,T,len(Y0))
    dt=T/n
    Yc=Y0-Y0[0]
    s=np.sqrt(np.sum(np.diff(Yc)**2))       # нормировка: полная квадратичная вариация = 1
    Y=Yc/s
    return dict(ts=ts,P=P,logP=Y0,Y=Y,t=t,dt=dt,scale=s,T=T,freq=freq,
                years=(ts[-1]-ts[0]).total_seconds()/(365.25*24*3600))
if __name__=='__main__':
    for f in ['5min','10min','15min','30min']:
        d=load(f)
        r=np.diff(d['Y'])
        print(f,'n=%d  scale=%.4f  годы=%.3f  ann.vol=%.1f%%  kurt=%.1f'%(len(d['Y']),d['scale'],d['years'],
            100*d['scale']/np.sqrt(d['years']), float(pd.Series(r).kurtosis())))
