"""
Разделимость ветвей. Лишняя ветвь проявляется как почти-дубликат уже имеющейся:
многочлен f приобретает кратный корень, и различить две ветви по данным нельзя.

Мера: вдоль восстановленного драйвера считается расстояние между ветвями
    d_{jk}(t) = |g_j(W_t,t) - g_k(W_t,t)|,
нормированное на характерный масштаб приращения sigma*sqrt(dt). Если у пары ветвей
расстояние остаётся малым на всём отрезке, ветви неразличимы и степень завышена.
"""
import numpy as np, sys
sys.path.insert(0, '/home/claude/work')
import msde as M, usage as U


def separation(Y, t, dt, nu, B, N, band=None):
    """Возвращает матрицу разделимости ветвей и её минимум по парам."""
    ll, Wv = U.driver(Y, t, dt, nu, B, N, band=band)
    if Wv is None:
        return None
    X = M.real_roots_grid(Wv, t, nu, B, N)          # (n, N), отсортированы, nan где комплексные
    scale = np.sqrt(np.mean(np.diff(Y) ** 2))       # характерное приращение ряда
    K = X.shape[1]
    D = np.full((K, K), np.inf)
    for j in range(K):
        for k in range(j + 1, K):
            d = np.abs(X[:, j] - X[:, k])
            ok = np.isfinite(d)
            if ok.sum() < 10:
                continue
            D[j, k] = D[k, j] = np.median(d[ok]) / scale
    return dict(D=D, min_pair=float(np.min(D)) if K > 1 else np.inf, W=Wv, X=X, scale=scale)


def effective_degree(Y, t, dt, fits, thresh=3.0, band=None):
    """Наибольшая степень, при которой все ветви ещё разделимы."""
    best = 1
    tab = {}
    for N in sorted(fits):
        nu = fits[N]['prod']['nu']; B = M.basis(N)
        s = separation(Y, t, dt, nu, B, N, band=band)
        tab[N] = np.nan if s is None else s['min_pair']
        if s is not None and s['min_pair'] > thresh:
            best = N
    return best, tab


def real_branch_count(Y, t, dt, nu, B, N, band=None):
    """Распределение числа вещественных ветвей вдоль траектории."""
    ll, Wv = U.driver(Y, t, dt, nu, B, N, band=band)
    if Wv is None:
        return None
    X = M.real_roots_grid(Wv, t, nu, B, N)
    nr = np.sum(np.isfinite(X), axis=1)
    return np.bincount(nr, minlength=N + 1) / len(nr)
