import numpy as np


def pmul(p, q):
    """Произведение многочленов от (w,t), заданных матрицами коэффициентов p[k,m]."""
    K = p.shape[0] + q.shape[0] - 1
    M = p.shape[1] + q.shape[1] - 1
    r = np.zeros((K, M))
    for k1 in range(p.shape[0]):
        for m1 in range(p.shape[1]):
            if p[k1, m1] == 0:
                continue
            for k2 in range(q.shape[0]):
                for m2 in range(q.shape[1]):
                    if q[k2, m2] == 0:
                        continue
                    r[k1 + k2, m1 + m2] += p[k1, m1] * q[k2, m2]
    return r


def branch_poly(c, a, b):
    """g(w,t) = c + a t + b w  ->  матрица коэффициентов."""
    p = np.zeros((2, 2))
    p[0, 0] = c; p[0, 1] = a; p[1, 0] = b
    return p


def nu_from_branches(branches, B, N):
    """nu для f = prod_j (X - g_j)."""
    # коэффициенты по X: раскрываем произведение
    polys = [{0: -branch_poly(*g), 1: np.array([[1.0]])} for g in branches]
    cur = {0: np.array([[1.0]])}
    for P in polys:
        new = {}
        for n1, p1 in cur.items():
            for n2, p2 in P.items():
                pr = pmul(p1, p2)
                if n1 + n2 in new:
                    A = new[n1 + n2]
                    K = max(A.shape[0], pr.shape[0]); M = max(A.shape[1], pr.shape[1])
                    Z = np.zeros((K, M)); Z[:A.shape[0], :A.shape[1]] += A
                    Z[:pr.shape[0], :pr.shape[1]] += pr
                    new[n1 + n2] = Z
                else:
                    new[n1 + n2] = pr
        cur = new
    nu = np.zeros(len(B))
    for i, (n, k, m) in enumerate(B):
        P = cur.get(n)
        if P is not None and k < P.shape[0] and m < P.shape[1]:
            nu[i] = P[k, m]
    return nu, cur


def simulate(branches, T=1.0, n_obs=4000, sub=20, seed=0, p_switch=0.5, j0=0, refract=0.0):
    """Одна траектория: Y_t = g_{j(t)}(W_t,t), смена ветви возможна только при их слиянии."""
    rng = np.random.default_rng(seed)
    n = n_obs * sub
    dt = T / n
    dW = rng.normal(0, np.sqrt(dt), n)
    W = np.r_[0.0, np.cumsum(dW)]
    t = np.linspace(0, T, n + 1)
    G = np.array([c + a * t + b * W for (c, a, b) in branches])   # (J, n+1)
    J = len(branches)
    j = j0
    lab = np.empty(n + 1, int); lab[0] = j
    Y = np.empty(n + 1); Y[0] = G[j, 0]
    last = -1e9
    for i in range(1, n + 1):
        d_prev = G[:, i - 1] - G[j, i - 1]
        d_now = G[:, i] - G[j, i]
        cross = np.where((d_prev * d_now < 0))[0]
        if len(cross) and t[i] - last >= refract and rng.random() < p_switch:
            j = int(cross[rng.integers(len(cross))]); last = t[i]
        Y[i] = G[j, i]; lab[i] = j
    idx = np.arange(0, n + 1, sub)
    return dict(t=t[idx], Y=Y[idx], W=W[idx], lab=lab[idx], dt=T / n_obs, T=T,
                t_fine=t, Y_fine=Y, W_fine=W)
