"""
Ветви, нелинейные и немонотонные по W_t.

Ветвь g(w,t) = c + a t + b w + r w^2 даёт по формуле Ито
    dX = (a + r) dt + (b + 2 r W_t) dW_t,
то есть волатильность b + 2 r W_t зависит от состояния драйвера (стохастическая
волатильность), а при b + 2 r w = 0 ветвь поворачивает и перестаёт быть монотонной.
Такие ветви лежат вне класса произведений аффинных множителей и требуют полного
многочлена с расширенным бюджетом степеней D.
"""
import numpy as np, sys
sys.path.insert(0, '/home/claude/work')
import msde as M
from synth import pmul


def qpoly(c, a, b, r):
    """g(w,t) = c + a t + b w + r w^2 -> матрица коэффициентов p[k,m] при w^k t^m."""
    p = np.zeros((3, 2))
    p[0, 0] = c; p[0, 1] = a; p[1, 0] = b; p[2, 0] = r
    return p


def nu_from_qbranches(branches, B, N):
    """nu для f = prod_j (X - g_j), g_j квадратичны по w."""
    cur = {0: np.array([[1.0]])}
    for g in branches:
        fac = {0: -qpoly(*g), 1: np.array([[1.0]])}
        new = {}
        for n1, p1 in cur.items():
            for n2, p2 in fac.items():
                pr = pmul(p1, p2); key = n1 + n2
                if key in new:
                    A = new[key]
                    K = max(A.shape[0], pr.shape[0]); Mx = max(A.shape[1], pr.shape[1])
                    Z = np.zeros((K, Mx))
                    Z[:A.shape[0], :A.shape[1]] += A
                    Z[:pr.shape[0], :pr.shape[1]] += pr
                    new[key] = Z
                else:
                    new[key] = pr
        cur = new
    nu = np.zeros(len(B))
    for i, (n, k, m) in enumerate(B):
        P = cur.get(n)
        if P is not None and k < P.shape[0] and m < P.shape[1]:
            nu[i] = P[k, m]
    # проверка, что бюджет степеней достаточен
    need = 0
    for n, P in cur.items():
        for k in range(P.shape[0]):
            for m in range(P.shape[1]):
                if abs(P[k, m]) > 1e-12:
                    need = max(need, k + m + n)
    return nu, need


def gval(g, w, t):
    c, a, b, r = g
    return c + a * t + b * w + r * w ** 2


def gslope(g, w):
    c, a, b, r = g
    return g[2] + 2 * g[3] * w


def simulate_q(branches, T=1.0, n_obs=2500, sub=20, seed=0, p_switch=0.5,
               j0=0, refract=0.03):
    """Траектория идёт по ветви, менять ветвь можно лишь в точках их пересечения."""
    rng = np.random.default_rng(seed)
    n = n_obs * sub; dt = T / n
    W = np.r_[0.0, np.cumsum(rng.normal(0, np.sqrt(dt), n))]
    t = np.linspace(0, T, n + 1)
    G = np.array([gval(g, W, t) for g in branches])
    j = j0; lab = np.empty(n + 1, int); lab[0] = j
    Y = np.empty(n + 1); Y[0] = G[j, 0]
    last = -1e9
    for i in range(1, n + 1):
        dp = G[:, i - 1] - G[j, i - 1]; dn = G[:, i] - G[j, i]
        cr = np.where(dp * dn < 0)[0]
        if len(cr) and t[i] - last >= refract and rng.random() < p_switch:
            j = int(cr[rng.integers(len(cr))]); last = t[i]
        Y[i] = G[j, i]; lab[i] = j
    idx = np.arange(0, n + 1, sub)
    return dict(t=t[idx], Y=Y[idx], W=W[idx], lab=lab[idx], dt=T / n_obs, T=T,
                branches=branches)


def describe(branches, W):
    """Диапазон волатильности каждой ветви на посещённом диапазоне драйвера."""
    lo, hi = W.min(), W.max()
    out = []
    for g in branches:
        s = np.array([gslope(g, lo), gslope(g, hi)])
        turn = -g[2] / (2 * g[3]) if g[3] != 0 else np.inf
        inside = lo < turn < hi
        out.append((float(min(s)), float(max(s)), float(turn), bool(inside)))
    return out


def cpoly(c, a, b, r):
    """g(w,t) = c + a t + b w + r w^3 -> матрица коэффициентов p[k,m]."""
    p = np.zeros((4, 2))
    p[0, 0] = c; p[0, 1] = a; p[1, 0] = b; p[3, 0] = r
    return p


def nu_from_cbranches(branches, B, N):
    """nu для f = prod_j (X - g_j), ветви кубические по w (глобально монотонные при b,r>0)."""
    cur = {0: np.array([[1.0]])}
    for g in branches:
        fac = {0: -cpoly(*g), 1: np.array([[1.0]])}
        new = {}
        for n1, p1 in cur.items():
            for n2, p2 in fac.items():
                pr = pmul(p1, p2); key = n1 + n2
                if key in new:
                    A = new[key]
                    K = max(A.shape[0], pr.shape[0]); Mx = max(A.shape[1], pr.shape[1])
                    Z = np.zeros((K, Mx))
                    Z[:A.shape[0], :A.shape[1]] += A
                    Z[:pr.shape[0], :pr.shape[1]] += pr
                    new[key] = Z
                else:
                    new[key] = pr
        cur = new
    nu = np.zeros(len(B)); need = 0
    for i, (n, k, m) in enumerate(B):
        P = cur.get(n)
        if P is not None and k < P.shape[0] and m < P.shape[1]:
            nu[i] = P[k, m]
    for n, P in cur.items():
        for k in range(P.shape[0]):
            for m in range(P.shape[1]):
                if abs(P[k, m]) > 1e-12:
                    need = max(need, k + m + n)
    return nu, need


def cval(g, w, t):
    c, a, b, r = g
    return c + a * t + b * w + r * w ** 3


def cslope(g, w):
    return g[2] + 3 * g[3] * w ** 2


def simulate_c(branches, T=1.0, n_obs=2500, sub=20, seed=0, p_switch=0.5,
               j0=0, refract=0.03):
    rng = np.random.default_rng(seed)
    n = n_obs * sub; dt = T / n
    W = np.r_[0.0, np.cumsum(rng.normal(0, np.sqrt(dt), n))]
    t = np.linspace(0, T, n + 1)
    G = np.array([cval(g, W, t) for g in branches])
    j = j0; lab = np.empty(n + 1, int); lab[0] = j
    Y = np.empty(n + 1); Y[0] = G[j, 0]; last = -1e9
    for i in range(1, n + 1):
        dp = G[:, i - 1] - G[j, i - 1]; dn = G[:, i] - G[j, i]
        cr = np.where(dp * dn < 0)[0]
        if len(cr) and t[i] - last >= refract and rng.random() < p_switch:
            j = int(cr[rng.integers(len(cr))]); last = t[i]
        Y[i] = G[j, i]; lab[i] = j
    idx = np.arange(0, n + 1, sub)
    return dict(t=t[idx], Y=Y[idx], W=W[idx], lab=lab[idx], dt=T / n_obs, T=T,
                branches=branches, kind='cubic')


def spoly(c, a, b, q, r):
    """g(w,t) = c + a t + b w + q w^2 + r w^3 (несимметричная улыбка, эффект рычага)."""
    p = np.zeros((4, 2))
    p[0, 0] = c; p[0, 1] = a; p[1, 0] = b; p[2, 0] = q; p[3, 0] = r
    return p


def nu_from_sbranches(branches, B, N):
    cur = {0: np.array([[1.0]])}
    for g in branches:
        fac = {0: -spoly(*g), 1: np.array([[1.0]])}
        new = {}
        for n1, p1 in cur.items():
            for n2, p2 in fac.items():
                pr = pmul(p1, p2); key = n1 + n2
                if key in new:
                    A = new[key]
                    K = max(A.shape[0], pr.shape[0]); Mx = max(A.shape[1], pr.shape[1])
                    Z = np.zeros((K, Mx))
                    Z[:A.shape[0], :A.shape[1]] += A
                    Z[:pr.shape[0], :pr.shape[1]] += pr
                    new[key] = Z
                else:
                    new[key] = pr
        cur = new
    nu = np.zeros(len(B)); need = 0
    for i, (n, k, m) in enumerate(B):
        P = cur.get(n)
        if P is not None and k < P.shape[0] and m < P.shape[1]:
            nu[i] = P[k, m]
    for n, P in cur.items():
        for k in range(P.shape[0]):
            for m in range(P.shape[1]):
                if abs(P[k, m]) > 1e-12:
                    need = max(need, k + m + n)
    return nu, need


def sval(g, w, t):
    c, a, b, q, r = g
    return c + a * t + b * w + q * w ** 2 + r * w ** 3


def sslope(g, w):
    return g[2] + 2 * g[3] * w + 3 * g[4] * w ** 2


def simulate_s(branches, T=1.0, n_obs=2500, sub=20, seed=0, p_switch=0.5, j0=0, refract=0.03):
    rng = np.random.default_rng(seed)
    n = n_obs * sub; dt = T / n
    W = np.r_[0.0, np.cumsum(rng.normal(0, np.sqrt(dt), n))]
    t = np.linspace(0, T, n + 1)
    G = np.array([sval(g, W, t) for g in branches])
    j = j0; lab = np.empty(n + 1, int); lab[0] = j
    Y = np.empty(n + 1); Y[0] = G[j, 0]; last = -1e9
    for i in range(1, n + 1):
        dp = G[:, i - 1] - G[j, i - 1]; dn = G[:, i] - G[j, i]
        cr = np.where(dp * dn < 0)[0]
        if len(cr) and t[i] - last >= refract and rng.random() < p_switch:
            j = int(cr[rng.integers(len(cr))]); last = t[i]
        Y[i] = G[j, i]; lab[i] = j
    idx = np.arange(0, n + 1, sub)
    return dict(t=t[idx], Y=Y[idx], W=W[idx], lab=lab[idx], dt=T / n_obs, T=T,
                branches=branches, kind='skew')
