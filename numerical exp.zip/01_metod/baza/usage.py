"""Диагностика занятости ветвей: какие ветви траектория действительно посещает."""
import numpy as np, sys
sys.path.insert(0,'/home/claude/work')
import msde as M

def driver(Y,t,dt,nu,B,N,D=None,band=None,kappa=None):
    if kappa is None: kappa=np.log(max(len(Y),2))
    ll,Wv,_=M.path_likelihood(Y,t,dt,nu,B,N,D,mode='max',band=band,tau=None,kappa=kappa)
    return ll,Wv

def occupancy_branches(Y,t,Wv,branches):
    """Явные аффинные ветви: доля времени, когда каждая ближе всех к траектории."""
    G=np.array([c+a*t+b*Wv for (c,a,b) in branches])
    j=np.argmin(np.abs(G-Y[None,:]),axis=0)
    res=np.min(np.abs(G-Y[None,:]),axis=0)
    return np.array([np.mean(j==k) for k in range(len(branches))]),j,res

def occupancy_slopes(Y,t,Wv,nu,B,N,tol=1e-6):
    """Общий случай: активная ветвь опознаётся по своему наклону b=-f_w/f_X.
    Возвращает наклон активной ветви и наклоны всех ветвей в каждый момент."""
    X=M.real_roots_grid(Wv,t,nu,B,N)
    sl=np.full_like(X,np.nan)
    for k in range(X.shape[1]):
        x=X[:,k]; ok=np.isfinite(x); xx=np.where(ok,x,0.)
        fx=M.f_X(xx,Wv,t,nu,B,N); fw=M.f_w(xx,Wv,t,nu,B,N)
        with np.errstate(divide='ignore',invalid='ignore'):
            sl[:,k]=np.where(ok&(np.abs(fx)>1e-12),-fw/fx,np.nan)
    act=np.argmin(np.abs(X-Y[:,None]),axis=1)
    b_act=sl[np.arange(len(Y)),act]
    return b_act,X,sl,act

def report(Y,t,dt,nu,B,N,branches=None,band=None):
    ll,Wv=driver(Y,t,dt,nu,B,N,band=band)
    if Wv is None: return None
    out={'ll':ll,'W':Wv}
    b_act,X,sl,act=occupancy_slopes(Y,t,Wv,nu,B,N)
    out['b_act']=b_act
    out['nreal']=np.sum(np.isfinite(X),axis=1)
    if branches is not None:
        occ,j,res=occupancy_branches(Y,t,Wv,branches)
        out['occ']=occ; out['lab']=j; out['res']=res
    return out
