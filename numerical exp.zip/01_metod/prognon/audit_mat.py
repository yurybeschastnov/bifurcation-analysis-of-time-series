"""Проверки математики ядра. Каждая может провалиться — в этом смысл.

Проверяется не то, что код запускается, а то, что он считает заявленное.
Запуск:  PYTHONPATH=../baza:../yadro python audit_mat.py
"""
import sys
sys.path.insert(0, '.')
import numpy as np
import msde as M, pipeline as P, examples3 as E3, classes as C, vetvi as V

OK, BAD = [], []


def check(nazv, uslovie, podrobno=''):
    (OK if uslovie else BAD).append(nazv)
    print('  %-56s %s %s' % (nazv, 'ок' if uslovie else 'ПРОВАЛ', podrobno))


print('1. ОБРАЩЕНИЕ ВЕТВИ: подстановка корня обратно в уравнение')
rng = np.random.default_rng(0)
for (c, a, b, r) in [(0.1, 0.05, 0.5, 0.3), (0.0, 0.0, 1.2, 0.0), (-0.2, 0.1, 0.35, 0.6)]:
    t = np.linspace(0, 1, 500); Y = rng.normal(0, 1, 500)
    W = V.koren_vetvi(Y, t, [(c, a, b, r)], 'cub')[:, 0]
    nev = np.max(np.abs(c + a * t + b * W + r * W ** 3 - Y))
    check('кубическое обращение b=%.2f r=%.2f' % (b, r), nev < 1e-8, 'невязка %.1e' % nev)

print('\n2. ВОЛАТИЛЬНОСТЬ: неявная -f_w/f_X против явной b+3rw^2')
d = E3.get('N6'); Y, t, dt = d['Y'], d['t'], d['dt']
keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40); kk = np.asarray(keep, bool)
br = d['branches']
ll, W, pv, dol = V.put(Y, t, dt, br, 'cub', keep, bref, po_vetvi=True)
tk, Yk = np.asarray(t)[kk], np.asarray(Y)[kk]
B_, D_ = C.basis_of('cub', 2); nu = C.nu_of('cub', br, B_, 2)
neyav = np.abs(-M.f_w(Yk, W, tk, nu, B_, 2) / M.f_X(Yk, W, tk, nu, B_, 2))
yav = np.array([abs(br[j][2] + 3 * br[j][3] * w ** 2) for j, w in zip(pv, W)])
otn = np.max(np.abs(neyav / yav - 1))
check('sigma = dg/dw от корней f=0', otn < 1e-8, 'макс отн. разн %.1e' % otn)

print('\n3. ПРАВДОПОДОБИЕ ПРИ ОДНОЙ ВЕТВИ: замкнутая гауссова форма')
c0, a0, b0 = 0.0, 0.10, 0.90
d1 = E3.get('L1'); Y1, t1, dt1 = d1['Y'], d1['t'], d1['dt']
k1 = P.censor_mask(Y1, t1, dt1); br1 = M.local_vol(Y1, dt1, 40); m1 = np.asarray(k1, bool)
Ym, tm = np.asarray(Y1)[m1], np.asarray(t1)[m1]
dY, dT = np.diff(Ym), np.diff(tm)
zam = float(np.sum(-(dY - a0 * dT) ** 2 / (2 * b0 ** 2 * dT)
                   - 0.5 * np.log(2 * np.pi * b0 ** 2 * dT)))
lp = V.put(Y1, t1, dt1, [(c0, a0, b0)], 'aff', k1, br1, po_vetvi=True)[0]
lsum, _ = V.put_summa(Y1, t1, dt1, [(c0, a0, b0)], 'aff', k1, br1)
check('профильное = замкнутая форма', abs(lp - zam) < 1e-6, 'разн %.2e' % abs(lp - zam))
check('маргинальное = замкнутая форма', abs(lsum - zam) < 1e-6, 'разн %.2e' % abs(lsum - zam))
check('при одной ветви сумма = максимуму', abs(lsum - lp) < 1e-6, 'разн %.2e' % abs(lsum - lp))

print('\n4. ТОЖДЕСТВО при kappa=0: ранг против ветви')
d3 = E3.get('L3'); Y3, t3, dt3 = d3['Y'], d3['t'], d3['dt']
k3 = P.censor_mask(Y3, t3, dt3); b3 = M.local_vol(Y3, dt3, 40)
qa = V.put(Y3, t3, dt3, d3['branches'], 'aff', k3, b3, kappa=0.0, po_vetvi=False)[0]
qb = V.put(Y3, t3, dt3, d3['branches'], 'aff', k3, b3, kappa=0.0, po_vetvi=True)[0]
check('при kappa=0 варианты совпадают', abs(qa - qb) < 1e-9, 'разн %.2e' % abs(qa - qb))

print('\n5. СУММА ПО ПУТЯМ НЕ МЕНЬШЕ МАКСИМУМА')
hudo = []
for key in ['L2', 'L3', 'L6', 'N1', 'N4', 'N6']:
    dd = E3.get(key); kind = 'aff' if key[0] == 'L' else 'cub'
    kp = P.censor_mask(dd['Y'], dd['t'], dd['dt']); bp = M.local_vol(dd['Y'], dd['dt'], 40)
    a = V.put(dd['Y'], dd['t'], dd['dt'], dd['branches'], kind, kp, bp, po_vetvi=True)[0]
    b, _ = V.put_summa(dd['Y'], dd['t'], dd['dt'], dd['branches'], kind, kp, bp)
    if b < a - 1e-6:
        hudo.append((key, a, b))
check('сумма >= максимума', not hudo, str(hudo[:2]))

print('\n6. АПОСТЕРИОРНЫЕ ВЕРОЯТНОСТИ')
lm, gam = V.put_summa(Y, t, dt, br, 'cub', keep, bref)
s1 = float(np.max(np.abs(gam.sum(axis=1) - 1.0)))
check('gamma суммируется в единицу', s1 < 1e-8, 'макс отклонение %.1e' % s1)
check('argmax gamma близок к пути Витерби',
      float(np.mean(np.argmax(gam, axis=1) == np.asarray(pv))) > 0.9)

print('\nИТОГ: пройдено %d, провалено %d' % (len(OK), len(BAD)))
if BAD:
    print('ПРОВАЛЕНО:', BAD)
