"""Батарея правил выбора числа режимов и честная их проверка.

Правила делятся на два класса, и смешивать их при отчёте нельзя.

  БЕЗ ПОРОГА   значение вычисляется и сравнивается между степенями; свободных
               постоянных нет, подгонять нечего. Сюда входят все варианты
               информационного критерия и удержанный прогнозный скор.

  С ПОРОГОМ    решение принимается сравнением с постоянной, которую надо откуда-то
               взять. Если постоянная выбрана по тому же набору рядов, на котором
               потом считается доля верных ответов, то доля верных ответов ничего
               не значит. Поэтому для таких правил считается СКОЛЬЗЯЩИЙ КОНТРОЛЬ:
               порог подбирается по двенадцати рядам, проверяется на тринадцатом,
               и так тринадцать раз.

Диагностика приращений драйвера. Модель утверждает, что W есть стандартный
винеровский процесс, то есть величины z_i = dW_i / sqrt(dt_i) независимы и
распределены как N(0,1). Проверяется это не одной статистикой, а всеми
свойствами сразу:

    var(z)          должна равняться единице (это и есть условие на квадратичную
                    вариацию, записанное иначе)
    LB(z)           отсутствие автокорреляции самих приращений
    LB(z^2)         отсутствие кластеризации волатильности; именно она остаётся,
                    когда режимов взято меньше, чем есть
    эксцесс(z)      нормальность хвостов

Занижение степени проявляется прежде всего в LB(z^2) и эксцессе: необъяснённая
смена волатильности выглядит как кластеризация и тяжёлые хвосты.
"""
import sys, pickle, itertools
sys.path.insert(0, '.')
import numpy as np
import msde as M, pipeline as P, examples3 as E3, vetvi as V

R = pickle.load(open('stepen.pkl', 'rb'))
IST = {k: v[0] for k, v in E3.LIN.items()}
IST.update({k: v[0] for k, v in E3.CUB.items()})
ORD = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
KAP = np.linspace(2.5, 9.0, 14)


def diagnostika(W, tt):
    """Свойства приращений драйвера: z = dW/sqrt(dt) ~ iid N(0,1)."""
    z = np.diff(W) / np.sqrt(np.diff(tt))
    z = z[np.isfinite(z)]
    if len(z) < 50:
        return dict(var=np.nan, lb1=np.nan, lb2=np.nan, kurt=np.nan)
    return dict(var=float(np.var(z)),
                lb1=float(M.ljung_box(z, h=20)),
                lb2=float(M.ljung_box(z ** 2, h=20)),
                kurt=float(np.mean((z - z.mean()) ** 4) / np.var(z) ** 2 - 3))


def sobrat():
    """Все статистики для каждой пары (ряд, степень)."""
    T = {}
    for key in ORD:
        br_ist = IST[key]; K = len(br_ist)
        kind = 'aff' if key.startswith('L') else 'cub'
        p = 4 if kind == 'cub' else 3
        d = E3.get(key); Y, t, dt = d['Y'], d['t'], d['dt']
        keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40)
        kk = np.asarray(keep, bool); n = int(kk.sum())
        tt = np.asarray(t)[kk]; lab = np.asarray(d['lab'])[kk]
        for N in range(1, K + 2):
            v = R.get('%s|%d' % (key, N))
            if not v:
                continue
            lp, W, pv, dol = V.put(Y, t, dt, v['branches'], kind, keep, bref, po_vetvi=True)
            if W is None:
                continue
            ls, g = V.put_summa(Y, t, dt, v['branches'], kind, keep, bref)
            if not np.isfinite(ls):
                continue
            # kappa по максимуму точного правдоподобия
            bst, kbst = -np.inf, np.log(n)
            for kp in KAP:
                l2, _ = V.put_summa(Y, t, dt, v['branches'], kind, keep, bref, kappa=kp)
                if np.isfinite(l2) and l2 > bst:
                    bst, kbst = l2, kp
            lpk, Wk, pvk, dolk = V.put(Y, t, dt, v['branches'], kind, keep, bref,
                                       kappa=kbst, po_vetvi=True)
            dg = diagnostika(W, tt)
            T[(key, N)] = dict(
                K=K, kind=kind, n=n,
                ll_prof=float(lp), ll_sum=float(ls), ll_sum_k=float(bst), kappa=float(kbst),
                bic=float(-2 * ls + (p * N - 1) * np.log(n)),
                bic_k=float(-2 * bst + (p * N) * np.log(n)),
                bic_prof=float(-2 * lp + (p * N - 1) * np.log(n)),
                zan=float(min(dol)), ap_zan=float(g.mean(axis=0).min()),
                perekl=int((np.diff(pv) != 0).sum()),
                perekl_k=int((np.diff(pvk) != 0).sum()) if pvk is not None else -1,
                perekl_ist=int((np.diff(lab) != 0).sum()),
                **dg)
    return T


def vybor_bezporoga(T, key, pole):
    """Степень с наименьшим значением критерия."""
    c = {N: v[pole] for (k, N), v in T.items() if k == key and np.isfinite(v[pole])}
    return min(c, key=c.get) if c else None


def vybor_porog(T, key, pole, por, storona='>'):
    """Наибольшая степень, проходящая порог."""
    ok = [N for (k, N), v in T.items() if k == key and np.isfinite(v[pole])
          and (v[pole] > por if storona == '>' else v[pole] < por)]
    return max(ok) if ok else 1


if __name__ == '__main__':
    T = sobrat()
    pickle.dump(T, open('batareya.pkl', 'wb'))
    print('собрано пар (ряд, степень): %d' % len(T))
    print('\n%-4s %-2s %-2s %9s %8s %7s %8s %8s %7s %6s'
          % ('ряд', 'K', 'N', 'll сумма', 'kappa', 'зан', 'ап.зан', 'LB(z^2)', 'экс', 'var'))
    for key in ORD:
        K = len(IST[key])
        for N in range(1, K + 2):
            v = T.get((key, N))
            if not v:
                continue
            print('%-4s %-2s %-2d %9.1f %8.2f %7.3f %8.3f %8.0f %7.2f %6.3f %s'
                  % (key if N == 1 else '', K if N == 1 else '', N, v['ll_sum_k'], v['kappa'],
                     v['zan'], v['ap_zan'], v['lb2'], v['kurt'], v['var'],
                     '<-' if N == K else ''))
