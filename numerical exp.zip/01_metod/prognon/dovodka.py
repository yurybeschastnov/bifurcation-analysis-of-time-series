"""Доводка всех кубических подгонок в координатах опорных значений sigma.

Доводятся ВСЕ степени, а не только истинная: если улучшить подгонку лишь при
верном числе режимов, сравнение правил выбора степени станет подтасовкой.
"""
import sys, os, time, pickle
sys.path.insert(0, '.')
import numpy as np
import msde as M, pipeline as P, examples3 as E3, vetvi as V, podgonka as PG

R = pickle.load(open('stepen.pkl', 'rb'))
IST = {k: v[0] for k, v in E3.CUB.items()}
ORD = ['N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
LOG = 'dovodka.pkl'
D = pickle.load(open(LOG, 'rb')) if os.path.exists(LOG) else {}

bud = float(sys.argv[1]) if len(sys.argv) > 1 else 250.
t0 = time.time()
for key in ORD:
    K = len(IST[key])
    for N in range(2, K + 2):
        kk = '%s|%d' % (key, N)
        if kk in D or kk not in R:
            continue
        if time.time() - t0 > bud - 70:
            print('пауза'); sys.exit(0)
        d = E3.get(key); Y, t, dt = d['Y'], d['t'], d['dt']
        keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40)
        st = time.time()
        r = PG.dovesti_sigma(Y, t, dt, R[kk]['branches'], keep, bref, vnesh=3, maxiter=600)
        D[kk] = dict(ll_old=R[kk]['ll'], ll=r['ll'], branches=r['branches'])
        if r['ll'] > R[kk]['ll'] + 0.05:
            v = dict(R[kk]); v['ll'] = r['ll']; v['branches'] = r['branches']
            ll, W, pv, dol = V.put(Y, t, dt, r['branches'], 'cub', keep, bref, po_vetvi=True)
            if dol is not None:
                v['dolya'] = list(dol)
            R[kk] = v
            pickle.dump(R, open('stepen.pkl', 'wb'))
        pickle.dump(D, open(LOG, 'wb'))
        print('%-4s N=%d  ll %9.1f -> %9.1f  (%+.1f)  %s  (%.0f с)'
              % (key, N, D[kk]['ll_old'], D[kk]['ll'], D[kk]['ll'] - D[kk]['ll_old'],
                 'r=' + str([round(g[3], 2) for g in sorted(r['branches'], key=lambda z: z[2])]),
                 time.time() - st))
        sys.stdout.flush()
print('ВСЁ')
