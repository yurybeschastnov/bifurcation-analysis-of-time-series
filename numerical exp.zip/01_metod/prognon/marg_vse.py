"""Доводка по маргинальному правдоподобию для ВСЕХ степеней всех рядов.

Применять только к истинной степени нельзя: сравнение степеней ведётся по тому
же маргинальному правдоподобию, и улучшив его выборочно, мы подтасуем выбор.
"""
import sys, os, time, pickle
sys.path.insert(0, '.')
import numpy as np
import msde as M, pipeline as P, examples3 as E3, vetvi as V, podgonka as PG

R = pickle.load(open('stepen.pkl', 'rb'))
T = pickle.load(open('batareya.pkl', 'rb'))
IST = {k: v[0] for k, v in E3.LIN.items()}
IST.update({k: v[0] for k, v in E3.CUB.items()})
ORD = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
LOG = 'marg.pkl'
D = pickle.load(open(LOG, 'rb')) if os.path.exists(LOG) else {}

bud = float(sys.argv[1]) if len(sys.argv) > 1 else 250.
t0 = time.time()
for key in ORD:
    K = len(IST[key]); kind = 'aff' if key.startswith('L') else 'cub'
    for N in range(1, K + 2):
        kk = '%s|%d' % (key, N)
        if kk in D or kk not in R:
            continue
        if time.time() - t0 > bud - 75:
            print('пауза'); sys.exit(0)
        d = E3.get(key); Y, t, dt = d['Y'], d['t'], d['dt']
        keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40)
        kap = T[(key, N)]['kappa'] if (key, N) in T else None
        st = time.time()
        r = PG.dovesti_marg(Y, t, dt, R[kk]['branches'], kind, keep, bref,
                            kappa=kap, maxiter=400)
        # принимаем только при росте маргинального правдоподобия
        if r['ll_marg'] > r['ll_marg0'] + 1e-9:
            lh = V.put(Y, t, dt, r['branches'], kind, keep, bref, po_vetvi=True)[0]
            if np.isfinite(lh) and lh > -1e5:
                v = dict(R[kk]); v['branches'] = r['branches']; v['ll'] = float(lh)
                ll, W, pv, dol = V.put(Y, t, dt, r['branches'], kind, keep, bref,
                                       po_vetvi=True)
                if dol is not None:
                    v['dolya'] = list(dol)
                R[kk] = v; pickle.dump(R, open('stepen.pkl', 'wb'))
        D[kk] = dict(m0=r['ll_marg0'], m1=r['ll_marg'])
        pickle.dump(D, open(LOG, 'wb'))
        print('%-4s N=%d  marg %9.1f -> %9.1f (%+.1f)  (%.0f с)'
              % (key, N, r['ll_marg0'], r['ll_marg'], r['ll_marg'] - r['ll_marg0'],
                 time.time() - st))
        sys.stdout.flush()
print('ВСЁ')
