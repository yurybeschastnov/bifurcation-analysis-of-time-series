"""Восстановление параметров ветвей: b, r и метки режимов.

Сравнивается не только функция sigma, но и сами коэффициенты, как просили.
Сопоставление режимов — венгерским алгоритмом по матрице совпадений меток, а
не сортировкой по уровню: у нелинейных ветвей порядок sigma меняется вдоль w,
поэтому сортировка даёт неверные пары.

Путь берётся при kappa, оценённом по точному правдоподобию, а не при
фиксированном log n: фиксированное значение отвечает одному ожидаемому
переключению на траекторию, тогда как истинных на этих рядах от 8 до 20.
"""
import sys, pickle
sys.path.insert(0, '.')
import numpy as np
from scipy.optimize import linear_sum_assignment
import msde as M, pipeline as P, examples3 as E3, vetvi as V

R = pickle.load(open('stepen.pkl', 'rb'))
T = pickle.load(open('batareya.pkl', 'rb'))
IST = {k: v[0] for k, v in E3.LIN.items()}
IST.update({k: v[0] for k, v in E3.CUB.items()})
ORD = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']


def sig(g, w, kind):
    r = g[3] if kind == 'cub' else 0.0
    return np.abs(g[2] + 3.0 * r * np.asarray(w) ** 2)


def ocenit(key):
    br_ist = IST[key]; K = len(br_ist)
    kind = 'aff' if key.startswith('L') else 'cub'
    v = R.get('%s|%d' % (key, K))
    if not v:
        return None
    kap = T[(key, K)]['kappa'] if (key, K) in T else None
    d = E3.get(key); Y, t, dt = d['Y'], d['t'], d['dt']
    keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40)
    kk = np.asarray(keep, bool)
    ll, W, pv, dol = V.put(Y, t, dt, v['branches'], kind, keep, bref,
                           kappa=kap, po_vetvi=True)
    if W is None:
        return None
    # мягкая разметка: наиболее вероятное состояние по прямо-обратному проходу.
    # Она точнее жёсткой по Витерби, поскольку не приписывает всю массу одному
    # пути: на ряде Л4 доля верных меток 0,958 против 0,945.
    lm, gam = V.put_summa(Y, t, dt, v['branches'], kind, keep, bref, kappa=kap)
    pv_g = np.argmax(gam, axis=1) if gam is not None else np.asarray(pv)
    lab = np.asarray(d['lab'])[kk]; Wi = np.asarray(d['W'])[kk]
    pv = np.asarray(pv_g)
    C = np.zeros((K, K))
    for a in range(K):
        for b in range(K):
            C[a, b] = -np.sum((pv == a) & (lab == b))
    ra, ca = linear_sum_assignment(C)
    m = {int(a): int(b) for a, b in zip(ra, ca)}
    obr = {b: a for a, b in m.items()}
    pv_m = np.array([m.get(int(j), -1) for j in pv])
    tochn = float(np.mean(pv_m == lab))
    # L2-сравнение функции волатильности. Для рядов Н sigma_j(w) есть функция,
    # поэтому скалярной сводки (медианы) недостаточно: две разные функции могут
    # иметь одну медиану. Сравниваются два способа:
    #   по времени  ||sigma^(t) - sigma(t)||_2 / ||sigma(t)||_2 вдоль траектории,
    #               где sigma^(t) берётся на восстановленном драйвере и своей
    #               ветви, а sigma(t) — на истинном; это волатильность как
    #               наблюдаемая величина, и матрица меток тут не нужна;
    #   по ветви    та же норма, но по посещённой ветвью области, с мерой,
    #               задаваемой эмпирическим распределением драйвера.
    s_i_t = np.array([sig(br_ist[j], w, kind) for j, w in zip(lab, Wi)])
    s_o_t = np.array([sig(v['branches'][j], w, kind) for j, w in zip(pv, W)])
    L2_t = float(np.sqrt(np.sum((s_o_t - s_i_t) ** 2) / np.sum(s_i_t ** 2)))
    rows = []; L2b = []
    for b in range(K):
        gi = br_ist[b]; a = obr.get(b)
        go = v['branches'][a] if a is not None else None
        mm = (lab == b)
        s_i = float(np.median(sig(gi, Wi[mm], kind))) if mm.sum() > 5 else np.nan
        nn = (pv == a)
        s_o = float(np.median(sig(go, W[nn], kind))) if (go and nn.sum() > 5) else np.nan
        if go is not None and mm.sum() > 5:
            si = sig(gi, Wi[mm], kind); so = sig(go, Wi[mm], kind)
            L2b.append(float(np.sqrt(np.sum((so - si) ** 2) / np.sum(si ** 2))))
        rows.append(dict(b_ist=gi[2], b_oc=(go[2] if go else np.nan),
                         r_ist=(gi[3] if kind == 'cub' else 0.0),
                         r_oc=((go[3] if kind == 'cub' else 0.0) if go else np.nan),
                         s_ist=s_i, s_oc=s_o))
    return dict(kind=kind, K=K, kappa=kap, tochn=tochn, rows=rows,
                L2_t=L2_t, L2b=L2b,
                perekl=int((np.diff(pv) != 0).sum()),
                perekl_ist=int((np.diff(lab) != 0).sum()))


if __name__ == '__main__':
    print('ВОССТАНОВЛЕНИЕ ПАРАМЕТРОВ ВЕТВЕЙ ПРИ ИСТИННОЙ СТЕПЕНИ')
    print('(kappa оценён по точному правдоподобию; метки сопоставлены венгерским алгоритмом)\n')
    print('%-4s %-6s %-6s %-8s %-9s %s' %
          ('ряд', 'метки', 'перекл', 'L2 sig', 'L2 по ветв', 'sigma истина -> оценка'))
    eb, er, es, er_v, L2all = [], [], [], [], []
    for key in ORD:
        o = ocenit(key)
        if not o:
            continue
        bs = ' '.join('%.2f>%.2f' % (r['b_ist'], r['b_oc']) for r in o['rows'])
        rs = ' '.join('%.2f>%.2f' % (r['r_ist'], r['r_oc']) for r in o['rows']) \
            if o['kind'] == 'cub' else '-'
        ss = ' '.join('%.2f>%.2f' % (r['s_ist'], r['s_oc']) for r in o['rows'])
        print('%-4s %6.3f %3d/%-3d %6.1f%% %s  %s'
              % (key, o['tochn'], o['perekl'], o['perekl_ist'], 100 * o['L2_t'],
                 ' '.join('%.1f%%' % (100 * x) for x in o['L2b']), ss))
        L2all.append(o['L2_t'])
        for r in o['rows']:
            if np.isfinite(r['b_oc']) and r['b_ist'] > 0:
                eb.append(abs(r['b_oc'] / r['b_ist'] - 1))
            if o['kind'] == 'cub' and np.isfinite(r['r_oc']):
                er.append(abs(r['r_oc'] - r['r_ist']))          # АБСОЛЮТНАЯ ошибка
                if r['r_ist'] > 0.15:
                    er_v.append(abs(r['r_oc'] / r['r_ist'] - 1))
            if np.isfinite(r['s_oc']) and r['s_ist'] > 0:
                es.append(abs(r['s_oc'] / r['s_ist'] - 1))
    print('\nb:     медиана отн. ошибки %.1f%%,  90%% квантиль %.1f%%'
          % (100 * np.median(eb), 100 * np.percentile(eb, 90)))
    print('sigma: медиана отн. ошибки %.1f%%,  90%% квантиль %.1f%%'
          % (100 * np.median(es), 100 * np.percentile(es, 90)))
    print('r:     медиана АБСОЛЮТНОЙ ошибки %.3f,  90%% квантиль %.3f  (шкала r: 0..0.60)'
          % (np.median(er), np.percentile(er, 90)))
    print('L2-ошибка sigma по траектории: медиана %.1f%%, макс %.1f%%'
          % (100 * np.median(L2all), 100 * np.max(L2all)))
    print('r при выраженной кривизне (r>0.15): медиана отн. ошибки %.1f%%  (n=%d)'
          % (100 * np.median(er_v), len(er_v)))
