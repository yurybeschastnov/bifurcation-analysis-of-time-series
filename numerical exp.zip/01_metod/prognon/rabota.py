"""Параллельный прогон множественных реализаций.

Задача тривиально распараллеливается по парам (ряд, посев): реализации
независимы. Поэтому здесь всё считается пулом процессов, а не подряд.

Прогон возобновляемый: результат каждой реализации дописывается в файл сразу,
поэтому прервать и продолжить можно в любой момент.
"""
import os, sys, time, pickle
import numpy as np
from scipy.optimize import linear_sum_assignment

import msde as M, pipeline as P, examples3 as E3, synth as S, synth3 as S3
import vetvi as V, podgonka as PG

N_OBS = 800          # длина ряда: втрое дешевле полной 2501 при тех же свойствах
N_REAL = 40          # реализаций на ряд
OCC_MIN = 0.15       # порог минимальной занятости режима
FN = 'real40.pkl'
SEEDS = 'real40_seeds.pkl'

IST = {k: ('aff',) + v for k, v in E3.LIN.items()}
IST.update({k: ('cub',) + v for k, v in E3.CUB.items()})
ORD = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']


def postroit(key, seed, n_obs=N_OBS):
    kind, br, sd0, rf, desc = IST[key]
    f = S.simulate if kind == 'aff' else S3.simulate_c
    d = f(br, T=1., n_obs=n_obs, sub=20, seed=seed, refract=rf)
    d.update(kind=kind, branches=br)
    lab = np.asarray(d['lab'])
    occ = np.array([np.mean(lab == j) for j in range(len(br))])
    return d, float(occ.min())


def otobrat(nado=N_REAL, max_probe=6000, put=SEEDS):
    """Отбор посевов со сбалансированной занятостью. Генерация дешёвая,
    поэтому делается последовательно и один раз."""
    SD = pickle.load(open(put, 'rb')) if os.path.exists(put) else {}
    for key in ORD:
        if key in SD and len(SD[key]['ok']) >= nado:
            continue
        ok, vsego, seed = [], 0, 10000
        while len(ok) < nado and vsego < max_probe:
            _, occ = postroit(key, seed)
            vsego += 1
            if occ >= OCC_MIN:
                ok.append(seed)
            seed += 1
        SD[key] = dict(ok=ok, vsego=vsego, dolya=len(ok) / max(vsego, 1))
        pickle.dump(SD, open(put, 'wb'))
        print('%-4s принято %d из %d, отбраковка %.0f%%'
              % (key, len(ok), vsego, 100 * (1 - SD[key]['dolya'])))
        sys.stdout.flush()
    return SD


def _sig(g, w, kind):
    r = g[3] if kind == 'cub' else 0.0
    return np.abs(g[2] + 3.0 * r * np.asarray(w) ** 2)


def odna(zadacha):
    """Одна реализация целиком. Чистая функция: годится для пула процессов."""
    key, seed = zadacha
    try:
        kind, br_ist = IST[key][0], IST[key][1]
        K = len(br_ist)
        d, occ = postroit(key, seed)
        Y, t, dt = d['Y'], d['t'], d['dt']
        keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40)
        kk = np.asarray(keep, bool)
        lab = np.asarray(d['lab'])[kk]; Wi = np.asarray(d['W'])[kk]
        n = int(kk.sum()); p = 4 if kind == 'cub' else 3

        fits, bic = {}, {}
        pred = None
        for N in range(1, K + 2):
            r = PG.podognat5(Y, t, dt, N, kind, keep, bref, br_pred=pred,
                             n_sobol=24, n_dovodka=2, maxiter=300, seed=7)
            if kind == 'cub' and N >= 2:
                r2 = PG.dovesti_sigma(Y, t, dt, r['branches'], keep, bref,
                                      vnesh=2, maxiter=300)
                if r2['ll'] > r['ll']:
                    r = dict(r); r['branches'] = r2['branches']; r['ll'] = r2['ll']
            rm = PG.dovesti_marg(Y, t, dt, r['branches'], kind, keep, bref, maxiter=250)
            if rm['ll_marg'] > rm['ll_marg0']:
                r = dict(r); r['branches'] = rm['branches']
            ls, g = V.put_summa(Y, t, dt, r['branches'], kind, keep, bref)
            if not np.isfinite(ls):
                continue
            fits[N] = r['branches']; bic[N] = -2 * ls + (p * N - 1) * np.log(n)
            pred = r['branches']
        if not bic:
            return (key, seed, None)
        nb = min(bic, key=bic.get)
        out = dict(seed=seed, occ=occ, K_bic=nb, verno=bool(nb == K))

        br = fits.get(K)
        if br is not None:
            ll, W, pv, dol = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)
            lm, gam = V.put_summa(Y, t, dt, br, kind, keep, bref)
            pv_g = np.argmax(gam, axis=1) if gam is not None else np.asarray(pv)
            s_i = np.array([_sig(br_ist[j], w, kind) for j, w in zip(lab, Wi)])
            s_o = np.array([_sig(br[j], w, kind) for j, w in zip(pv_g, W)])
            C = np.zeros((K, K))
            for a in range(K):
                for b in range(K):
                    C[a, b] = -np.sum((pv_g == a) & (lab == b))
            ra, ca = linear_sum_assignment(C)
            m = {int(a): int(b) for a, b in zip(ra, ca)}
            out.update(
                L2=float(np.sqrt(np.sum((s_o - s_i) ** 2) / np.sum(s_i ** 2))),
                metki=float(np.mean(np.array([m.get(int(j), -1) for j in pv_g]) == lab)),
                perekl=int((np.diff(pv_g) != 0).sum()),
                perekl_ist=int((np.diff(lab) != 0).sum()),
                b_ist=[float(g[2]) for g in br_ist],
                b_oc=[float(br[m2][2]) if (m2 := [a for a, b2 in m.items() if b2 == j])
                      else float('nan') for j in range(K)] if False else None)
        return (key, seed, out)
    except Exception as e:
        return (key, seed, {'oshibka': repr(e)})


def prognat(n_jobs=None, ryady=None, fn=FN):
    """Параллельный прогон. n_jobs=None -> по числу ядер."""
    import multiprocessing as mp
    SD = otobrat()
    R = pickle.load(open(fn, 'rb')) if os.path.exists(fn) else {}
    zad = [(k, s) for k in (ryady or ORD) for s in SD[k]['ok']
           if '%s|%d' % (k, s) not in R]
    if not zad:
        print('всё уже посчитано'); return R
    n_jobs = n_jobs or max(1, mp.cpu_count())
    print('осталось реализаций: %d,  процессов: %d' % (len(zad), n_jobs))
    sys.stdout.flush()
    t0 = time.time(); sdel = 0
    with mp.Pool(n_jobs) as pool:
        for key, seed, res in pool.imap_unordered(odna, zad, chunksize=1):
            R['%s|%d' % (key, seed)] = res
            sdel += 1
            if sdel % 5 == 0 or sdel == len(zad):
                pickle.dump(R, open(fn, 'wb'))
            pr = sdel / len(zad)
            ost = (time.time() - t0) * (1 - pr) / max(pr, 1e-9)
            print('  %4d/%d  %-4s %s   осталось ~%.0f мин'
                  % (sdel, len(zad), key,
                     ('BIC=%d %s' % (res['K_bic'], 'v' if res['verno'] else 'X'))
                     if res and 'K_bic' in res else 'сбой', ost / 60))
            sys.stdout.flush()
    pickle.dump(R, open(fn, 'wb'))
    return R


def svodka(fn=FN, put_seeds=SEEDS):
    R = pickle.load(open(fn, 'rb'))
    SD = pickle.load(open(put_seeds, 'rb')) if os.path.exists(put_seeds) else {}
    print('\nМНОЖЕСТВЕННЫЕ РЕАЛИЗАЦИИ, длина %d, порог занятости %.2f' % (N_OBS, OCC_MIN))
    print('=' * 88)
    print('%-4s %-3s %-8s %-11s %-12s %-22s %s'
          % ('ряд', 'K', 'сделано', 'отбраковка', 'BIC верно', 'L2 sigma  мед (10-90%)',
             'метки мед'))
    vs_v, vs_n = 0, 0
    for key in ORD:
        L = [v for k, v in R.items() if k.startswith(key + '|') and v and 'K_bic' in v]
        if not L:
            continue
        K = len(IST[key][1])
        dol = SD.get(key, {}).get('dolya', float('nan'))
        v = sum(1 for x in L if x['verno']); vs_v += v; vs_n += len(L)
        l2 = [x['L2'] for x in L if 'L2' in x]
        mt = [x['metki'] for x in L if 'metki' in x]
        oshib = {}
        for x in L:
            if not x['verno']:
                oshib[x['K_bic']] = oshib.get(x['K_bic'], 0) + 1
        print('%-4s %-3d %-8d %-11.0f%% %-12s %-22s %-9s %s'
              % (key, K, len(L), 100 * (1 - dol), '%d/%d' % (v, len(L)),
                 ('%.1f%%  (%.1f-%.1f)' % (100 * np.median(l2),
                                           100 * np.percentile(l2, 10),
                                           100 * np.percentile(l2, 90))) if l2 else '-',
                 ('%.3f' % np.median(mt)) if mt else '-',
                 ('ошибки: ' + ', '.join('%d раз ->%d' % (c, kk2)
                                         for kk2, c in sorted(oshib.items()))) if oshib else ''))
    if vs_n:
        print('\nВСЕГО: %d реализаций, число режимов верно в %d (%.1f%%)'
              % (vs_n, vs_v, 100 * vs_v / vs_n))
    return R
