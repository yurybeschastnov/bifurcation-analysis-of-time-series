"""Все рисунки статьи, 350 dpi. Возобновляемый: готовые не перерисовывает.

    python risunki.py [бюджет_секунд]
"""
import sys, os, time, pickle
sys.path.insert(0, '.')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import msde as M, pipeline as P, examples3 as E3, vetvi as V

plt.rcParams.update({
    'font.size': 8.5, 'axes.linewidth': .7, 'legend.frameon': False,
    'savefig.dpi': 350, 'figure.dpi': 110, 'savefig.bbox': 'tight',
    'savefig.pad_inches': .05, 'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': True, 'grid.alpha': .25, 'grid.linewidth': .5})

PAL = ['#2e7d32', '#ef6c00', '#c62828', '#5e35b1', '#0277bd']
OUT = 'ris'
os.makedirs(OUT, exist_ok=True)

R = pickle.load(open('stepen.pkl', 'rb'))
T = pickle.load(open('batareya.pkl', 'rb'))
IST = {k: v[0] for k, v in E3.LIN.items()}
IST.update({k: v[0] for k, v in E3.CUB.items()})
ORD = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
RUS = {k: k.replace('L', 'Л').replace('N', 'Н') for k in ORD}


def sig(g, w, kind):
    r = g[3] if kind == 'cub' else 0.0
    return np.abs(g[2] + 3.0 * r * np.asarray(w) ** 2)


def gval(g, t, w, kind):
    r = g[3] if kind == 'cub' else 0.0
    return g[0] + g[1] * t + g[2] * w + r * np.asarray(w) ** 3


def dan(key):
    d = E3.get(key)
    return d, P.censor_mask(d['Y'], d['t'], d['dt']), M.local_vol(d['Y'], d['dt'], 40)


def podgonka(key, N=None):
    K = len(IST[key]); N = N or K
    kind = 'aff' if key.startswith('L') else 'cub'
    d, keep, bref = dan(key)
    br = R['%s|%d' % (key, N)]['branches']
    kap = T[(key, N)]['kappa'] if (key, N) in T else None
    ll, W, pv, dol = V.put(d['Y'], d['t'], d['dt'], br, kind, keep, bref,
                           kappa=kap, po_vetvi=True)
    lm, gam = V.put_summa(d['Y'], d['t'], d['dt'], br, kind, keep, bref, kappa=kap)
    pv_g = np.argmax(gam, axis=1) if gam is not None else np.asarray(pv)
    return d, keep, bref, br, kind, W, np.asarray(pv_g), dol


def gotov(nm):
    return os.path.exists('%s/%s.png' % (OUT, nm))


def fig_ryad(key):
    nm = 'ryad_%s' % key
    if gotov(nm):
        return
    d, keep, bref, br, kind, W, pv, dol = podgonka(key)
    K = len(br); kk = np.asarray(keep, bool)
    Yk, tk = np.asarray(d['Y'])[kk], np.asarray(d['t'])[kk]
    fig = plt.figure(figsize=(7.4, 6.2))
    gs = fig.add_gridspec(3, 3, height_ratios=[1.15, 1, 1], hspace=.5, wspace=.3)
    ax = fig.add_subplot(gs[0, :])
    ax.plot(tk, Yk, color='0.15', lw=.55)
    gran = np.where(np.diff(pv) != 0)[0]
    for a, b in zip(np.r_[0, gran + 1], np.r_[gran + 1, len(pv)]):
        ax.axvspan(tk[a], tk[min(b, len(tk) - 1)], color=PAL[pv[a] % len(PAL)],
                   alpha=.16, lw=0)
    leg = []
    for j in range(K):
        m = (pv == j)
        s = sig(br[j], W[m], kind) if m.sum() > 5 else np.array([np.nan])
        pod = (r'$g_%d$: $\partial g/\partial w=%.2f$' % (j + 1, np.median(s))) if kind == 'aff' \
            else (r'$g_%d$: $%.2f\ldots%.2f$'
                  % (j + 1, np.nanpercentile(s, 5), np.nanpercentile(s, 95)))
        leg.append(Patch(facecolor=PAL[j % len(PAL)], alpha=.35, label=pod))
    ax.legend(handles=leg, fontsize=6.6, loc='upper left', bbox_to_anchor=(1.005, 1.0))
    ax.set_xlabel('$t$'); ax.set_ylabel('$Y_t$')
    ax.set_title('ряд %s: траектория с восстановленными режимами' % RUS[key], fontsize=9)
    ww = np.linspace(np.percentile(W, 1), np.percentile(W, 99), 200)
    for c, ts in enumerate([0.20, 0.50, 0.80]):
        okno = np.abs(tk - ts) < 0.06
        a1 = fig.add_subplot(gs[1, c])
        for j in range(K):
            a1.plot(ww, gval(br[j], ts, ww, kind), color=PAL[j % len(PAL)], lw=1.2)
        a1.plot(W[okno], Yk[okno], '.', color='0.2', ms=1.6)
        a1.set_xlabel('$w$'); a1.tick_params(labelsize=7)
        a1.text(.97, .05, '$t=%.2f$' % ts, transform=a1.transAxes, ha='right', fontsize=7.5)
        if c == 0:
            a1.set_ylabel('$g(w,t)$')
        a2 = fig.add_subplot(gs[2, c])
        for j in range(K):
            a2.plot(ww, sig(br[j], ww, kind), color=PAL[j % len(PAL)], lw=1.2)
        a2.set_xlabel('$w$'); a2.set_ylim(0, None); a2.tick_params(labelsize=7)
        a2.text(.97, .05, '$t=%.2f$' % ts, transform=a2.transAxes, ha='right', fontsize=7.5)
        if c == 0:
            a2.set_ylabel(r'$\partial g_j/\partial w$')
    fig.savefig('%s/%s.png' % (OUT, nm)); plt.close(fig); print('  ', nm)


def fig_zanyatost():
    if gotov('zanyatost'):
        return
    fig, ax = plt.subplots(figsize=(7.0, 2.7))
    for i, key in enumerate(ORD):
        dol = np.sort(np.array(R['%s|%d' % (key, len(IST[key]))]['dolya']))[::-1]
        niz = 0.0
        for j, v in enumerate(dol):
            ax.bar(i, v, bottom=niz, color=PAL[j % len(PAL)], width=.72,
                   edgecolor='w', lw=.5); niz += v
    ax.set_xticks(range(len(ORD))); ax.set_xticklabels([RUS[k] for k in ORD])
    ax.set_ylabel('доля времени'); ax.set_ylim(0, 1)
    ax.set_title('занятость режимов вдоль восстановленного пути', fontsize=9)
    fig.savefig('%s/zanyatost.png' % OUT); plt.close(fig); print('   zanyatost')


def fig_rang():
    if gotov('rang_vetv'):
        return
    dat = []
    for key in ORD:
        K = len(IST[key]); kind = 'aff' if key.startswith('L') else 'cub'
        d, keep, bref = dan(key); kk = np.asarray(keep, bool)
        br = R['%s|%d' % (key, K)]['branches']
        ll, W, pv, dol = V.put(d['Y'], d['t'], d['dt'], br, kind, keep, bref, po_vetvi=True)
        tk = np.asarray(d['t'])[kk]
        G = np.array([[gval(g, tt, w, kind) for g in br] for tt, w in zip(tk, W)])
        rang = np.argsort(np.argsort(G, axis=1), axis=1)[np.arange(len(pv)), pv]
        lab = np.asarray(d['lab'])[kk]
        dat.append((int((np.diff(rang) != 0).sum()), int((np.diff(pv) != 0).sum()),
                    int((np.diff(lab) != 0).sum())))
    dat = np.array(dat); x = np.arange(len(ORD))
    fig, ax = plt.subplots(figsize=(7.0, 2.9))
    ax.bar(x - .26, dat[:, 0], .25, label='смен ранга корня', color='#90a4ae')
    ax.bar(x, dat[:, 1], .25, label='смен идентичности ветви', color=PAL[1])
    ax.bar(x + .26, dat[:, 2], .25, label='истинных переключений', color=PAL[0])
    ax.set_xticks(x); ax.set_xticklabels([RUS[k] for k in ORD])
    ax.set_ylabel('число событий'); ax.legend(fontsize=7.5)
    ax.set_title('штраф должен относиться к смене ветви, а не ранга корня', fontsize=9)
    fig.savefig('%s/rang_vetv.png' % OUT); plt.close(fig); print('   rang_vetv')


def fig_bic():
    if gotov('bic'):
        return
    fig, axs = plt.subplots(3, 5, figsize=(7.4, 4.3))
    for i, key in enumerate(ORD):
        a = axs.ravel()[i]; K = len(IST[key])
        Ns = [N for N in range(1, K + 2) if (key, N) in T]
        vals = np.array([T[(key, N)]['bic'] for N in Ns]); vals = vals - vals.min()
        a.plot(Ns, vals, 'o-', color='0.35', lw=1.1, ms=3.4)
        a.plot([K], [vals[Ns.index(K)]], 'o', color=PAL[0], ms=6.5, zorder=5)
        a.set_xticks(Ns); a.set_title(RUS[key], fontsize=8); a.tick_params(labelsize=7)
        if i % 5 == 0:
            a.set_ylabel('BIC $-$ min', fontsize=7.5)
    for j in range(len(ORD), 15):
        axs.ravel()[j].axis('off')
    fig.suptitle('информационный критерий по степени; зелёным — истинное число режимов',
                 fontsize=9, y=1.01)
    fig.tight_layout(); fig.savefig('%s/bic.png' % OUT); plt.close(fig); print('   bic')


def fig_drayver():
    if gotov('drayver'):
        return
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.5))
    lb2, ku, vr, cv = [], [], [], []
    for key in ORD:
        K = len(IST[key])
        for N in range(1, K + 2):
            if (key, N) not in T:
                continue
            v = T[(key, N)]
            lb2.append(v['lb2']); ku.append(v['kurt']); vr.append(v['var'])
            cv.append(PAL[0] if N == K else ('#c62828' if N > K else '#90a4ae'))
    for a, y, nm2, lin in [(axs[0], lb2, r'$LB(z^2)$', 30),
                           (axs[1], ku, 'эксцесс $z$', None),
                           (axs[2], vr, r'$\mathrm{var}(z)$', 1.0)]:
        a.scatter(range(len(y)), y, c=cv, s=13)
        if lin is not None:
            a.axhline(lin, color='0.4', ls='--', lw=.8)
        a.set_ylabel(nm2); a.set_xlabel('подгонки'); a.tick_params(labelsize=7)
    axs[0].set_yscale('log')
    axs[0].legend(handles=[Patch(color='#90a4ae', label='заниженная'),
                           Patch(color=PAL[0], label='истинная'),
                           Patch(color='#c62828', label='завышенная')],
                  fontsize=6.5, loc='upper right')
    fig.suptitle(r'приращения драйвера $z=\Delta W/\sqrt{\Delta t}$: проверка на $N(0,1)$',
                 fontsize=8.5, y=1.04)
    fig.tight_layout(); fig.savefig('%s/drayver.png' % OUT); plt.close(fig); print('   drayver')


def fig_sigma():
    if gotov('sigma_vosst'):
        return
    kub = ['N1', 'N3', 'N4', 'N5', 'N6', 'N7']
    fig, axs = plt.subplots(2, 3, figsize=(7.4, 4.2))
    for i, key in enumerate(kub):
        a = axs.ravel()[i]
        d, keep, bref, br, kind, W, pv, dol = podgonka(key)
        kk = np.asarray(keep, bool)
        Wi = np.asarray(d['W'])[kk]; lab = np.asarray(d['lab'])[kk]
        for j in range(len(IST[key])):
            m = (lab == j)
            if m.sum() < 5:
                continue
            lo, hi = np.percentile(Wi[m], [2, 98])
            a.plot(np.linspace(lo, hi, 120), sig(IST[key][j], np.linspace(lo, hi, 120), 'cub'),
                   '-', color=PAL[j % len(PAL)], lw=1.7)
        for j in range(len(br)):
            m = (pv == j)
            if m.sum() < 5:
                continue
            lo, hi = np.percentile(W[m], [2, 98])
            a.plot(np.linspace(lo, hi, 120), sig(br[j], np.linspace(lo, hi, 120), kind),
                   '--', color=PAL[j % len(PAL)], lw=1.4)
        a.set_title(RUS[key], fontsize=8.5); a.tick_params(labelsize=7)
        a.set_xlabel('$w$', fontsize=7.5)
        if i % 3 == 0:
            a.set_ylabel(r'$\sigma(w)$', fontsize=8)
    fig.suptitle('сплошные — истинная $\\sigma(w)$, штриховые — восстановленная,'
                 ' на посещённой области', fontsize=8.5, y=1.02)
    fig.tight_layout(); fig.savefig('%s/sigma_vosst.png' % OUT); plt.close(fig)
    print('   sigma_vosst')


if __name__ == '__main__':
    bud = float(sys.argv[1]) if len(sys.argv) > 1 else 250.
    t0 = time.time()
    zad = [('zanyatost', fig_zanyatost), ('bic', fig_bic), ('drayver', fig_drayver),
           ('rang_vetv', fig_rang), ('sigma_vosst', fig_sigma)]
    zad += [('ryad_%s' % k, (lambda kk=k: fig_ryad(kk))) for k in ORD]
    for nm, f in zad:
        if gotov(nm):
            continue
        if time.time() - t0 > bud - 45:
            print('пауза'); sys.exit(0)
        f(); sys.stdout.flush()
    print('ВСЕ РИСУНКИ ГОТОВЫ:', len(os.listdir(OUT)))
