"""Устранение асимметрии: слияние для наибольшей степени-кандидата.

Старт слиянием для степени N строится из решения степени N+1. Кандидатами
выбора служат степени 1..K+1, поэтому для симметрии нужны решения до K+2.
Степень K+2 считается ТОЛЬКО как источник стартов и в сравнение по критерию не
входит — иначе ей самой понадобилась бы K+3, и так без конца.

После слияния к степени K+1 применяются те же доводки, что и ко всем прочим
кандидатам: сигма-координаты для кубических и маргинальное правдоподобие.

    python simmetriya.py 250     возобновляемый
"""
import sys, os, time, pickle
sys.path.insert(0, '.')
import numpy as np
from scipy.optimize import minimize
import msde as M, pipeline as P, examples3 as E3, vetvi as V, podgonka as PG

R = pickle.load(open('stepen.pkl', 'rb'))
T = pickle.load(open('batareya.pkl', 'rb'))
IST = {k: v[0] for k, v in E3.LIN.items()}
IST.update({k: v[0] for k, v in E3.CUB.items()})
ORD = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
LOG = 'simm.pkl'
S = pickle.load(open(LOG, 'rb')) if os.path.exists(LOG) else {}

bud = float(sys.argv[1]) if len(sys.argv) > 1 else 250.
t0 = time.time()

for key in ORD:
    K = len(IST[key]); kind = 'aff' if key.startswith('L') else 'cub'
    d = E3.get(key); Y, t, dt = d['Y'], d['t'], d['dt']
    keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40)

    # --- шаг 1: решение степени K+2 как источник стартов
    kk2 = '%s|%d' % (key, K + 2)
    if kk2 not in R:
        if time.time() - t0 > bud - 150:
            print('пауза'); sys.exit(0)
        st = time.time()
        r = PG.podognat5(Y, t, dt, K + 2, kind, keep, bref,
                         br_pred=R['%s|%d' % (key, K + 1)]['branches'],
                         n_sobol=32, n_dovodka=2, maxiter=400, seed=7)
        if kind == 'cub':
            r2 = PG.dovesti_sigma(Y, t, dt, r['branches'], keep, bref, vnesh=2, maxiter=400)
            if r2['ll'] > r['ll']:
                r = r2
        ll, W, pv, dol = V.put(Y, t, dt, r['branches'], kind, keep, bref, po_vetvi=True)
        R[kk2] = dict(ll=float(r['ll']), branches=r['branches'], kind=kind,
                      dolya=list(dol) if dol is not None else [0.0])
        pickle.dump(R, open('stepen.pkl', 'wb'))
        print('%-4s N=%d (источник стартов) ll=%.1f  (%.0f с)'
              % (key, K + 2, r['ll'], time.time() - st)); sys.stdout.flush()

    # --- шаг 2: слияние для степени K+1
    kk1 = '%s|%d' % (key, K + 1)
    if kk1 in S:
        continue
    if time.time() - t0 > bud - 150:
        print('пауза'); sys.exit(0)
    st = time.time(); best = (R[kk1]['ll'], R[kk1]['branches'])
    for br0 in PG.sliyanie_starty(Y, t, dt, R[kk2]['branches'], kind, keep, bref):
        x = PG._upak(br0, kind); cur = -1e18
        for _ in range(3):
            rr = minimize(PG.kriterij, x, args=(Y, t, dt, K + 1, kind, keep, bref),
                          method='Nelder-Mead',
                          options=dict(maxiter=500, maxfev=500, xatol=1e-6, fatol=1e-6))
            if -rr.fun <= cur + 1e-9:
                break
            cur = -rr.fun
            x = PG._upak(PG.uslovno_ca(Y, t, dt, PG._raspak(rr.x, K + 1, kind),
                                       kind, keep, bref), kind)
        kand = PG._raspak(x, K + 1, kind)
        if kind == 'cub':
            d2 = PG.dovesti_sigma(Y, t, dt, kand, keep, bref, vnesh=2, maxiter=400)
            if d2['ll'] > cur:
                kand = d2['branches']
        lh = V.put(Y, t, dt, kand, kind, keep, bref, po_vetvi=True)[0]
        if np.isfinite(lh) and lh > best[0] + 1e-9:
            best = (lh, kand)
    # маргинальная доводка, как у всех кандидатов
    kap = T[(key, K + 1)]['kappa'] if (key, K + 1) in T else None
    rm = PG.dovesti_marg(Y, t, dt, best[1], kind, keep, bref, kappa=kap, maxiter=400)
    if rm['ll_marg'] > rm['ll_marg0'] + 1e-9:
        lh = V.put(Y, t, dt, rm['branches'], kind, keep, bref, po_vetvi=True)[0]
        if np.isfinite(lh) and lh > -1e5:
            best = (lh, rm['branches'])
    S[kk1] = dict(ll_old=R[kk1]['ll'], ll=best[0])
    if best[0] > R[kk1]['ll'] + 0.05:
        ll, W, pv, dol = V.put(Y, t, dt, best[1], kind, keep, bref, po_vetvi=True)
        v = dict(R[kk1]); v.update(ll=float(best[0]), branches=best[1], dolya=list(dol))
        R[kk1] = v; pickle.dump(R, open('stepen.pkl', 'wb'))
    pickle.dump(S, open(LOG, 'wb'))
    print('%-4s N=%d СЛИЯНИЕ: ll %9.1f -> %9.1f (%+.1f)  (%.0f с)'
          % (key, K + 1, S[kk1]['ll_old'], S[kk1]['ll'],
             S[kk1]['ll'] - S[kk1]['ll_old'], time.time() - st))
    sys.stdout.flush()
print('ВСЁ')
