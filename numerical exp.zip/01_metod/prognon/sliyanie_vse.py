"""Старты слиянием ДЛЯ ВСЕХ степеней, а не только для истинных.

Иначе сравнение степеней подтасовано: улучшив подгонку лишь при верном числе
режимов, мы делаем верный ответ выгодным независимо от свойств правила.

Остаётся неустранимая асимметрия: наибольшей посчитанной степени слияние
недоступно, поскольку для него нужно решение степени на единицу большей.
Она смещает не в пользу завышения, то есть в консервативную сторону, но
называть её надо явно.
"""
import sys, os, time, pickle
sys.path.insert(0, '.')
import numpy as np
from scipy.optimize import minimize
import msde as M, pipeline as P, examples3 as E3, vetvi as V, podgonka as PG

R = pickle.load(open('stepen.pkl', 'rb'))
IST = {k: v[0] for k, v in E3.LIN.items()}
IST.update({k: v[0] for k, v in E3.CUB.items()})
ORD = ['L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
LOG = 'sliyanie.pkl'
D = pickle.load(open(LOG, 'rb')) if os.path.exists(LOG) else {}
gotovo = {'N7|3', 'N2|3'}

bud = float(sys.argv[1]) if len(sys.argv) > 1 else 250.
t0 = time.time()
for key in ORD:
    K = len(IST[key]); kind = 'aff' if key.startswith('L') else 'cub'
    for N in range(2, K + 1):
        kk = '%s|%d' % (key, N)
        if kk in D or kk in gotovo or kk not in R or ('%s|%d' % (key, N + 1)) not in R:
            continue
        if time.time() - t0 > bud - 80:
            print('пауза'); sys.exit(0)
        d = E3.get(key); Y, t, dt = d['Y'], d['t'], d['dt']
        keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40)
        st = time.time(); best = (R[kk]['ll'], R[kk]['branches'])
        for br0 in PG.sliyanie_starty(Y, t, dt, R['%s|%d' % (key, N + 1)]['branches'],
                                      kind, keep, bref):
            x = PG._upak(br0, kind); cur = -1e18
            for _ in range(3):
                rr = minimize(PG.kriterij, x, args=(Y, t, dt, N, kind, keep, bref),
                              method='Nelder-Mead',
                              options=dict(maxiter=500, maxfev=500, xatol=1e-6, fatol=1e-6))
                if -rr.fun <= cur + 1e-9:
                    break
                cur = -rr.fun
                x = PG._upak(PG.uslovno_ca(Y, t, dt, PG._raspak(rr.x, N, kind),
                                           kind, keep, bref), kind)
            kand = PG._raspak(x, N, kind)
            if kind == 'cub':
                d2 = PG.dovesti_sigma(Y, t, dt, kand, keep, bref, vnesh=2, maxiter=400)
                if d2['ll'] > cur:
                    cur, kand = d2['ll'], d2['branches']
            lh = V.put(Y, t, dt, kand, kind, keep, bref, po_vetvi=True)[0]
            if np.isfinite(lh) and lh > best[0] + 1e-9:
                best = (lh, kand)
        D[kk] = dict(ll_old=R[kk]['ll'], ll=best[0])
        if best[0] > R[kk]['ll'] + 0.05:
            ll, W, pv, dol = V.put(Y, t, dt, best[1], kind, keep, bref, po_vetvi=True)
            v = dict(R[kk]); v.update(ll=float(best[0]), branches=best[1], dolya=list(dol))
            R[kk] = v; pickle.dump(R, open('stepen.pkl', 'wb'))
        pickle.dump(D, open(LOG, 'wb'))
        print('%-4s N=%d  ll %9.1f -> %9.1f (%+.1f)  (%.0f с)'
              % (key, N, D[kk]['ll_old'], D[kk]['ll'], D[kk]['ll'] - D[kk]['ll_old'],
                 time.time() - st))
        sys.stdout.flush()
print('ВСЁ')
