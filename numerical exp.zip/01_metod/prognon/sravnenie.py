"""Сравнение правил выбора степени. Главное здесь — протокол оценки.

Правило с порогом, откалиброванным по тому же набору, на котором потом
считается доля верных ответов, всегда выглядит лучше, чем оно есть. Тринадцати
рядов хватит, чтобы подогнать порог почти под что угодно. Поэтому:

  ВНУТРИ    порог выбран по всем тринадцати рядам; это ВЕРХНЯЯ ОЦЕНКА,
            и сравнивать её с правилами без порога нельзя;
  СКОЛЬЗЯЩ  порог выбран по двенадцати рядам, ответ проверен на тринадцатом,
            и так тринадцать раз; это честная оценка.

У правил без свободных постоянных (информационный критерий, удержанный скор)
обе колонки совпадают по построению, поэтому у них указана одна.
"""
import sys, pickle
sys.path.insert(0, '.')
import numpy as np
import examples3 as E3

T = pickle.load(open('batareya.pkl', 'rb'))
IST = {k: v[0] for k, v in E3.LIN.items()}
IST.update({k: v[0] for k, v in E3.CUB.items()})
ORD = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
KIST = {k: len(v) for k, v in IST.items()}


def stepeni(key):
    return sorted(N for (k, N) in T if k == key)


def po_min(key, pole):
    c = {N: T[(key, N)][pole] for N in stepeni(key) if np.isfinite(T[(key, N)][pole])}
    return min(c, key=c.get) if c else 1


def po_porogu_max(key, pole, por):
    """наибольшая степень, у которой величина ВЫШЕ порога"""
    ok = [N for N in stepeni(key) if np.isfinite(T[(key, N)][pole]) and T[(key, N)][pole] > por]
    return max(ok) if ok else 1


def po_porogu_min(key, pole, por):
    """наименьшая степень, у которой величина НИЖЕ порога"""
    ok = [N for N in stepeni(key) if np.isfinite(T[(key, N)][pole]) and T[(key, N)][pole] < por]
    return min(ok) if ok else max(stepeni(key))


def tochnost(f, klyuchi):
    return sum(1 for k in klyuchi if f(k) == KIST[k])


def luchshiy_porog(pole, fn, klyuchi, setka):
    b, bp = -1, None
    for por in setka:
        t = tochnost(lambda k: fn(k, pole, por), klyuchi)
        if t > b:
            b, bp = t, por
    return bp, b


def skolzyashchiy(pole, fn, setka):
    ok = 0
    for k in ORD:
        drug = [x for x in ORD if x != k]
        por, _ = luchshiy_porog(pole, fn, drug, setka)
        ok += (fn(k, pole, por) == KIST[k])
    return ok


if __name__ == '__main__':
    print('ПРАВИЛА БЕЗ СВОБОДНЫХ ПОСТОЯННЫХ')
    for nm, pole in [('BIC по профильному критерию (как в отчёте)', 'bic_prof'),
                     ('BIC по точному правдоподобию', 'bic'),
                     ('BIC по точному правдоподобию, kappa оценён', 'bic_k')]:
        v = [po_min(k, pole) for k in ORD]
        oshib = [(k, a, KIST[k]) for k, a in zip(ORD, v) if a != KIST[k]]
        print('  %-45s %2d из 13   ошибки: %s'
              % (nm, sum(1 for k, a in zip(ORD, v) if a == KIST[k]),
                 ', '.join('%s %d вместо %d' % o for o in oshib) or 'нет'))

    print('\nПРАВИЛА С ПОРОГОМ')
    zad = [('занятость по пути >', 'zan', po_porogu_max, np.linspace(0.01, 0.30, 30)),
           ('апостериорная занятость >', 'ap_zan', po_porogu_max, np.linspace(0.01, 0.30, 30)),
           ('LB(z^2) <  (белизна)', 'lb2', po_porogu_min, np.linspace(10, 200, 39)),
           ('|эксцесс| <', 'kurt', po_porogu_min, np.linspace(0.02, 1.0, 25))]
    for nm, pole, fn, setka in zad:
        por, vn = luchshiy_porog(pole, fn, ORD, setka)
        sk = skolzyashchiy(pole, fn, setka)
        print('  %-30s порог %7.3f   внутри %2d из 13   скользящий %2d из 13'
              % (nm, por, vn, sk))

    print('\nСОЧЕТАНИЯ')
    def sochet(k, p1, p2):
        """наибольшая степень, проходящая занятость, среди белых"""
        ok = [N for N in stepeni(k) if T[(k, N)]['zan'] > p1 and T[(k, N)]['lb2'] < p2]
        return max(ok) if ok else 1
    b, bp = -1, None
    for p1 in np.linspace(0.02, 0.25, 24):
        for p2 in np.linspace(10, 200, 39):
            t = tochnost(lambda k: sochet(k, p1, p2), ORD)
            if t > b:
                b, bp = t, (p1, p2)
    ok = 0
    for k in ORD:
        drug = [x for x in ORD if x != k]
        bb, pp = -1, None
        for p1 in np.linspace(0.02, 0.25, 24):
            for p2 in np.linspace(10, 200, 39):
                t = tochnost(lambda z: sochet(z, p1, p2), drug)
                if t > bb:
                    bb, pp = t, (p1, p2)
        ok += (sochet(k, *pp) == KIST[k])
    print('  занятость и белизна вместе   пороги %.3f / %.0f   внутри %2d из 13   скользящий %2d из 13'
          % (bp[0], bp[1], b, ok))

    print('\nBIC СРЕДИ БЕЛЫХ (белизна как допуск к сравнению, не как правило)')
    for p2 in (30, 50, 100, 150):
        def bel(k):
            kand = [N for N in stepeni(k) if T[(k, N)]['lb2'] < p2]
            if not kand:
                kand = stepeni(k)
            c = {N: T[(k, N)]['bic_k'] for N in kand}
            return min(c, key=c.get)
        v = [bel(k) for k in ORD]
        osh = [(k, a) for k, a in zip(ORD, v) if a != KIST[k]]
        print('  допуск LB(z^2) < %3d:  %2d из 13   ошибки: %s'
              % (p2, sum(1 for k, a in zip(ORD, v) if a == KIST[k]),
                 ', '.join('%s->%d' % o for o in osh) or 'нет'))
