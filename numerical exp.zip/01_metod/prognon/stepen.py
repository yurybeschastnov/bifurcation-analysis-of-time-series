"""Выбор степени под исправленным критерием.

Задача: выяснить, восстанавливает ли метод число режимов, и какое правило это
обеспечивает. Для каждого ряда подгоняются степени N = K, K+1 (первая очередь),
затем K-1 и ниже (вторая очередь), и для каждой записываются все величины,
которые могут войти в правило:

    ll          значение критерия (состояние = идентичность ветви)
    dolya       занятость ветвей вдоль восстановленного пути
    sigma       медиана sigma_j(w) по посещённой ветвью области
    rho         разделимость по положению вдоль пути
    metki       доля верных меток режима (только для синтетики, для диагностики)
    perekl      число переключений пути против истинного

Занятость здесь имеет смысл впервые: при штрафе за смену ранга путь менял режим
на каждом пересечении ветвей, и доли времени ни о чём не говорили.

    python stepen.py 250        считает, пока хватает бюджета, потом продолжает
    python stepen.py --svodka
"""
import sys, os, time, pickle
sys.path.insert(0, '.')
import numpy as np
import msde as M, pipeline as P, examples3 as E3
import vetvi as V, podgonka as PG, kriterii2 as K2

FN = 'stepen.pkl'
ORD = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
IST = {}
for _k, (_br, _s, _r, _d) in E3.LIN.items():
    IST[_k] = ('aff', _br)
for _k, (_br, _s, _r, _d) in E3.CUB.items():
    IST[_k] = ('cub', _br)

R = pickle.load(open(FN, 'rb')) if os.path.exists(FN) else {}


def dan(key):
    d = E3.get(key)
    keep = P.censor_mask(d['Y'], d['t'], d['dt'])
    bref = M.local_vol(d['Y'], d['dt'], 40)
    return d, keep, bref


def odna(key, N):
    kind, br_ist = IST[key]
    K = len(br_ist)
    d, keep, bref = dan(key)
    Y, t, dt = d['Y'], d['t'], d['dt']
    t0 = time.time()
    pred = R.get('%s|%d' % (key, N - 1))
    brp = pred['branches'] if pred else None
    fit = PG.podognat5(Y, t, dt, N, kind, keep, bref, br_pred=brp,
                       n_sobol=32, n_dovodka=2, maxiter=450, seed=7)
    h = K2.harakteristiki(Y, t, dt, fit['branches'], kind, keep, bref)
    k = np.asarray(keep, bool)
    lab = np.asarray(d['lab'])[k]
    # диагностика восстановленного драйвера: модель утверждает, что он есть
    # винеровский процесс. Если приращения не белые, структура не объяснена —
    # это условие ДОСТАТОЧНОСТИ числа режимов, ловящее занижение. Занятость и
    # прирост критерия ловят только завышение.
    tt = np.asarray(t)[np.asarray(keep, bool)]
    dW = np.diff(fit['W']); ddt = np.diff(tt); z = dW / np.sqrt(ddt)
    qv = float(np.sum(dW ** 2) / np.sum(ddt))
    kurt = float(np.mean((z - z.mean()) ** 4) / np.var(z) ** 2 - 3.0)
    lb = float(M.ljung_box(z ** 2, h=20))
    out = dict(ll=fit['ll'], branches=fit['branches'], kind=kind,
               qv=qv, kurt=kurt, lb=lb, belyi=bool(lb < 37.6),
               dolya=h['dolya'].tolist(), sigma=h['sigma'].tolist(),
               rho=h['rho'], sec=time.time() - t0,
               perekl=int((np.diff(fit['put']) != 0).sum()),
               perekl_ist=int((np.diff(lab) != 0).sum()))
    if N == K:
        out['metki'] = float(np.mean(np.asarray(fit['put']) == lab))
    return out


def ocheredi():
    """Первая очередь: N = K и K+1. Вторая: остальные степени вниз до 1."""
    z1, z2 = [], []
    for key in ORD:
        K = len(IST[key][1])
        # степени идут по возрастанию: решение предыдущей служит тёплым стартом
        for N in range(1, K + 2):
            (z1 if N >= K else z2).append((key, N))
    return z1 + z2


def svodka():
    print('\nВЫБОР СТЕПЕНИ ПОД ИСПРАВЛЕННЫМ КРИТЕРИЕМ\n' + '=' * 92)
    print('%-4s %-3s %-2s %9s %8s %8s %7s %8s  %s'
          % ('ряд', 'ист', 'N', 'll', 'мин.зан', 'rho', 'перекл', 'метки', 'sigma'))
    for key in ORD:
        K = len(IST[key][1])
        for N in range(1, K + 2):
            v = R.get('%s|%d' % (key, N))
            if not v:
                continue
            mz = min(v['dolya'])
            met = ('%.3f' % v['metki']) if 'metki' in v else '-'
            print('%-4s %-3d %-2d %9.1f %8.3f %8.2f %4d/%-3d %8s  %s'
                  % (key if N == 1 else '', K if N == 1 else 0, N, v['ll'], mz, v['rho'],
                     v['perekl'], v['perekl_ist'], met, np.round(np.sort(v['sigma']), 3)))
    print()
    print('ЗАНЯТОСТЬ КАК РАЗДЕЛИТЕЛЬ')
    a, b = [], []
    for key in ORD:
        K = len(IST[key][1])
        u = R.get('%s|%d' % (key, K)); w = R.get('%s|%d' % (key, K + 1))
        if u:
            a.append(min(u['dolya']))
        if w:
            b.append(min(w['dolya']))
    if a and b:
        print('  при истинной степени:  мин %.4f  макс %.4f  (n=%d)' % (min(a), max(a), len(a)))
        print('  при завышенной:        мин %.4f  макс %.4f  (n=%d)' % (min(b), max(b), len(b)))
        print('  зазор: %s' % ('ЕСТЬ, %.4f .. %.4f' % (max(b), min(a)) if max(b) < min(a)
                               else 'НЕТ, множества перекрываются'))
    print()


if __name__ == '__main__':
    if '--svodka' in sys.argv:
        svodka(); sys.exit(0)
    bud = float(sys.argv[1]) if len(sys.argv) > 1 else 250.
    t0 = time.time()
    zad = sorted(ocheredi(), key=lambda z: (ORD.index(z[0]), z[1]))
    for key, N in zad:
        kk = '%s|%d' % (key, N)
        if kk in R:
            continue
        if time.time() - t0 > bud - 140:
            print('пауза, продолжайте тем же вызовом'); sys.exit(0)
        try:
            R[kk] = odna(key, N)
            v = R[kk]
            print('%-4s N=%d ll=%9.1f мин.зан=%.3f LB=%6.0f %s перекл %d/%d sigma=%s (%.0fс)'
                  % (key, N, v['ll'], min(v['dolya']), v['lb'],
                     'бел ' if v['belyi'] else 'НЕбел', v['perekl'],
                     v['perekl_ist'], np.round(np.sort(v['sigma']), 3), v['sec']))
        except Exception as e:
            R[kk] = None
            print('%-4s N=%d  ОШИБКА: %s' % (key, N, e))
        pickle.dump(R, open(FN, 'wb'))
        sys.stdout.flush()
    print('\nВСЁ ГОТОВО'); svodka()
