"""Критерии выбора модели для нелинейных ветвей.

Почему прежние определения непригодны для рядов Н. Волатильность ветви есть
функция драйвера

    sigma_j(w) = |dg_j/dw| = b_j + 3 r_j w^2,

а не число. Различимость в отчёте определена как

    tau = min |b_i - b_j| / sqrt(s_i^2 + s_j^2),

то есть сравнивает значения при w = 0. Для аффинных ветвей это и есть
волатильность, для кубических — значение в точке, которая у половины ветвей
лежит ВНЕ посещённого драйвером диапазона. Сравниваются экстраполяции.

Здесь все три меры переопределены через саму функцию sigma на посещённой
области. На аффинных ветвях определения переходят в прежние тождественно,
поэтому числа для рядов Л сопоставимы.

    sigma_j        медиана sigma_j(W_t) по моментам, когда путь на ветви j
    rho            наименьшее по парам медианное расстояние между ветвями
                   вдоль пути, нормированное на характерное приращение
    tau_sigma      наименьшее по парам расстояние между sigma_i и sigma_j
                   в единицах их собственных погрешностей
    t_j            отношение кривизны к её погрешности: критерий выбора
                   между прямой и кубической ветвью

Погрешности берутся профилированием с перенастройкой прочих параметров ТОЙ ЖЕ
ветви — по предложению 13 отчёта плоское направление лежит именно внутри
параметров одной ветви.

Масштабное профилирование. Чтобы профилировать именно уровень волатильности, а
не коэффициент при w, ветвь умножается на общий множитель:

    (b_j, r_j)  ->  (lam * b_j, lam * r_j),

отчего sigma_j(w) -> lam * sigma_j(w) целиком, а форма улыбки сохраняется. Для
аффинной ветви это в точности сдвиг b_j. Погрешность sigma_j равна sigma_j
умноженной на полуширину области, где критерий падает на две наты, делённую
на два.
"""
import numpy as np
from scipy.optimize import minimize
import vetvi as V


def _sigma(g, w, kind):
    r = g[3] if kind == 'cub' else 0.0
    return np.abs(g[2] + 3.0 * r * np.asarray(w) ** 2)


def _gval(g, t, w, kind):
    r = g[3] if kind == 'cub' else 0.0
    return g[0] + g[1] * t + g[2] * w + r * np.asarray(w) ** 3


def harakteristiki(Y, t, dt, br, kind, keep=None, bref=None):
    """sigma по ветвям, занятость, rho — всё по посещённой области."""
    ll, W, pv, dolya = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)
    if W is None:
        return None
    k = np.ones(len(Y), bool) if keep is None else np.asarray(keep, bool)
    Yk, tk = np.asarray(Y)[k], np.asarray(t)[k]
    K = len(br)
    sig, diap = [], []
    for j in range(K):
        m = (pv == j)
        if m.sum() < 5:
            sig.append(np.nan); diap.append((np.nan, np.nan)); continue
        s = _sigma(br[j], W[m], kind)
        sig.append(float(np.median(s)))
        diap.append((float(np.percentile(W[m], 2)), float(np.percentile(W[m], 98))))
    # разделимость по положению вдоль пути
    scale = float(np.sqrt(np.mean(np.diff(Yk) ** 2)))
    rho = np.inf
    for i in range(K):
        for j in range(i + 1, K):
            d = np.abs(_gval(br[i], tk, W, kind) - _gval(br[j], tk, W, kind))
            rho = min(rho, float(np.median(d) / scale))
    return dict(ll=ll, W=W, put=pv, dolya=dolya, sigma=np.array(sig),
                diapazon=diap, rho=float(rho))


def _profil(Y, t, dt, br, kind, j, keep, bref, param, setka, maxiter=120):
    """Профиль критерия по одному параметру ветви j с перенастройкой прочих
    параметров той же ветви. param: 'lam' (масштаб sigma) или 'r' (кривизна)."""
    g0 = br[j]
    out = []
    for v in setka:
        def cel(z):
            if param == 'lam':
                g = (float(z[0]), float(z[1]), float(v * g0[2])) + \
                    ((float(v * g0[3]),) if kind == 'cub' else ())
            else:
                g = (float(z[0]), float(z[1]), float(abs(z[2])), float(max(v, 0.0)))
            b2 = list(br); b2[j] = g
            ll = V.put(Y, t, dt, b2, kind, keep, bref, po_vetvi=True)[0]
            return -ll if np.isfinite(ll) else 1e9
        z0 = [g0[0], g0[1]] + ([] if param == 'lam' else [g0[2]])
        r = minimize(cel, np.array(z0, float), method='Nelder-Mead',
                     options=dict(maxiter=maxiter, maxfev=maxiter, xatol=1e-4, fatol=1e-3))
        out.append(-r.fun)
    return np.array(out)


def se_sigma(Y, t, dt, br, kind, j, keep, bref, span=0.30, ng=7, maxiter=120):
    """Погрешность уровня sigma_j масштабным профилированием."""
    lam = np.linspace(1 - span, 1 + span, ng)
    v = _profil(Y, t, dt, br, kind, j, keep, bref, 'lam', lam, maxiter)
    m = np.nanmax(v); ok = v >= m - 2.0
    if ok.all():
        pol = float(lam[-1] - lam[0])            # профиль плоский шире сетки
        ploskij = True
    elif ok.sum() < 2:
        pol = float(lam[1] - lam[0]) / 2.0; ploskij = False
    else:
        pol = float(lam[ok].max() - lam[ok].min()) / 2.0; ploskij = False
    return pol / 2.0, ploskij, lam, v


def tau_sigma(Y, t, dt, br, kind, keep=None, bref=None, span=0.30, ng=7, maxiter=120,
              tolko_para=None):
    """Различимость по уровню волатильности.

    tolko_para — считать лишь для указанной пары индексов; поскольку tau есть
    минимум по парам, значение по одной паре ограничивает её сверху."""
    h = harakteristiki(Y, t, dt, br, kind, keep, bref)
    if h is None:
        return np.nan, None
    sig = h['sigma']; K = len(br)
    nado = set()
    if tolko_para is None:
        pary = [(i, j) for i in range(K) for j in range(i + 1, K)]
    else:
        pary = [tuple(tolko_para)]
    for p in pary:
        nado.update(p)
    se = {}
    for j in sorted(nado):
        s_rel, pl, _, _ = se_sigma(Y, t, dt, br, kind, j, keep, bref, span, ng, maxiter)
        se[j] = (abs(sig[j]) * s_rel, pl)
    best = np.inf; info = None
    for i, j in pary:
        if not (np.isfinite(sig[i]) and np.isfinite(sig[j])):
            continue
        d = abs(sig[i] - sig[j]) / np.sqrt(se[i][0] ** 2 + se[j][0] ** 2)
        if d < best:
            best = d; info = dict(para=(i, j), sigma=(sig[i], sig[j]),
                                  se=(se[i][0], se[j][0]),
                                  ploskie=(se[i][1], se[j][1]))
    return float(best), info


def t_krivizna(Y, t, dt, br, kind, keep=None, bref=None, rmax=0.8, ng=9, maxiter=120):
    """Отношение кривизны к её погрешности для каждой ветви.

    Это и есть критерий выбора между прямой и кубической ветвью: ветвь
    объявляется искривлённой при t_j > 2. Проверка идёт поветвенно, поэтому
    смешанные наборы получаются автоматически и отдельного сравнения двух
    классов целиком не требуется."""
    if kind != 'cub':
        return np.zeros(len(br)), None
    setka = np.linspace(0.0, rmax, ng)
    out, prof = [], []
    for j in range(len(br)):
        v = _profil(Y, t, dt, br, kind, j, keep, bref, 'r', setka, maxiter)
        prof.append(v)
        i0 = int(np.nanargmax(v)); rhat = float(setka[i0])
        ok = v >= np.nanmax(v) - 2.0
        if ok.all():
            se = float(setka[-1] - setka[0])
        elif ok.sum() < 2:
            se = float(setka[1] - setka[0]) / 2.0
        else:
            se = float(setka[ok].max() - setka[ok].min()) / 4.0
        out.append(rhat / se if se > 0 else 0.0)
    return np.array(out), (setka, np.array(prof))
