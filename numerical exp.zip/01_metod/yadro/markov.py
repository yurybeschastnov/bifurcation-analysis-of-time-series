"""Марковское переключение как базовая модель сравнения.

В работе утверждается, что многорежимная алгебраическая модель делает то, чего
не делает обычный подход, но обычный подход в коде отсутствовал. Рецензент
спросит об этом первым. Здесь стандартная модель Гамильтона: приращения
условно гауссовы со своим сносом и своей волатильностью в каждом режиме,
скрытая цепь Маркова с матрицей переходов, оценка методом Баума-Уэлча
(EM с прямо-обратным проходом), выбор числа режимов по Шварцу.

    python markov.py            все ряды
    python markov.py N3 L6      выбранные

Что сравнивается:

  * число режимов. У марковской модели это выбор по BIC, у нашей — двойное
    правило. Ряды с известной истиной позволяют сопоставить точность.
  * волатильности режимов. Марковская модель оценивает их напрямую по
    приращениям, наша — через восстановленный драйвер.

Чего сравнение НЕ показывает и о чём надо сказать в тексте: марковская модель
не даёт ни детерминированной связи наблюдаемого ряда с драйвером, ни точной
переходной плотности, ни структурного параметра для калибровки по риск-
нейтральной мере. Она сильна там, где нужно только число режимов и уровень
волатильности в каждом, и именно на этом её и надо бить или признать её
преимущество.
"""
import sys, os, pickle, time
sys.path.insert(0, '.')
import numpy as np
import examples3 as E3

POL = 0.10   # доля общего стандартного отклонения приращений

ORDER = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7',
         'btc', 'btcB', 'btcC']
ISTINA = {'L1': 1, 'L2': 2, 'L3': 3, 'L4': 2, 'L5': 3, 'L6': 4,
          'N1': 2, 'N2': 3, 'N3': 2, 'N4': 3, 'N5': 2, 'N6': 2, 'N7': 3}


def em(r, dt, K, n_iter=150, seed=0, tol=1e-6):
    """Баум-Уэлч для переключающейся гауссовой модели приращений.

    r      приращения ряда
    K      число режимов
    Возвращает логарифм правдоподобия, сносы, волатильности, матрицу переходов.
    Волатильности приведены к тем же единицам, что и b в нашей модели:
    sigma = std(r) / sqrt(dt).
    """
    rng = np.random.default_rng(seed)
    n = len(r)
    q = np.quantile(np.abs(r), np.linspace(.15, .85, K))
    sd = np.maximum(q, 1e-8) * (1 + .05 * rng.standard_normal(K))
    mu = np.zeros(K)
    A = np.full((K, K), .05 / max(K - 1, 1)); np.fill_diagonal(A, .95)
    pi = np.full(K, 1.0 / K)
    ll_old = -np.inf
    for _ in range(n_iter):
        # плотности наблюдений
        B = np.exp(-.5 * ((r[:, None] - mu[None, :]) / sd[None, :]) ** 2) / (sd[None, :] * np.sqrt(2 * np.pi))
        B = np.maximum(B, 1e-300)
        # прямой проход с масштабированием
        al = np.zeros((n, K)); c = np.zeros(n)
        al[0] = pi * B[0]; c[0] = al[0].sum(); al[0] /= c[0]
        for i in range(1, n):
            al[i] = (al[i - 1] @ A) * B[i]
            c[i] = al[i].sum(); al[i] /= c[i]
        ll = float(np.log(c).sum())
        # обратный проход
        be = np.zeros((n, K)); be[-1] = 1.0
        for i in range(n - 2, -1, -1):
            be[i] = (A @ (B[i + 1] * be[i + 1])) / c[i + 1]
        g = al * be; g /= np.maximum(g.sum(1, keepdims=True), 1e-300)
        # переходы
        # xi_{kj} = sum_i al[i,k] A[k,j] B[i+1,j] be[i+1,j] / c[i+1] — без цикла по i
        Mx = B[1:] * be[1:] / c[1:, None]
        xi = A * (al[:-1].T @ Mx)
        A = xi / np.maximum(xi.sum(1, keepdims=True), 1e-300)
        pi = g[0] / g[0].sum()
        w = np.maximum(g.sum(0), 1e-10)
        mu = (g * r[:, None]).sum(0) / w
        sd = np.sqrt(np.maximum((g * (r[:, None] - mu[None, :]) ** 2).sum(0) / w, 1e-16))
        # Пол на волатильность. Без него EM садится в вырожденное решение с почти
        # нулевой дисперсией на подмножестве точек — известная патология модели
        # переключений, а не её содержательный ответ. Сравнение без этой защиты
        # было бы нечестным по отношению к базовой модели.
        sd = np.maximum(sd, POL * r.std())
        if ll - ll_old < tol * abs(ll):
            ll_old = ll; break
        ll_old = ll
    o = np.argsort(sd)
    return ll_old, mu[o] / dt, sd[o] / np.sqrt(dt), A[np.ix_(o, o)], g[:, o]


def podobrat(r, dt, K, ntry=3):
    """Несколько стартов: EM садится в локальные максимумы."""
    best = None
    for s in range(ntry):
        try:
            out = em(r, dt, K, seed=s)
        except Exception:
            continue
        if best is None or out[0] > best[0]:
            best = out
    return best


def zagruzit(key):
    """BTC берётся из выгруженных txt, если исходного csv нет."""
    try:
        d = E3.get(key)
        return np.asarray(d['Y']), d['dt']
    except FileNotFoundError:
        fn = {'btc': '../dat/btc.txt', 'btcB': '../dat/btcB.txt', 'btcC': '../dat/btcC.txt'}[key]
        a = np.loadtxt(fn, skiprows=1)
        t, Y = a[:, 0], a[:, 1]
        return Y, float(np.median(np.diff(t)))


def po_ryadu(key, Kmax=5):
    Y, dt = zagruzit(key)
    r = np.diff(Y); n = len(r)
    out = {}
    for K in range(1, Kmax + 1):
        res = podobrat(r, dt, K)
        if res is None:
            continue
        ll = res[0]
        # параметры: K сносов + K волатильностей + K(K-1) переходов + (K-1) начальных
        k = 2 * K + K * (K - 1) + (K - 1)
        out[K] = dict(ll=ll, k=k, bic=-2 * ll + k * np.log(n),
                      mu=res[1].tolist(), sigma=res[2].tolist())
    Kb = min(out, key=lambda K: out[K]['bic'])
    return out, Kb


if __name__ == '__main__':
    keys = [a for a in sys.argv[1:] if not a.startswith('-')] or ORDER
    FN = 'markov.pkl'
    R = pickle.load(open(FN, 'rb')) if os.path.exists(FN) else {}
    for key in keys:
        if key in R:
            continue
        t0 = time.time()
        out, Kb = po_ryadu(key)
        R[key] = dict(po_K=out, K_bic=Kb)
        pickle.dump(R, open(FN, 'wb'))
        tr = ISTINA.get(key)
        print('%-6s BIC выбирает K=%d%s  sigma=%s  (%.0f с)'
              % (key, Kb, ('  истина %d  %s' % (tr, 'верно' if Kb == tr else 'ОШИБКА')) if tr else '',
                 np.round(out[Kb]['sigma'], 3), time.time() - t0))
        sys.stdout.flush()
    print('\nСВОДКА по синтетическим рядам')
    good = sum(1 for k in ISTINA if k in R and R[k]['K_bic'] == ISTINA[k])
    print('  марковское переключение, выбор по Шварцу: %d из %d' % (good, len([k for k in ISTINA if k in R])))
