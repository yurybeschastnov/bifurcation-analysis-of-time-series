"""Подгонка по критерию с состоянием-ветвью.

Оптимизация построена по схеме из присланных рекомендаций: независимый старт,
глобальный поиск по логарифмам уровней волатильности, локальная безградиентная
доводка. Прежняя процедура стартовала только из сглаженной локальной оценки
волатильности, а она вблизи переключений смешивает соседние режимы, отчего все
старты смещены одинаково и лежат в одной области притяжения.

  u_j = log b_j                     уровни ищутся в логарифмах: положительность
                                    выполняется автоматически, а масштаб
                                    естественно логарифмический
  b_j in [0.2 s, 5 s]               s — общее стандартное отклонение приращений,
                                    делённое на sqrt(dt)
  Соболь по (u_1..u_K)              низкоразмерный глобальный слой
  c_j, a_j условно                  при заданных уровнях свободный член и снос
                                    берутся линейной регрессией на устойчивых
                                    интервалах пути
  Нелдер-Мид по всем параметрам     критерий кусочно-гладок, градиентные методы
                                    непригодны

Перестановочная инвариантность: жёсткое упорядочение u_1 < ... < u_K не
навязывается, решения сопоставляются с истиной после оптимизации по назначению.
"""
import numpy as np
from scipy.optimize import minimize
from scipy.stats import qmc
import vetvi as V


def _raspak(x, K, kind):
    p = 4 if kind == 'cub' else 3
    z = x.reshape(K, p)
    br = []
    for row in z:
        c, a, u = row[0], row[1], row[2]
        # Нелдер-Мид не знает границ и уводит u в десятки, отчего exp переполняется
        # и падает с OverflowError (ряд Н3 не считался вовсе). Уровень ограничен
        # физически осмысленным диапазоном.
        b = float(np.exp(np.clip(u, -12.0, 6.0)))
        if kind == 'cub':
            br.append((float(c), float(a), b, float(max(row[3], 0.0))))
        else:
            br.append((float(c), float(a), b))
    return br


def _upak(br, kind):
    out = []
    for g in br:
        row = [g[0], g[1], np.log(max(g[2], 1e-6))]
        if kind == 'cub':
            row.append(max(g[3], 0.0))
        out.append(row)
    return np.array(out, float).ravel()


def kriterij(x, Y, t, dt, K, kind, keep, bref, myagko=True):
    """Критерий для оптимизации.

    Ограничение на квадратичную вариацию драйвера в исходном виде возвращает
    -1e6, то есть создаёт плоское плато: безградиентный метод, попав туда,
    не имеет направления выхода. Именно на этом срывался лестничный старт с
    расщеплением ветви (на ряде Л4 стартовое q = 0,686 при нижней границе 0,70).
    Поэтому на время поиска граница делается мягкой: критерий считается без
    отсечения, а нарушение штрафуется гладко и растёт квадратично. Окончательное
    решение проверяется жёстким условием как прежде."""
    br = _raspak(x, K, kind)
    if not myagko:
        ll = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)[0]
        return -ll if np.isfinite(ll) else 1e9
    ll, W, pv, dol = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True,
                           proverka_qv=False)
    if W is None or not np.isfinite(ll):
        return 1e9
    tt = np.asarray(t)[np.asarray(keep, bool)] if keep is not None else np.asarray(t)
    span = float(np.sum(np.diff(tt)))
    q = float(np.sum(np.diff(W) ** 2)) / span if span > 0 else np.nan
    if not np.isfinite(q):
        return 1e9
    nar = max(0.0, V.QV_LO - q) + max(0.0, q - V.QV_HI)
    return -(ll - 2.0e4 * nar ** 2)


def uslovno_ca(Y, t, dt, br, kind, keep, bref):
    """При заданных уровнях волатильности уточняем c_j и a_j регрессией на
    устойчивых интервалах восстановленного пути."""
    ll, W, pv, _ = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)
    if W is None:
        return br
    k = np.ones(len(Y), bool) if keep is None else np.asarray(keep, bool)
    Yk, tk = np.asarray(Y)[k], np.asarray(t)[k]
    out = []
    for j, g in enumerate(br):
        m = (pv == j)
        if m.sum() < 20:
            out.append(g); continue
        r = g[3] if kind == 'cub' else 0.0
        # Y = c + a t + b w + r w^3  ->  остаток по (c, a)
        ost = Yk[m] - g[2] * W[m] - r * W[m] ** 3
        A = np.column_stack([np.ones(m.sum()), tk[m]])
        try:
            sol, *_ = np.linalg.lstsq(A, ost, rcond=None)
            out.append((float(sol[0]), float(sol[1])) + tuple(g[2:]))
        except Exception:
            out.append(g)
    return out


def podognat(Y, t, dt, K, kind='aff', keep=None, bref=None, n_sobol=32,
             n_dovodka=3, maxiter=None, seed=0, verbose=False):
    """Возвращает словарь с ветвями, значением критерия и путём."""
    Y = np.asarray(Y, float); t = np.asarray(t, float)
    s = float(np.std(np.diff(Y)) / np.sqrt(dt))
    lo, hi = np.log(0.2 * s), np.log(5.0 * s)
    p = 4 if kind == 'cub' else 3
    if maxiter is None:
        maxiter = 250 * K * p

    # --- глобальный слой: Соболь по логарифмам уровней
    eng = qmc.Sobol(d=K, scramble=True, seed=seed)
    U = lo + (hi - lo) * eng.random(n_sobol)
    kand = []
    for u in U:
        br = [(0.0, 0.0, float(np.exp(uu))) + ((0.0,) if kind == 'cub' else ())
              for uu in np.sort(u)]
        br = uslovno_ca(Y, t, dt, br, kind, keep, bref)
        ll = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)[0]
        kand.append((ll, br))
    kand.sort(key=lambda z: -z[0])

    # --- локальная доводка лучших кандидатов
    best = None
    for ll0, br0 in kand[:n_dovodka]:
        x0 = _upak(br0, kind)
        res = minimize(kriterij, x0, args=(Y, t, dt, K, kind, keep, bref),
                       method='Nelder-Mead',
                       options=dict(maxiter=maxiter, maxfev=maxiter, xatol=1e-4, fatol=1e-4))
        if best is None or -res.fun > best[0]:
            best = (-res.fun, _raspak(res.x, K, kind))
        if verbose:
            print('   старт ll=%.1f -> %.1f' % (ll0, -res.fun))

    ll, br = best
    # чередование «путь — параметры»: условное уточнение c_j, a_j на устойчивых
    # интервалах, затем повторная доводка. Шаг принимается только при росте
    # того же самого критерия.
    for _ in range(3):
        br2 = uslovno_ca(Y, t, dt, br, kind, keep, bref)
        res = minimize(kriterij, _upak(br2, kind), args=(Y, t, dt, K, kind, keep, bref),
                       method='Nelder-Mead',
                       options=dict(maxiter=maxiter // 2, maxfev=maxiter // 2,
                                    xatol=1e-5, fatol=1e-5))
        if -res.fun > ll + 1e-9:
            ll, br = -res.fun, _raspak(res.x, K, kind)
        else:
            break
    llf, W, pv, dolya = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)
    return dict(ll=float(llf), branches=br, kind=kind, N=K, W=W, put=pv, dolya=dolya)


def sopostavit(br_ocen, br_ist, kind):
    """Перестановочно-инвариантное сопоставление по уровню волатильности."""
    a = np.array([abs(g[2]) for g in br_ocen])
    b = np.array([abs(g[2]) for g in br_ist])
    from scipy.optimize import linear_sum_assignment
    C = np.abs(a[:, None] - b[None, :])
    r, c = linear_sum_assignment(C)
    perm = np.empty(len(b), int)
    for i, j in zip(r, c):
        perm[j] = i
    return perm


def oshibka_sigma(W, pv, br_ocen, br_ist, kind, W_ist, lab_ist, perm):
    """Медианная относительная ошибка sigma на посещённой области."""
    def sg(g, w):
        r = g[3] if kind == 'cub' else 0.0
        return abs(g[2] + 3.0 * r * w ** 2)
    s_ist = np.array([sg(br_ist[j], w) for j, w in zip(lab_ist, W_ist)])
    s_oc = np.array([sg(br_ocen[perm[j]], w) for j, w in zip(lab_ist, W)])
    return float(np.median(np.abs(s_oc / s_ist - 1.0)))


def hmm_start(Y, t, dt, K, kind, keep=None, bref=None, ntry=4):
    """Независимый старт от марковской модели переключений.

    Сглаженная локальная оценка волатильности как единственный источник стартов
    непригодна: около переключений окно смешивает соседние режимы, поэтому все
    старты смещены одинаково и лежат в одной области притяжения. Марковская
    модель оценивает уровни по приращениям без окна и потому даёт независимое
    приближение. Она используется ТОЛЬКО как генератор стартовой точки;
    окончательное решение выбирается по критерию алгебраической модели."""
    import markov as MK
    r = np.asarray(np.diff(np.asarray(Y, float)))
    best = MK.podobrat(r, dt, K, ntry=ntry)
    if best is None:
        return None
    sig = np.sort(np.asarray(best[2], float))
    g = best[4]                                   # апостериорные вероятности режимов
    lab = np.argmax(g, axis=1)
    br = []
    tk = np.asarray(t, float)[:-1]
    for j in range(K):
        m = (lab == j)
        b = float(max(sig[j], 1e-3))
        br.append((0.0, 0.0, b) + ((0.0,) if kind == 'cub' else ()))
    return uslovno_ca(Y, t, dt, br, kind, keep, bref)


def podognat2(Y, t, dt, K, kind='aff', keep=None, bref=None, n_sobol=24,
              n_dovodka=2, maxiter=None, seed=0, verbose=False):
    """Полная схема: марковский старт + Соболь по уровням + доводка + чередование."""
    p = 4 if kind == 'cub' else 3
    if maxiter is None:
        maxiter = 250 * K * p
    starty = []
    try:
        h = hmm_start(Y, t, dt, K, kind, keep, bref)
        if h is not None:
            starty.append(('марков', h))
    except Exception as e:
        if verbose:
            print('   марковский старт не построен:', e)
    s = float(np.std(np.diff(np.asarray(Y, float))) / np.sqrt(dt))
    lo, hi = np.log(0.2 * s), np.log(5.0 * s)
    eng = qmc.Sobol(d=K, scramble=True, seed=seed)
    U = lo + (hi - lo) * eng.random(n_sobol)
    kand = []
    for u in U:
        br = [(0.0, 0.0, float(np.exp(uu))) + ((0.0,) if kind == 'cub' else ())
              for uu in np.sort(u)]
        br = uslovno_ca(Y, t, dt, br, kind, keep, bref)
        kand.append((V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)[0], br))
    kand.sort(key=lambda z: -z[0])
    starty += [('соболь%d' % i, b) for i, (_, b) in enumerate(kand[:n_dovodka])]

    best = None
    for nm, br0 in starty:
        x = _upak(br0, kind); cur = -1e18
        for _ in range(4):
            res = minimize(kriterij, x, args=(Y, t, dt, K, kind, keep, bref),
                           method='Nelder-Mead',
                           options=dict(maxiter=maxiter, maxfev=maxiter,
                                        xatol=1e-6, fatol=1e-6))
            if -res.fun <= cur + 1e-9:
                break
            cur = -res.fun
            x = _upak(uslovno_ca(Y, t, dt, _raspak(res.x, K, kind), kind, keep, bref), kind)
        if verbose:
            print('   старт %-8s -> ll=%.1f' % (nm, cur))
        if best is None or cur > best[0]:
            best = (cur, _raspak(x, K, kind))
    ll, br = best
    llf, W, pv, dolya = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)
    if llf < ll - 1e-6:
        llf = ll
    return dict(ll=float(llf), branches=br, kind=kind, N=K, W=W, put=pv, dolya=dolya)


def podognat3(Y, t, dt, K, kind='aff', keep=None, bref=None, n_sobol=64,
              n_dovodka=3, maxiter=1200, seed=1, verbose=False):
    """Окончательная схема оптимизации.

    Ключевое отличие от прежней: глобальный слой идёт не только по уровням
    волатильности, но и по свободным членам. Уровни у разных локальных максимумов
    почти совпадают, а расходятся решения именно по свободным членам, поскольку
    они задают положение точек пересечения ветвей, то есть геометрию пути. Поиск
    только по уровням поэтому не выводит из ложной области притяжения.

    Слой Соболя строится в размерности 2K (аффинный класс) или 3K (кубический,
    добавляются кривизны). Далее — чередование условного уточнения c_j, a_j на
    устойчивых интервалах и безградиентной доводки Нелдера-Мида, с приёмом шага
    только при росте того же самого критерия.
    """
    Y = np.asarray(Y, float); t = np.asarray(t, float)
    s = float(np.std(np.diff(Y)) / np.sqrt(dt))
    lo, hi = np.log(0.2 * s), np.log(5.0 * s)
    cy = np.percentile(Y, [5, 95])
    dim = 3 * K if kind == 'cub' else 2 * K
    eng = qmc.Sobol(d=dim, scramble=True, seed=seed)
    Z = eng.random(n_sobol)
    kand = []
    for z in Z:
        u = np.sort(lo + (hi - lo) * z[:K])
        c = cy[0] + (cy[1] - cy[0]) * z[K:2 * K]
        if kind == 'cub':
            rr = 0.8 * z[2 * K:3 * K]
            br = [(float(cc), 0.0, float(np.exp(uu)), float(r0))
                  for uu, cc, r0 in zip(u, c, rr)]
        else:
            br = [(float(cc), 0.0, float(np.exp(uu))) for uu, cc in zip(u, c)]
        kand.append((V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)[0], br))
    kand.sort(key=lambda z: -z[0])

    best = None
    for ll0, br0 in kand[:n_dovodka]:
        x = _upak(br0, kind); cur = -1e18
        for _ in range(4):
            res = minimize(kriterij, x, args=(Y, t, dt, K, kind, keep, bref),
                           method='Nelder-Mead',
                           options=dict(maxiter=maxiter, maxfev=maxiter,
                                        xatol=1e-6, fatol=1e-6))
            if -res.fun <= cur + 1e-9:
                break
            cur = -res.fun
            x = _upak(uslovno_ca(Y, t, dt, _raspak(res.x, K, kind), kind, keep, bref), kind)
        if verbose:
            print('   холодный %.1f -> %.1f' % (ll0, cur))
        if best is None or cur > best[0]:
            best = (cur, _raspak(x, K, kind))
    ll, br = best
    llf, W, pv, dolya = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)
    return dict(ll=float(max(llf, ll)), branches=br, kind=kind, N=K,
                W=W, put=pv, dolya=dolya)


def podognat4(Y, t, dt, K, kind='aff', keep=None, bref=None, br_pred=None,
              n_sobol=32, n_dovodka=2, maxiter=400, seed=7, verbose=False):
    """Схема с лестничным стартом и расщеплением ветви.

    Соболь по уровням и свободным членам покрывает пространство равномерно и
    потому плохо попадает в узкую цель, когда два режима близки по волатильности
    (ряд Л4: истинные 0,70 и 0,95). Там глобальный слой сходится к вырожденному
    решению, где одна ветвь забирает весь путь, а вторая уходит из данных.
    Критерий при этом верен: двухветвевое решение даёт на 20 нат больше.

    Поэтому к холодным стартам добавляются два тёплых, строящихся из решения
    предыдущей степени:

      добавление    к N-1 ветвям приписывается ветвь на далёком уровне — ловит
                    режим, действительно отсутствующий в решении меньшей степени;
      расщепление   самая занятая ветвь заменяется двумя с уровнями, сдвинутыми
                    на +-20 процентов — ловит случай, когда одна ветвь решения
                    меньшей степени на деле объединяет два близких режима.
    """
    Y = np.asarray(Y, float); t = np.asarray(t, float)
    s = float(np.std(np.diff(Y)) / np.sqrt(dt))
    lo, hi = np.log(0.2 * s), np.log(5.0 * s)
    cy = np.percentile(Y, [5, 95])
    starty = []

    if br_pred is not None and len(br_pred) == K - 1:
        ll0, W0, pv0, dol0 = V.put(Y, t, dt, br_pred, kind, keep, bref, po_vetvi=True)
        # добавление далёкой ветви
        dal = float(np.exp(hi)) if np.mean([g[2] for g in br_pred]) < np.exp(hi) / 2 else float(np.exp(lo))
        g_new = (float(np.median(Y)), 0.0, dal) + ((0.0,) if kind == 'cub' else ())
        starty.append(('добавл', list(br_pred) + [g_new]))
        # расщепление самой занятой ветви
        if dol0 is not None:
            j = int(np.argmax(dol0)); g = br_pred[j]
            for d1, d2 in ((0.80, 1.20),):
                a = (g[0], g[1], g[2] * d1) + ((g[3],) if kind == 'cub' else ())
                b = (g[0], g[1], g[2] * d2) + ((g[3],) if kind == 'cub' else ())
                nb = [x for i, x in enumerate(br_pred) if i != j] + [a, b]
                starty.append(('расщеп', uslovno_ca(Y, t, dt, nb, kind, keep, bref)))

    dim = 3 * K if kind == 'cub' else 2 * K
    eng = qmc.Sobol(d=dim, scramble=True, seed=seed)
    Z = eng.random(n_sobol)
    kand = []
    for z in Z:
        u = np.sort(lo + (hi - lo) * z[:K])
        c = cy[0] + (cy[1] - cy[0]) * z[K:2 * K]
        if kind == 'cub':
            rr = 0.8 * z[2 * K:3 * K]
            br = [(float(cc), 0.0, float(np.exp(uu)), float(r0))
                  for uu, cc, r0 in zip(u, c, rr)]
        else:
            br = [(float(cc), 0.0, float(np.exp(uu))) for uu, cc in zip(u, c)]
        kand.append((V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)[0], br))
    kand.sort(key=lambda z: -z[0])
    starty += [('соболь%d' % i, b) for i, (_, b) in enumerate(kand[:n_dovodka])]

    best = None
    for nm, br0 in starty:
        x = _upak(br0, kind); cur = -1e18
        for _ in range(3):
            res = minimize(kriterij, x, args=(Y, t, dt, K, kind, keep, bref),
                           method='Nelder-Mead',
                           options=dict(maxiter=maxiter, maxfev=maxiter,
                                        xatol=1e-6, fatol=1e-6))
            if -res.fun <= cur + 1e-9:
                break
            cur = -res.fun
            x = _upak(uslovno_ca(Y, t, dt, _raspak(res.x, K, kind), kind, keep, bref), kind)
        if verbose:
            print('   %-8s -> %.1f' % (nm, cur))
        if best is None or cur > best[0]:
            best = (cur, _raspak(x, K, kind))
    ll, br = best
    llf, W, pv, dolya = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)
    return dict(ll=float(max(llf, ll)), branches=br, kind=kind, N=K,
                W=W, put=pv, dolya=dolya)


def hmm_start2(Y, t, dt, K, kind, keep=None, bref=None, ntry=4):
    """Независимый старт по разметке марковской модели.

    Прежний вариант брал у марковской модели только уровни волатильности, а
    свободные члены доопределял по текущему пути, то есть всё равно опирался на
    уже найденное решение. Здесь используется сама разметка:

      1. марковская модель на приращениях даёт метки режимов;
      2. приращения делятся на волатильность своего режима, что даёт
         предварительный драйвер (де-волатилизация);
      3. внутри каждого режима Y регрессируется на (1, t, W), что даёт сразу
         c_j, a_j и b_j.

    Старт независим от сглаженной локальной оценки волатильности и потому
    выводит из области притяжения вырожденных решений: на ряде Л4 с близкими
    режимами (0,70 и 0,95) все прочие старты сходились к одной ветви.
    """
    import markov as MK
    Y = np.asarray(Y, float); t = np.asarray(t, float)
    r = np.diff(Y)
    best = MK.podobrat(r, dt, K, ntry=ntry)
    if best is None:
        return None
    sig = np.asarray(best[2], float)                  # уровни, отсортированы
    g = best[4]
    lab = np.argmax(g, axis=1)
    # dY = a dt + b dW, поэтому dW = dY / b: делить надо на уровень волатильности,
    # а не на шаговое стандартное отклонение, иначе драйвер раздувается в 1/sqrt(dt) раз
    s_t = np.maximum(sig[lab], 1e-6)
    W = np.concatenate([[0.0], np.cumsum(r / s_t)])
    br = []
    for j in range(K):
        m = np.zeros(len(Y), bool)
        m[:-1] = (lab == j); m[1:] |= (lab == j)
        if m.sum() < 20:
            br.append((float(np.median(Y)), 0.0, float(max(sig[j], 1e-3)))
                      + ((0.0,) if kind == 'cub' else ()))
            continue
        A = np.column_stack([np.ones(m.sum()), t[m], W[m]])
        sol, *_ = np.linalg.lstsq(A, Y[m], rcond=None)
        b = float(abs(sol[2])) if abs(sol[2]) > 1e-6 else float(max(sig[j], 1e-3))
        br.append((float(sol[0]), float(sol[1]), b) + ((0.0,) if kind == 'cub' else ()))
    return br


def podognat5(Y, t, dt, K, kind='aff', keep=None, bref=None, br_pred=None,
              n_sobol=32, n_dovodka=2, maxiter=450, seed=7, verbose=False):
    """Портфель стартов. Ни один старт не пригоден на всех рядах.

    Соболь по уровням и свободным членам выигрывает на Л3 (6740,5 против 6664,3
    у марковского), марковская разметка выигрывает на Л4 с близкими режимами
    (6503,7 против 6484,6 у всех прочих: там Соболь сходится к вырожденному
    решению с одной ветвью). Поэтому запускаются все, а решение выбирается по
    значению критерия.
    """
    Y = np.asarray(Y, float); t = np.asarray(t, float)
    s = float(np.std(np.diff(Y)) / np.sqrt(dt))
    lo, hi = np.log(0.2 * s), np.log(5.0 * s)
    cy = np.percentile(Y, [5, 95])
    starty = []
    try:
        h = hmm_start2(Y, t, dt, K, kind, keep, bref)
        if h is not None:
            starty.append(('марков', h))
    except Exception:
        pass
    if br_pred is not None and len(br_pred) == K - 1:
        ll0, W0, pv0, dol0 = V.put(Y, t, dt, br_pred, kind, keep, bref, po_vetvi=True)
        dal = float(np.exp(hi))
        starty.append(('добавл', list(br_pred) +
                       [(float(np.median(Y)), 0.0, dal) + ((0.0,) if kind == 'cub' else ())]))
        if dol0 is not None:
            j = int(np.argmax(dol0)); g = br_pred[j]
            a = (g[0], g[1], g[2] * 0.80) + ((g[3],) if kind == 'cub' else ())
            b = (g[0], g[1], g[2] * 1.20) + ((g[3],) if kind == 'cub' else ())
            starty.append(('расщеп', [x for i, x in enumerate(br_pred) if i != j] + [a, b]))
    dim = 3 * K if kind == 'cub' else 2 * K
    Z = qmc.Sobol(d=dim, scramble=True, seed=seed).random(n_sobol)
    kand = []
    for z in Z:
        u = np.sort(lo + (hi - lo) * z[:K])
        c = cy[0] + (cy[1] - cy[0]) * z[K:2 * K]
        if kind == 'cub':
            br = [(float(cc), 0.0, float(np.exp(uu)), float(0.8 * r0))
                  for uu, cc, r0 in zip(u, c, z[2 * K:3 * K])]
        else:
            br = [(float(cc), 0.0, float(np.exp(uu))) for uu, cc in zip(u, c)]
        kand.append((V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True,
                           proverka_qv=False)[0], br))
    kand.sort(key=lambda z: -z[0])
    starty += [('соболь%d' % i, b) for i, (_, b) in enumerate(kand[:n_dovodka])]

    best = None
    for nm, br0 in starty:
        x = _upak(br0, kind); cur = -1e18
        for _ in range(3):
            res = minimize(kriterij, x, args=(Y, t, dt, K, kind, keep, bref),
                           method='Nelder-Mead',
                           options=dict(maxiter=maxiter, maxfev=maxiter,
                                        xatol=1e-6, fatol=1e-6))
            if -res.fun <= cur + 1e-9:
                break
            cur = -res.fun
            x = _upak(uslovno_ca(Y, t, dt, _raspak(res.x, K, kind), kind, keep, bref), kind)
        br_c = _raspak(x, K, kind)
        llh = V.put(Y, t, dt, br_c, kind, keep, bref, po_vetvi=True)[0]   # жёсткая проверка
        if verbose:
            print('   %-8s -> %.1f (жёстко %.1f)' % (nm, cur, llh))
        if np.isfinite(llh) and llh > -1e5 and (best is None or llh > best[0]):
            best = (llh, br_c)
    if best is None:
        best = (-1e6, _raspak(_upak(starty[0][1], kind), K, kind))
    ll, br = best
    llf, W, pv, dolya = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)
    return dict(ll=float(ll), branches=br, kind=kind, N=K, W=W, put=pv, dolya=dolya)


# ---------------------------------------------------------------------------
# Параметризация кубической ветви опорными значениями волатильности
# ---------------------------------------------------------------------------
# Волатильность ветви sigma(w) = b + 3 r w^2 линейна по q = w^2. Значит оценка
# (b, r) есть регрессия sigma на q по посещённой области. Если q меняется мало,
# свободный член и наклон почти коллинеарны: на ряде Н4 первая ветвь живёт в
# q от 0 до 0,17, и профиль критерия по r там плоский (6366,2 при r = 0 против
# 6363,0 при истинном r = 0,5), хотя сама sigma определена хорошо.
#
# Поэтому ветвь параметризуется не парой (b, r), а двумя ЗНАЧЕНИЯМИ sigma в двух
# точках внутри посещённой области:
#
#     s1 = sigma(q1) = b + 3 r q1,      s2 = sigma(q2) = b + 3 r q2,
#     r  = (s2 - s1) / (3 (q2 - q1)),   b = (q2 s1 - q1 s2) / (q2 - q1).
#
# Значения функции в двух разнесённых точках почти ортогональны, тогда как
# уровень и кривизна сильно связаны. Опоры q1, q2 берутся квартилями w^2 по
# занятости ветви, фиксируются на время внутреннего шага и обновляются между
# внешними итерациями: иначе меняется сама система координат.

def opory(W, pv, K, mini=0.02):
    """Квартили w^2 по занятости каждой ветви."""
    out = []
    for j in range(K):
        w = W[pv == j]
        if len(w) < 20:
            out.append((0.0, 1.0)); continue
        q = w ** 2
        q1, q2 = np.percentile(q, [25, 75])
        if q2 - q1 < mini:
            q2 = q1 + mini
        out.append((float(q1), float(q2)))
    return out


def s_v_br(x, K, op, kind='cub'):
    """(c, a, log s1, log s2) -> ветви (c, a, b, r)."""
    z = x.reshape(K, 4); br = []
    for row, (q1, q2) in zip(z, op):
        s1 = float(np.exp(np.clip(row[2], -12, 6)))
        s2 = float(np.exp(np.clip(row[3], -12, 6)))
        r = (s2 - s1) / (3.0 * (q2 - q1))
        b = (q2 * s1 - q1 * s2) / (q2 - q1)
        r = max(r, 0.0); b = max(b, 1e-4)
        br.append((float(row[0]), float(row[1]), b, r))
    return br


def br_v_s(br, op):
    """ветви -> (c, a, log s1, log s2)."""
    out = []
    for g, (q1, q2) in zip(br, op):
        s1 = max(g[2] + 3.0 * g[3] * q1, 1e-4)
        s2 = max(g[2] + 3.0 * g[3] * q2, 1e-4)
        out.append([g[0], g[1], np.log(s1), np.log(s2)])
    return np.array(out, float).ravel()


def kriterij_s(x, Y, t, dt, K, op, keep, bref):
    br = s_v_br(x, K, op)
    ll, W, pv, dol = V.put(Y, t, dt, br, 'cub', keep, bref, po_vetvi=True,
                           proverka_qv=False)
    if W is None or not np.isfinite(ll):
        return 1e9
    tt = np.asarray(t)[np.asarray(keep, bool)] if keep is not None else np.asarray(t)
    span = float(np.sum(np.diff(tt)))
    q = float(np.sum(np.diff(W) ** 2)) / span if span > 0 else np.nan
    if not np.isfinite(q):
        return 1e9
    nar = max(0.0, V.QV_LO - q) + max(0.0, q - V.QV_HI)
    return -(ll - 2.0e4 * nar ** 2)


def dovesti_sigma(Y, t, dt, br0, keep=None, bref=None, vnesh=4, maxiter=800):
    """Доводка кубической подгонки в координатах опорных значений sigma."""
    K = len(br0); br = list(br0)
    luchshee = V.put(Y, t, dt, br, 'cub', keep, bref, po_vetvi=True)[0]
    for _ in range(vnesh):
        ll, W, pv, dol = V.put(Y, t, dt, br, 'cub', keep, bref, po_vetvi=True)
        if W is None:
            break
        op = opory(W, pv, K)
        x0 = br_v_s(br, op)
        res = minimize(kriterij_s, x0, args=(Y, t, dt, K, op, keep, bref),
                       method='Nelder-Mead',
                       options=dict(maxiter=maxiter, maxfev=maxiter,
                                    xatol=1e-6, fatol=1e-6))
        kand = s_v_br(res.x, K, op)
        lk = V.put(Y, t, dt, kand, 'cub', keep, bref, po_vetvi=True)[0]
        if np.isfinite(lk) and lk > luchshee + 1e-9:
            luchshee, br = lk, kand
        else:
            break
    return dict(ll=float(luchshee), branches=br, kind='cub', N=K)


def sliyanie_starty(Y, t, dt, br_next, kind, keep=None, bref=None):
    """Старты слиянием: из решения степени N+1 получить кандидатов степени N.

    Мотивация прямо из раздела 6.6 отчёта: аффинная модель достаточно большой
    степени приближает ОДНУ искривлённую ветвь несколькими прямыми, разбив
    диапазон изменения волатильности на участки постоянства. Лестничные старты
    снизу (добавить ветвь, расщепить ветвь) этого случая не ловят: они умеют
    только дробить. Нужен обратный ход — взять пару соседних ветвей решения
    большей степени и заменить её одной ветвью, подогнанной по объединённым
    данным этой пары.

    Слитая ветвь строится линейной регрессией Y на (1, t, W, W^3) по моментам,
    где путь шёл по любой из двух ветвей: это даёт сразу c, a, b, r без поиска.
    """
    Y = np.asarray(Y, float); t = np.asarray(t, float)
    ll, W, pv, dol = V.put(Y, t, dt, br_next, kind, keep, bref, po_vetvi=True)
    if W is None:
        return []
    k = np.ones(len(Y), bool) if keep is None else np.asarray(keep, bool)
    Yk, tk = Y[k], t[k]
    K = len(br_next)
    sg = []
    for j, g in enumerate(br_next):
        m = (pv == j)
        r = g[3] if kind == 'cub' else 0.0
        sg.append(np.median(np.abs(g[2] + 3 * r * W[m] ** 2)) if m.sum() > 5 else np.inf)
    por = np.argsort(sg)
    out = []
    for a in range(K - 1):
        i, j = int(por[a]), int(por[a + 1])
        m = (pv == i) | (pv == j)
        if m.sum() < 40:
            continue
        if kind == 'cub':
            A = np.column_stack([np.ones(m.sum()), tk[m], W[m], W[m] ** 3])
        else:
            A = np.column_stack([np.ones(m.sum()), tk[m], W[m]])
        try:
            sol, *_ = np.linalg.lstsq(A, Yk[m], rcond=None)
        except Exception:
            continue
        b = float(abs(sol[2]))
        if b < 1e-4:
            continue
        nov = (float(sol[0]), float(sol[1]), b) + \
              ((float(max(sol[3], 0.0)),) if kind == 'cub' else ())
        kand = [g for q, g in enumerate(br_next) if q not in (i, j)] + [nov]
        out.append(kand)
    return out


def kriterij_marg(x, Y, t, dt, K, kind, keep, bref, kappa=None):
    """Целевая функция — ТОЧНОЕ маргинальное правдоподобие, а не профильное.

    Профильный критерий есть максимум по одному пути, то есть аналог обучения
    по Витерби. Оно приписывает всю вероятностную массу одному пути и потому
    даёт смещённые оценки: короткие эпизоды подавляются, а параметры сдвигаются.
    На ряде Н2 это видно прямо: решение с БОЛЬШИМ значением профильного критерия
    дало ХУДШИЕ параметры (b: 1,25 -> 0,96 против 1,16 у решения похуже).

    Маргинальное правдоподобие суммирует по всем путям и таких смещений не имеет.
    """
    br = _raspak(x, K, kind)
    ll, g = V.put_summa(Y, t, dt, br, kind, keep, bref, kappa=kappa)
    return -ll if np.isfinite(ll) else 1e9


def dovesti_marg(Y, t, dt, br0, kind, keep=None, bref=None, kappa=None, maxiter=500):
    """Доводка по маргинальному правдоподобию от готового решения."""
    K = len(br0)
    x0 = _upak(br0, kind)
    l0, _ = V.put_summa(Y, t, dt, br0, kind, keep, bref, kappa=kappa)
    res = minimize(kriterij_marg, x0, args=(Y, t, dt, K, kind, keep, bref, kappa),
                   method='Nelder-Mead',
                   options=dict(maxiter=maxiter, maxfev=maxiter, xatol=1e-6, fatol=1e-6))
    br = _raspak(res.x, K, kind)
    return dict(ll_marg=float(-res.fun), ll_marg0=float(l0), branches=br, kind=kind, N=K)
