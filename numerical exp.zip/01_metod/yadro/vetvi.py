"""Путь по идентичности ветви вместо ранга отсортированного корня.

В msde.path_likelihood таблица корней строится решением f(Y_t, w, t) = 0 и
сортируется по величине, после чего штраф kappa накладывается на смену ИНДЕКСА
в этой таблице (в коде: same = eye(K), с примечанием «корни упорядочены: ранг
непрерывен»). Но ветви пересекаются — на этом и построена вся модель, — и в
точке пересечения ранг данной ветви меняется. Поэтому штраф наложен не на то
событие:

  * сохранить ранг при прохождении пересечения = перейти на другую ветвь, и это
    бесплатно;
  * остаться на своей ветви = сменить ранг, и это стоит kappa.

Измерено на итоговых подгонках: путь меняет ранг 5-31 раз, а идентичность ветви
63-212 раз при истинных 12-20 переключениях. То есть восстановленный путь
меняет режим на каждом пересечении, и данные соседних режимов перемешиваются.

Здесь состояние динамического программирования есть номер ветви. Это возможно,
поскольку ветви заданы явно: для монотонной ветви (b > 0, r >= 0) уравнение
Y = g_j(w, t) имеет ровно один вещественный корень, и таблица корней строится
поветвенно, без сортировки. Соглашения об эмиссии, цензурировании, полосе
волатильности и штрафе сохранены в точности, чтобы значения критерия были
сопоставимы с прежними.

Проверка тождественности: при kappa = 0 оба варианта обязаны давать одно и то
же значение критерия, поскольку множество допустимых путей совпадает, а
различается лишь разметка состояний.
"""
import numpy as np

TAU_CONT = 8.0          # то же ограничение непрерывности драйвера, что в pipeline
QV_LO, QV_HI = 0.70, 1.40
BAND_LO, BAND_HI = 0.25, 4.0


def koren_vetvi(Y, t, br, kind):
    """Корень w уравнения Y = g_j(w,t) для каждой ветви: (n, K).

    Аффинная ветвь обращается явно. Кубическая монотонная ветвь при b > 0 и
    r >= 0 имеет ровно один вещественный корень; при r = 0 вырождается в
    аффинную."""
    Y = np.asarray(Y, float); t = np.asarray(t, float)
    n = len(Y); K = len(br)
    W = np.full((n, K), np.nan)
    for j, g in enumerate(br):
        c, a, b = g[0], g[1], g[2]
        r = g[3] if kind == 'cub' else 0.0
        rhs = Y - c - a * t
        # при малой кривизне формула Кардано переполняется: p = b/r и q = -rhs/r
        # растут как 1/r, а куб p даёт 1/r^3. Ветвь с пренебрежимо малой кривизной
        # обращается как аффинная — это и есть предел той же формулы.
        if kind == 'aff' or r <= 1e-6:
            if abs(b) < 1e-300:
                continue
            W[:, j] = rhs / b
        else:
            # r w^3 + b w - rhs = 0, один вещественный корень (формула Кардано)
            p = b / r; q = -rhs / r
            with np.errstate(over='ignore', invalid='ignore'):
                disc = (q / 2.0) ** 2 + (p / 3.0) ** 3
                sq = np.sqrt(np.maximum(disc, 0.0))
                u = np.cbrt(-q / 2.0 + sq); v = np.cbrt(-q / 2.0 - sq)
                w = u + v
            # при переполнении отступаем к аффинному пределу b w = rhs
            plohо = ~np.isfinite(w)
            if plohо.any() and abs(b) > 1e-300:
                w = np.where(plohо, rhs / b, w)
            W[:, j] = w
    return W


def naklon(W, br, kind):
    """b_j(w) = dg_j/dw = b_j + 3 r_j w^2: (n, K)."""
    out = np.empty_like(W)
    for j, g in enumerate(br):
        r = g[3] if kind == 'cub' else 0.0
        out[:, j] = g[2] + 3.0 * r * W[:, j] ** 2
    return out


def put(Y, t, dt, br, kind, keep=None, bref=None, kappa=None, po_vetvi=True,
        tau=TAU_CONT, proverka_qv=True):
    """Профильное правдоподобие с состоянием-ветвью.

    po_vetvi=True  — штраф на смену идентичности ветви (исправленный вариант);
    po_vetvi=False — штраф на смену ранга (прежнее поведение), для сравнения.

    Возвращает (ll, W, put_vetvei, dolya_vremeni)."""
    Y = np.asarray(Y, float); t = np.asarray(t, float)
    if keep is not None:
        k = np.asarray(keep, bool)
        Y, t = Y[k], t[k]
        if bref is not None:
            bref = np.asarray(bref, float)[k]
    n = len(Y); K = len(br)
    dts = np.diff(t); dts = np.where(dts > 0, dts, dt)
    if kappa is None:
        kappa = np.log(max(n, 2))

    R = koren_vetvi(Y, t, br, kind)                  # (n,K), столбец = ветвь
    B = naklon(R, br, kind)
    fin = np.isfinite(R) & np.isfinite(B) & (np.abs(B) > 1e-12)
    with np.errstate(divide='ignore', invalid='ignore'):
        EM = -np.log(np.abs(B))
    if bref is not None:
        ref = np.asarray(bref, float)[:, None]
        fin &= (np.abs(B) >= BAND_LO * ref) & (np.abs(B) <= BAND_HI * ref)
    EM = np.where(fin, EM, -1e10)
    if not fin[0].any() or not fin.any(axis=1).all():
        return -1e6, None, None, None

    Rz = np.nan_to_num(R)
    d = Rz[1:, :, None] - Rz[:-1, None, :]
    dd = dts[:, None, None]
    TR = -0.5 * d ** 2 / dd - 0.5 * np.log(2 * np.pi * dd)
    adm = fin[1:][:, :, None] & fin[:-1][:, None, :]
    if tau is not None:
        adm &= np.abs(d) <= tau * np.sqrt(dd)

    if po_vetvi:
        # состояние = ветвь: штраф ровно за событие z_{i+1} != z_i
        shtraf = ~np.eye(K, dtype=bool)[None, :, :]
    else:
        # прежнее поведение: штраф за смену ранга. Ранг ветви в каждый момент
        # определяется порядком значений g_j вдоль пути, поэтому событие
        # «сменился ранг» переводится в матрицу по ветвям поточечно.
        rang = np.argsort(np.argsort(Rz, axis=1), axis=1)
        shtraf = rang[1:][:, :, None] != rang[:-1][:, None, :]
    TR = TR - kappa * shtraf
    TR = np.where(adm, TR, -1e10)

    alpha = np.where(fin[0], 0.0, -1e10)
    back = np.zeros((n, K), np.int32)
    for i in range(1, n):
        z = TR[i - 1] + alpha[None, :]
        bb = np.argmax(z, axis=1); back[i] = bb
        alpha = np.maximum(z[np.arange(K), bb] + EM[i], -1e10)
    ll = float(np.max(alpha)); j = int(np.argmax(alpha))
    put_v = np.empty(n, int); W = np.empty(n)
    put_v[-1] = j; W[-1] = Rz[n - 1, j]
    for i in range(n - 1, 0, -1):
        j = back[i, j]; put_v[i - 1] = j; W[i - 1] = Rz[i - 1, j]

    if proverka_qv:
        span = float(np.sum(np.diff(t)))
        q = float(np.sum(np.diff(W) ** 2)) / span if span > 0 else np.nan
        if not np.isfinite(q) or q < QV_LO or q > QV_HI:
            ll = -1e6
    dolya = np.array([float(np.mean(put_v == j)) for j in range(K)])
    return ll, W, put_v, dolya


def sigma_po_puti(W, put_v, br, kind):
    """sigma вдоль восстановленного пути: sigma(w) на своей ветви."""
    out = np.empty(len(W))
    for i, (w, j) in enumerate(zip(W, put_v)):
        g = br[j]; r = g[3] if kind == 'cub' else 0.0
        out[i] = abs(g[2] + 3.0 * r * w ** 2)
    return out


def put_summa(Y, t, dt, br, kind, keep=None, bref=None, kappa=None, tau=TAU_CONT):
    """ТОЧНОЕ маргинальное правдоподобие вместо профильного.

    Идея. Исправленное состояние (идентичность ветви, а не ранг корня) делает
    модель настоящей скрытой марковской моделью: состояние z_i есть номер ветви,
    переход разрешён геометрией, а плотность наблюдения при заданном состоянии
    равна phi_dt(dw) / |b|, то есть является ПЛОТНОСТЬЮ ПО y (замена переменной
    из w в y). Значит доступна прямая рекурсия — сумма по всем путям, а не
    максимум по одному.

    Не хватало только нормировки весов переходов. Вес перехода exp(-kappa) при
    смене ветви и 1 при сохранении не образует распределения вероятностей, пока
    строка не нормирована. Нормировка берётся по фактически допустимому в данный
    момент множеству состояний:

        Z_{i,j} = sum_{k допустимо} exp(-kappa * 1[j != k]),

    что сохраняет геометрическое ограничение замечания 1: переход возможен лишь
    там, где ветви сближаются.

    Что это даёт, и ради чего всё затевалось:

      * величина становится нормированной плотностью p(y_1..y_n | y_0), поэтому
        информационный критерий применим законно, а не по аналогии;
      * появляется удержанный прогнозный скор — выбор степени вообще без счёта
        параметров и без калиброванного порога;
      * становится возможен параметрический бутстреп, который отчёт отверг в
        разделе 8.4 из-за неопределённого правила выбора ветви: теперь правило
        задано, вероятность смены равна exp(-kappa)/Z.

    Возвращает (ll_sum, gamma) — правдоподобие и апостериорные вероятности
    состояний из прямо-обратного прохода.
    """
    Y = np.asarray(Y, float); t = np.asarray(t, float)
    if keep is not None:
        k = np.asarray(keep, bool)
        Y, t = Y[k], t[k]
        if bref is not None:
            bref = np.asarray(bref, float)[k]
    n = len(Y); K = len(br)
    dts = np.diff(t); dts = np.where(dts > 0, dts, dt)
    if kappa is None:
        kappa = np.log(max(n, 2))

    R = koren_vetvi(Y, t, br, kind)
    B = naklon(R, br, kind)
    fin = np.isfinite(R) & np.isfinite(B) & (np.abs(B) > 1e-12)
    with np.errstate(divide='ignore', invalid='ignore'):
        EM = -np.log(np.abs(B))
    if bref is not None:
        ref = np.asarray(bref, float)[:, None]
        fin &= (np.abs(B) >= BAND_LO * ref) & (np.abs(B) <= BAND_HI * ref)
    if not fin.any(axis=1).all() or not fin[0].any():
        return -np.inf, None
    EM = np.where(fin, EM, -np.inf)

    Rz = np.nan_to_num(R)
    d = Rz[1:, :, None] - Rz[:-1, None, :]          # (n-1, k_next, j_prev)
    dd = dts[:, None, None]
    GA = -0.5 * d ** 2 / dd - 0.5 * np.log(2 * np.pi * dd)
    adm = fin[1:][:, :, None] & fin[:-1][:, None, :]
    if tau is not None:
        adm &= np.abs(d) <= tau * np.sqrt(dd)
    P = np.where(~np.eye(K, dtype=bool)[None, :, :], np.exp(-kappa), 1.0)
    P = np.where(adm, P, 0.0)
    Z = P.sum(axis=1, keepdims=True)                # нормировка по строке j
    Z = np.where(Z > 0, Z, 1.0)
    LT = np.where(P > 0, np.log(np.where(P > 0, P, 1.0)) - np.log(Z), -np.inf) + GA

    al = np.full((n, K), -np.inf)
    # Начальное условие: правдоподобие условно по первому наблюдению. Прежде
    # сюда добавлялся член EM[0] = -log|b(w_1)|, что равносильно несобственному
    # плоскому приору на w_1: плотность y_1 выходила равной |b|^{-1}, то есть
    # неинтегрируемой. Из-за этого audit_mat печатал 2 провала из 11.
    # Условное соглашение корректно и делает маргинальное правдоподобие в
    # точности равным замкнутой гауссовой форме при одной ветви.
    al[0] = np.where(fin[0], -np.log(max(int(fin[0].sum()), 1)), -np.inf)
    c = np.zeros(n)
    m0 = al[0].max(); c[0] = m0 + np.log(np.exp(al[0] - m0).sum())
    al[0] -= c[0]
    for i in range(1, n):
        z = LT[i - 1] + al[i - 1][None, :]
        m = np.max(z, axis=1)
        s = np.where(np.isfinite(m), m + np.log(np.sum(np.exp(z - m[:, None]), axis=1)), -np.inf)
        a = s + EM[i]
        mm = a.max()
        if not np.isfinite(mm):
            return -np.inf, None
        c[i] = mm + np.log(np.exp(a - mm).sum())
        al[i] = a - c[i]
    ll = float(np.sum(c))

    be = np.full((n, K), -np.inf); be[-1] = 0.0
    for i in range(n - 2, -1, -1):
        z = LT[i] + (be[i + 1] + EM[i + 1])[:, None]
        m = np.max(z, axis=0)
        be[i] = np.where(np.isfinite(m), m + np.log(np.sum(np.exp(z - m[None, :]), axis=0)),
                         -np.inf) - c[i + 1]
    g = al + be
    g -= g.max(axis=1, keepdims=True)
    g = np.exp(g); g /= np.maximum(g.sum(axis=1, keepdims=True), 1e-300)
    return ll, g
