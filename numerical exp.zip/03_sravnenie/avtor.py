"""Результаты авторского метода, приведённые к общей шкале оценивания.

Извлекается: выбор степени по BIC (диапазоны 1..K+1 и 1..K+2), метки на
полной сетке точек, sigma вдоль восстановленного пути.
"""
import os, sys, os, pickle
sys.path.insert(0, os.environ.get('MSDE_PATH', '.'))
sys.path.insert(0, os.environ.get('MSDE_REZ', '.'))
import numpy as np
import msde as M, pipeline as P, examples3 as E3, vetvi as V

KAT = os.environ.get('MSDE_REZ', '.')
R = pickle.load(open(os.path.join(KAT, 'stepen.pkl'), 'rb'))
T = pickle.load(open(os.path.join(KAT, 'batareya.pkl'), 'rb'))
IST = {k: v[0] for k, v in E3.LIN.items()}
IST.update({k: v[0] for k, v in E3.CUB.items()})
ORD = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
KAP = np.linspace(2.5, 9.0, 14)


def bic_vse(key):
    """BIC по точному маргинальному правдоподобию для ВСЕХ степеней в stepen.pkl."""
    K = len(IST[key]); kind = 'aff' if key.startswith('L') else 'cub'
    p = 4 if kind == 'cub' else 3
    d = E3.get(key); Y, t, dt = d['Y'], d['t'], d['dt']
    keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40)
    n = int(np.asarray(keep, bool).sum())
    out = {}
    for N in range(1, K + 3):
        v = R.get('%s|%d' % (key, N))
        if not v:
            continue
        bst, kbst = -np.inf, np.log(n)
        for kp in KAP:
            l2, _ = V.put_summa(Y, t, dt, v['branches'], kind, keep, bref, kappa=kp)
            if np.isfinite(l2) and l2 > bst:
                bst, kbst = l2, kp
        if not np.isfinite(bst):
            continue
        out[N] = dict(ll=float(bst), kappa=float(kbst),
                      bic=float(-2 * bst + (p * N) * np.log(n)))
    return out


def razmetka(key):
    """Метки и sigma авторского метода на ПОЛНОЙ сетке точек."""
    K = len(IST[key]); kind = 'aff' if key.startswith('L') else 'cub'
    v = R['%s|%d' % (key, K)]
    kap = T[(key, K)]['kappa'] if (key, K) in T else None
    d = E3.get(key); Y, t, dt = d['Y'], d['t'], d['dt']
    keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40)
    kk = np.asarray(keep, bool)
    ll, W, pv, dol = V.put(Y, t, dt, v['branches'], kind, keep, bref, kappa=kap, po_vetvi=True)
    lm, gam = V.put_summa(Y, t, dt, v['branches'], kind, keep, bref, kappa=kap)
    z_keep = np.argmax(gam, axis=1) if gam is not None else np.asarray(pv)
    br = v['branches']
    s_keep = np.array([abs(br[j][2] + 3.0 * (br[j][3] if kind == 'cub' else 0.0) * w ** 2)
                       for j, w in zip(z_keep, W)])
    # разворачиваем на полную сетку: цензурированные точки берут ближайшего соседа
    idx = np.where(kk)[0]
    n = len(Y)
    poz = np.searchsorted(idx, np.arange(n))
    poz = np.clip(poz, 0, len(idx) - 1)
    poz2 = np.clip(poz - 1, 0, len(idx) - 1)
    blizh = np.where(np.abs(idx[poz] - np.arange(n)) <= np.abs(idx[poz2] - np.arange(n)), poz, poz2)
    return dict(z=z_keep[blizh], sigma=s_keep[blizh], keep=kk,
                z_keep=z_keep, s_keep=s_keep, branches=br, kind=kind, K=K, W=W)


if __name__ == '__main__':
    print('BIC ПО ТОЧНОМУ МАРГИНАЛЬНОМУ ПРАВДОПОДОБИЮ, ВСЕ ДОСТУПНЫЕ СТЕПЕНИ')
    print('%-4s %-3s %s' % ('ряд', 'K', 'BIC(N) - min по N'))
    ok1 = ok2 = 0
    svod = {}
    for key in ORD:
        b = bic_vse(key); K = len(IST[key])
        mn = min(b.values(), key=lambda v: v['bic'])['bic']
        s = '  '.join('N=%d:%+7.1f%s' % (N, v['bic'] - mn, '*' if v['bic'] == mn else ' ')
                      for N, v in sorted(b.items()))
        print('%-4s %-3d %s' % (key, K, s))
        vyb1 = min([N for N in b if N <= K + 1], key=lambda N: b[N]['bic'])
        vyb2 = min(b, key=lambda N: b[N]['bic'])
        ok1 += (vyb1 == K); ok2 += (vyb2 == K)
        svod[key] = dict(K=K, vyb_K1=vyb1, vyb_K2=vyb2, bic={N: v['bic'] for N, v in b.items()})
    print('\nверных при поиске 1..K+1: %d из 13' % ok1)
    print('верных при поиске 1..K+2: %d из 13' % ok2)
    pickle.dump(svod, open(os.environ.get('REZ_PATH','../rezultaty') + '/avtor_bic.pkl', 'wb'))
