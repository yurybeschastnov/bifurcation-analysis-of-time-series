"""Восстановленный скрипт, порождающий avtor_metriki.pkl.
В архиве его нет: avtor.py пишет только avtor_bic.pkl.
Запуск:  python zapusk.py  --  либо с теми же переменными среды, что задаёт zapusk.py.
Проверено: воспроизводит приложенный avtor_metriki.pkl на всех 13 рядах."""
import pickle, numpy as np, os, sys, warnings
warnings.filterwarnings('ignore')
import obshee as O, avtor as A

ORD = ['L1','L2','L3','L4','L5','L6','N1','N2','N3','N4','N5','N6','N7']

if __name__ == '__main__':
    out = {}
    for key in ORD:
        z = A.razmetka(key)
        d = O.dannye(key)
        si = O.sigma_ist(d); lab = d['lab']
        acc, _, _ = O.sopostavit(z['z'], lab, d['K'])
        out[key] = dict(K=d['K'], acc=acc, ari=O.ari(z['z'], lab),
                        l2=O.l2_sigma(z['sigma'], si),
                        perekl=int((np.diff(z['z']) != 0).sum()),
                        perekl_ist=int((np.diff(lab) != 0).sum()),
                        sigma_ist=[float(np.mean(si[lab == j])) for j in range(d['K'])])
        print('%-4s K=%d acc %.3f ari %.3f l2 %.3f' % (
            key, out[key]['K'], out[key]['acc'], out[key]['ari'], out[key]['l2']), flush=True)
    pickle.dump(out, open(os.environ.get('REZ_PATH', '.') + '/avtor_metriki.pkl', 'wb'))
    print('медианы: acc %.3f  ari %.3f  l2 %.3f' % tuple(
        np.median([out[k][p] for k in ORD]) for p in ('acc', 'ari', 'l2')))
