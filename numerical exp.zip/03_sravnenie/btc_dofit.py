"""Досчёт подгонок, не удавшихся общей схемой, и разбор причины.

На участке Б5 одноветвевая модель не была найдена ни в аффинном, ни в кубическом
классе. Первоначальное объяснение — «узкое допустимое окно, поиск в него не
попадает» — оказалось НЕВЕРНЫМ. При одной ветви драйвер определён явно,
W = (Y - c - a t) / b, поэтому все три жёсткие связи модели превращаются в связи
на единственный параметр b:

  полоса волатильности   b >= 0,25 max bref,  b <= 4 min bref
  квадратичная вариация  QV(W) = QV(Y)/b^2 in [0,70; 1,40]
  непрерывность драйвера |dW| <= tau sqrt(dt) при tau = 8, то есть
                         b >= max |dY| / (tau sqrt(dt))

Третья связь при первом разборе была упущена, а она и решает дело. На Б5
наибольшее нормированное приращение равно 11,67, поэтому непрерывность требует
b >= 1,459, тогда как полоса волатильности требует b <= 0,903. Пересечение
ПУСТО: одноветвевой модели на этом участке не существует, и дело не в поиске.

Это содержательный результат, а не помеха. Одна ветвь обязана объяснить и
скромную типичную волатильность, и одиночный скачок в 11,67 условных сигмы;
постоянным уровнем это несовместимо. Несколько ветвей снимают противоречие:
скачок приходится на ветвь с высокой волатильностью и перестаёт быть выбросом.

Скрипт вычисляет допустимое окно со ВСЕМИ тремя связями. Если окно непусто,
оно просматривается сеткой (для N = 1 это точное описание допустимого множества,
а не приближение). Если пусто — это записывается как свойство участка.
"""
import sys, os, time, pickle
import numpy as np
from scipy.optimize import minimize
import msde as M, pipeline as P, vetvi as V, podgonka as PG
import btc_kuski as BK
from btc_progon import FN, gotov, bic_odin

R = pickle.load(open(FN, 'rb'))


def okno_b(Y, t, dt, keep, bref):
    """Допустимое множество b при одной ветви, со всеми тремя связями."""
    kk = np.asarray(keep, bool)
    Yk, tk = np.asarray(Y)[kk], np.asarray(t)[kk]
    lo_p = V.BAND_LO * bref[kk].max()
    hi_p = V.BAND_HI * bref[kk].min()
    qv = float(np.sum(np.diff(Yk) ** 2) / np.sum(np.diff(tk)))
    lo_q = np.sqrt(qv / V.QV_HI)
    hi_q = np.sqrt(qv / V.QV_LO)
    zmax = float(np.max(np.abs(np.diff(Yk)) / np.sqrt(np.diff(tk))))
    lo_t = zmax / V.TAU_CONT          # непрерывность драйвера
    return (max(lo_p, lo_q, lo_t), min(hi_p, hi_q),
            dict(polosa=(lo_p, hi_p), qv=(lo_q, hi_q), tau=lo_t, zmax=zmax))


def odna_vetv(tag, kind, setka=48):
    d, Y, t, dt, keep, bref = gotov(tag)
    lo, hi, raz = okno_b(Y, t, dt, keep, bref)
    if not (hi > lo):
        return None, (lo, hi, raz)
    t0 = time.time()
    best = None
    for b in np.linspace(lo * 1.001, hi * 0.999, setka):
        br = [(0.0, 0.0, float(b)) + ((0.0,) if kind == 'cub' else ())]
        br = PG.uslovno_ca(Y, t, dt, br, kind, keep, bref)
        ll = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)[0]
        if np.isfinite(ll) and ll > -1e5 and (best is None or ll > best[0]):
            best = (ll, br)
    if best is None:
        return None, (lo, hi, raz)
    # доводка внутри окна: шаг принимается только если жёсткая проверка проходит
    x = PG._upak(best[1], kind)
    res = minimize(PG.kriterij, x, args=(Y, t, dt, 1, kind, keep, bref),
                   method='Nelder-Mead',
                   options=dict(maxiter=400, maxfev=400, xatol=1e-6, fatol=1e-6))
    kand = PG._raspak(res.x, 1, kind)
    lk = V.put(Y, t, dt, kand, kind, keep, bref, po_vetvi=True)[0]
    if np.isfinite(lk) and lk > best[0]:
        best = (lk, kand)
    br = best[1]
    r3 = PG.dovesti_marg(Y, t, dt, br, kind, keep, bref, maxiter=400)
    if r3['ll_marg'] > r3['ll_marg0'] + 1e-9:
        lh = V.put(Y, t, dt, r3['branches'], kind, keep, bref, po_vetvi=True)[0]
        if np.isfinite(lh) and lh > -1e5:
            br = r3['branches']
    llf, W, pv, dolya = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)
    tt = np.asarray(t)[np.asarray(keep, bool)]
    dW = np.diff(W); ddt = np.diff(tt); z = dW / np.sqrt(ddt)
    return dict(ll=float(llf), branches=br, kind=kind, N=1,
                dolya=list(dolya), qv=float(np.sum(dW ** 2) / np.sum(ddt)),
                lb=float(M.ljung_box(z ** 2, h=20)), perekl=0,
                sec=time.time() - t0, sposob='сетка по допустимому окну'), (lo, hi, raz)


if __name__ == '__main__':
    plohie = [k for k, v in R.items()
              if v is None and not k.startswith(('bic|', 'sl|'))]
    print('не удалось общей схемой:', plohie, flush=True)
    for k in plohie:
        tag, kind, N = k.split('|')
        if int(N) != 1:
            print('%s: не одноветвевой случай, пропуск' % k); continue
        out, (lo, hi, raz) = odna_vetv(tag, kind)
        if out is None:
            print('%s: одноветвевой модели НЕ СУЩЕСТВУЕТ.' % k, flush=True)
            print('    полоса волатильности: b in [%.3f, %.3f]' % raz['polosa'], flush=True)
            print('    квадратичная вариация: b in [%.3f, %.3f]' % raz['qv'], flush=True)
            print('    непрерывность драйвера: b >= %.3f (max |dY|/sqrt(dt) = %.2f)'
                  % (raz['tau'], raz['zmax']), flush=True)
            print('    пересечение [%.3f, %.3f] пусто' % (lo, hi), flush=True)
            R[k] = dict(nedopustimo=True, okno=(lo, hi), razbor=raz)
            pickle.dump(R, open(FN, 'wb'))
            continue
        R[k] = out
        print('%s: окно b [%.3f, %.3f], ll=%.1f, b=%.3f, qv=%.3f (%.0f с)'
              % (k, lo, hi, out['ll'], out['branches'][0][2], out['qv'], out['sec']),
              flush=True)
        pickle.dump(R, open(FN, 'wb'))
    # BIC для досчитанных
    for k in list(R):
        if k.startswith(('bic|', 'sl|')) or R[k] is None:
            continue
        tag, kind, N = k.split('|')
        mk = 'bic|%s|%s|%s' % (tag, kind, N)
        if R.get(mk) is None:
            R[mk] = bic_odin(tag, kind, int(N))
            pickle.dump(R, open(FN, 'wb'))
            print('  BIC пересчитан:', mk, flush=True)
    print('ГОТОВО', flush=True)
