"""Предложенный метод на пяти участках биткойна.

Повторяется тот же конвейер, что и на синтетике, без единого изменения в ядре:

    podognat5        портфель стартов (марковский, лестничный, Соболь)
    dovesti_sigma    доводка кубических ветвей в координатах опорных sigma
    dovesti_marg     доводка по точному маргинальному правдоподобию
    sliyanie_starty  обратный ход: из решения степени N+1 кандидаты степени N
    put_summa        BIC по точному маргинальному правдоподобию, kappa профилируется

Отличие от синтетики только одно: истинных режимов нет, поэтому ни ARI, ни доля
верных меток, ни E_L2 не определены. Считается то, что определено на реальных
данных: выбор числа ветвей, сами ветви, разметка и sigma вдоль пути.

Класс ветви (аффинный или кубический) метод тоже выбирает сам — по тому же
критерию, что и число ветвей.

    python btc_progon.py 900        считать не дольше 900 секунд, потом продолжить
"""
import sys, os, time, pickle
import numpy as np
from scipy.optimize import minimize
import msde as M, pipeline as P, vetvi as V, podgonka as PG
import btc_kuski as BK

FN = 'btc_rez.pkl'
KAP = np.linspace(2.5, 9.0, 14)
R = pickle.load(open(FN, 'rb')) if os.path.exists(FN) else {}


def gotov(tag):
    d = BK.kusok(tag)
    Y, t, dt = d['Y'], d['t'], d['dt']
    keep = P.censor_mask(Y, t, dt)
    bref = M.local_vol(Y, dt, 40)
    return d, Y, t, dt, keep, bref


def odna(tag, kind, N):
    d, Y, t, dt, keep, bref = gotov(tag)
    t0 = time.time()
    pred = R.get('%s|%s|%d' % (tag, kind, N - 1))
    brp = pred['branches'] if pred else None
    fit = PG.podognat5(Y, t, dt, N, kind, keep, bref, br_pred=brp,
                       n_sobol=32, n_dovodka=2, maxiter=450, seed=7)
    br, ll = fit['branches'], fit['ll']
    if kind == 'cub':
        r2 = PG.dovesti_sigma(Y, t, dt, br, keep, bref, vnesh=3, maxiter=600)
        if r2['ll'] > ll + 0.05:
            br, ll = r2['branches'], r2['ll']
    r3 = PG.dovesti_marg(Y, t, dt, br, kind, keep, bref, maxiter=400)
    if r3['ll_marg'] > r3['ll_marg0'] + 1e-9:
        lh = V.put(Y, t, dt, r3['branches'], kind, keep, bref, po_vetvi=True)[0]
        if np.isfinite(lh) and lh > -1e5:
            br, ll = r3['branches'], float(lh)
    llf, W, pv, dolya = V.put(Y, t, dt, br, kind, keep, bref, po_vetvi=True)
    tt = np.asarray(t)[np.asarray(keep, bool)]
    dW = np.diff(W); ddt = np.diff(tt); z = dW / np.sqrt(ddt)
    return dict(ll=float(llf), branches=br, kind=kind, N=N,
                dolya=list(dolya) if dolya is not None else None,
                qv=float(np.sum(dW ** 2) / np.sum(ddt)),
                lb=float(M.ljung_box(z ** 2, h=20)),
                perekl=int((np.diff(pv) != 0).sum()),
                sec=time.time() - t0)


def sliyanie(tag, kind, N):
    """Обратный ход: кандидаты степени N из решения степени N+1."""
    kk = '%s|%s|%d' % (tag, kind, N)
    ks = '%s|%s|%d' % (tag, kind, N + 1)
    if kk not in R or ks not in R or R[kk] is None or R[ks] is None:
        return False
    d, Y, t, dt, keep, bref = gotov(tag)
    best = (R[kk]['ll'], R[kk]['branches'])
    for br0 in PG.sliyanie_starty(Y, t, dt, R[ks]['branches'], kind, keep, bref):
        x = PG._upak(br0, kind); cur = -1e18
        for _ in range(3):
            rr = minimize(PG.kriterij, x, args=(Y, t, dt, N, kind, keep, bref),
                          method='Nelder-Mead',
                          options=dict(maxiter=500, maxfev=500, xatol=1e-6, fatol=1e-6))
            if -rr.fun <= cur + 1e-9:
                break
            cur = -rr.fun
            x = PG._upak(PG.uslovno_ca(Y, t, dt, PG._raspak(rr.x, N, kind),
                                       kind, keep, bref), kind)
        kand = PG._raspak(x, N, kind)
        if kind == 'cub':
            d2 = PG.dovesti_sigma(Y, t, dt, kand, keep, bref, vnesh=2, maxiter=400)
            if d2['ll'] > cur:
                cur, kand = d2['ll'], d2['branches']
        lh = V.put(Y, t, dt, kand, kind, keep, bref, po_vetvi=True)[0]
        if np.isfinite(lh) and lh > best[0] + 1e-9:
            best = (lh, kand)
    if best[0] > R[kk]['ll'] + 0.05:
        ll, W, pv, dol = V.put(Y, t, dt, best[1], kind, keep, bref, po_vetvi=True)
        v = dict(R[kk]); v.update(ll=float(best[0]), branches=best[1],
                                  dolya=list(dol) if dol is not None else None,
                                  perekl=int((np.diff(pv) != 0).sum()))
        R[kk] = v
        return True
    return False


def bic_odin(tag, kind, N):
    """BIC по точному маргинальному правдоподобию; kappa профилируется."""
    v = R.get('%s|%s|%d' % (tag, kind, N))
    if not v:
        return None
    d, Y, t, dt, keep, bref = gotov(tag)
    n = int(np.asarray(keep, bool).sum())
    p = 4 if kind == 'cub' else 3
    bst, kbst = -np.inf, np.log(n)
    for kp in KAP:
        l2, _ = V.put_summa(Y, t, dt, v['branches'], kind, keep, bref, kappa=kp)
        if np.isfinite(l2) and l2 > bst:
            bst, kbst = l2, kp
    if not np.isfinite(bst):
        return None
    return dict(ll_marg=float(bst), kappa=float(kbst),
                bic=float(-2 * bst + (p * N) * np.log(n)), n=n)


def zadachi():
    z = []
    for q in BK.KUSKI:
        for kind in ('aff', 'cub'):
            for N in range(1, q['vid'] + 3):
                z.append((q['tag'], kind, N))
    return z


if __name__ == '__main__':
    bud = float(sys.argv[1]) if len(sys.argv) > 1 else 900.
    t0 = time.time()
    for tag, kind, N in zadachi():
        kk = '%s|%s|%d' % (tag, kind, N)
        if kk in R:
            continue
        if time.time() - t0 > bud - 200:
            print('пауза, продолжайте тем же вызовом', flush=True); sys.exit(0)
        try:
            R[kk] = odna(tag, kind, N)
            v = R[kk]
            print('%-3s %-3s N=%d ll=%9.1f зан=%s qv=%.3f перекл=%3d (%.0f с)'
                  % (tag, kind, N, v['ll'],
                     np.round(np.sort(v['dolya']), 3) if v['dolya'] else '-',
                     v['qv'], v['perekl'], v['sec']), flush=True)
        except Exception as e:
            R[kk] = None
            print('%-3s %-3s N=%d ОШИБКА: %s' % (tag, kind, N, e), flush=True)
        pickle.dump(R, open(FN, 'wb'))
    print('\nподгонки готовы, обратный ход слиянием', flush=True)
    for q in BK.KUSKI:
        for kind in ('aff', 'cub'):
            for N in range(q['vid'] + 1, 1, -1):
                mk = 'sl|%s|%s|%d' % (q['tag'], kind, N)
                if mk in R:
                    continue
                if time.time() - t0 > bud - 200:
                    print('пауза', flush=True); sys.exit(0)
                try:
                    ok = sliyanie(q['tag'], kind, N)
                except Exception as e:
                    ok = False
                    print('  слияние %s %s N=%d ОШИБКА: %s' % (q['tag'], kind, N, e), flush=True)
                R[mk] = bool(ok)
                pickle.dump(R, open(FN, 'wb'))
                print('  слияние %s %s N=%d: %s' % (q['tag'], kind, N,
                                                    'улучшено' if ok else 'без изменений'), flush=True)
    print('\nBIC', flush=True)
    for q in BK.KUSKI:
        for kind in ('aff', 'cub'):
            for N in range(1, q['vid'] + 3):
                mk = 'bic|%s|%s|%d' % (q['tag'], kind, N)
                if mk in R:
                    continue
                R[mk] = bic_odin(q['tag'], kind, N)
                pickle.dump(R, open(FN, 'wb'))
        print('  %s готов' % q['tag'], flush=True)
    print('\nВСЁ ГОТОВО', flush=True)
