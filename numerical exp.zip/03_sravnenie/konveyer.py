"""Два эксперимента: Л (аффинные ветви) и Н (кубические ветви).

Сравниваются КОНВЕЙЕРЫ ЦЕЛИКОМ: каждый эталон сам определяет число режимов и
сам оценивает параметры. Никто не получает истинного K.
"""
import os, sys, os, pickle, time, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'sravnenie'))
import numpy as np
import obshee as O, metody as MT, metody2 as M2

FN = os.environ.get('REZ_PATH','../rezultaty') + '/konveyer.pkl'
RES = pickle.load(open(FN, 'rb')) if os.path.exists(FN) else {}
KMAX = 6


def met(z_pri, sig_toch, d):
    """z_pri — метки приращений; приводим к точкам и считаем метрики."""
    n = len(d['Y']); K = d['K']
    zt = O.tochki_iz_prirostov(np.asarray(z_pri), n)
    st = np.asarray(sig_toch)
    if len(st) == n - 1:
        st = np.r_[st[0], st]
    lab = d['lab']; si = O.sigma_ist(d)
    acc, mp, zm = O.sopostavit(zt, lab, K)
    return dict(acc=acc, ari=O.ari(zt, lab), l2=O.l2_sigma(st, si),
                perekl=int((np.diff(zt) != 0).sum()))


def sig_po_sost(z, sg):
    s = np.asarray(sg, float)
    s = np.where(np.isfinite(s), s, np.nanmedian(s[np.isfinite(s)]) if np.isfinite(s).any() else 1.0)
    return s[np.clip(np.asarray(z), 0, len(s) - 1)]


def odin(key, polnyi):
    d = O.dannye(key); r = d['r']; K = d['K']; n = len(d['Y'])
    rv = M2.lok_rv(d['Y'], d['dt'], 40)
    Wh = M2.drayver(d['Y'], rv)
    out = {}

    # ---------- эталон снизу: локальная волатильность без режимов -----------
    si = O.sigma_ist(d)
    out['rv'] = {h: O.l2_sigma(M2.lok_rv(d['Y'], d['dt'], h), si) for h in (10, 20, 40, 80)}

    # ---------- гауссова HMM: выбор K тремя критериями ----------------------
    t0 = time.time()
    H = MT.hmm(r, Kmax=KMAX, restarts=10)
    for crit in ('bic', 'aic', 'icl'):
        Kh = min(H, key=lambda k: H[k][crit])
        v = H[Kh]
        out['hmm_' + crit] = dict(K=Kh, sigma=np.sort(v['sigma']).tolist(),
                                  **met(v['z'], sig_po_sost(v['z'], v['sigma']), d))
    out['hmm_krivaya'] = {k: dict(bic=float(v['bic']), icl=float(v['icl']),
                                  ll=float(v['ll'])) for k, v in H.items()}
    # при ИСТИННОМ K — отделяет ошибку выбора от ошибки оценивания
    v = H[K]
    out['hmm_pri_K'] = dict(K=K, sigma=np.sort(v['sigma']).tolist(),
                            **met(v['z'], sig_po_sost(v['z'], v['sigma']), d))
    out['sec_hmm'] = time.time() - t0

    # ---------- липкая HDP-HMM ---------------------------------------------
    t0 = time.time()
    Hd = MT.hdphmm(r, L=10, iters=500, burn=200, seed=1)
    out['hdphmm'] = dict(K=Hd['K'], post=Hd['post'].tolist(),
                         sigma=np.sort(Hd['sigma']).tolist(),
                         **met(Hd['z'], sig_po_sost(Hd['z'], Hd['sigma']), d))
    out['sec_hdp'] = time.time() - t0

    # ---------- разладка PELT + кластеризация -------------------------------
    Pt = MT.pelt(r, Kmax=KMAX)
    out['pelt'] = dict(K=Pt['K'], nseg=Pt['nseg'], sigma=np.sort(Pt['sigma']).tolist(),
                       **met(Pt['z'], sig_po_sost(Pt['z'], Pt['sigma']), d))

    # ---------- процесс Дирихле (только выбор K) + HMM ----------------------
    Dp = MT.dpgmm(r, Kmax=10)
    Kd = max(1, min(Dp['K'], KMAX))
    v = H[Kd]
    out['dp_hmm'] = dict(K=Kd, sigma=np.sort(v['sigma']).tolist(),
                         **met(v['z'], sig_po_sost(v['z'], v['sigma']), d))

    # ---------- ядерная sigma_j(w) поверх выбранной разметки ----------------
    Kb = out['hmm_bic']['K']
    zb = H[Kb]['z']
    sg = M2.yadro_sigma2(r, zb, Wh, Kb)
    out['yadro'] = dict(K=Kb, **met(zb, sg, d))
    sg2 = M2.yadro_sigma2(r, H[K]['z'], Wh, K)
    out['yadro_pri_K'] = dict(K=K, **met(H[K]['z'], sg2, d))

    if polnyi:
        # ---------- HMM со смесевыми эмиссиями ------------------------------
        t0 = time.time()
        Sm = M2.hmm_smes(r, Kmax=4, M=3, restarts=4)
        if Sm:
            Ks = min(Sm, key=lambda k: Sm[k]['bic'])
            v = Sm[Ks]
            out['smes'] = dict(K=Ks, sigma=np.sort(v['sigma']).tolist(),
                               **met(v['z'], sig_po_sost(v['z'], v['sigma']), d))
            if K in Sm:
                v = Sm[K]
                out['smes_pri_K'] = dict(K=K, **met(v['z'], sig_po_sost(v['z'], v['sigma']), d))
        out['sec_smes'] = time.time() - t0

        # ---------- MS-GARCH ------------------------------------------------
        t0 = time.time()
        Mg = M2.msgarch(r, Kmax=3, starts=1)
        if Mg:
            Kg = min(Mg, key=lambda k: Mg[k]['bic'])
            v = Mg[Kg]
            out['msgarch'] = dict(K=Kg, sigma=np.sort(v['sigma']).tolist(),
                                  **met(v['z'], v['sigma_t'], d))
            if K in Mg:
                v = Mg[K]
                out['msgarch_pri_K'] = dict(K=K, **met(v['z'], v['sigma_t'], d))
        out['sec_msg'] = time.time() - t0
    return out


if __name__ == '__main__':
    zad = sys.argv[1:]
    for key in zad:
        if key in RES:
            print('%s уже есть' % key); continue
        t0 = time.time()
        RES[key] = odin(key, polnyi=key.startswith('N'))
        pickle.dump(RES, open(FN, 'wb'))
        print('%-4s готово за %.0f с' % (key, time.time() - t0), flush=True)
    print('всего рядов: %d' % len(RES))
