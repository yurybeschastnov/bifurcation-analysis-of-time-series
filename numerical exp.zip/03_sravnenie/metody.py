"""Классические (не нейросетевые) методы определения режимов.

Все методы получают ровно тот же вход: нормированные приращения
r_i = dY_i / sqrt(dt), i = 1..n-1. Ни один не видит W, метки и истинные
параметры. Возвращают: число режимов, метки приращений, sigma по режимам.
"""
import numpy as np, warnings
warnings.filterwarnings('ignore')

# ------------------------------------------------------------------ GMM + BIC
def gmm(r, Kmax=6, seed=0):
    from sklearn.mixture import GaussianMixture
    X = r.reshape(-1, 1); out = {}
    for K in range(1, Kmax + 1):
        g = GaussianMixture(K, covariance_type='full', n_init=10, random_state=seed,
                            max_iter=500, reg_covar=1e-8).fit(X)
        out[K] = dict(bic=g.bic(X), aic=g.aic(X), ll=g.score(X) * len(X),
                      z=g.predict(X), sigma=np.sqrt(g.covariances_.ravel()),
                      mu=g.means_.ravel())
    return out

# ------------------------------------------------------------------ HMM + BIC/AIC/ICL
def hmm(r, Kmax=6, restarts=12, seed=0):
    from hmmlearn.hmm import GaussianHMM
    X = r.reshape(-1, 1); n = len(X); out = {}
    for K in range(1, Kmax + 1):
        best = None
        for s in range(restarts):
            m = GaussianHMM(n_components=K, covariance_type='diag', n_iter=300,
                            tol=1e-4, random_state=seed * 100 + s,
                            init_params='stmc', min_covar=1e-8)
            try:
                m.fit(X); ll = m.score(X)
            except Exception:
                continue
            if not np.isfinite(ll):
                continue
            if best is None or ll > best[0]:
                best = (ll, m)
        if best is None:
            continue
        ll, m = best
        p = K * K + K - 1                     # переходы + начальные + mu + sigma
        z = m.predict(X)
        g = m.predict_proba(X)
        ent = -np.sum(g * np.log(np.maximum(g, 1e-300)))
        out[K] = dict(ll=ll, bic=-2 * ll + p * np.log(n), aic=-2 * ll + 2 * p,
                      icl=-2 * ll + p * np.log(n) + 2 * ent, z=z,
                      sigma=np.sqrt(m.covars_.ravel()), mu=m.means_.ravel(),
                      A=m.transmat_, model=m)
    return out

# --------------------------------------------- марковское переключение (Гамильтон)
def msm(r, Kmax=4, seed=0):
    """statsmodels MarkovRegression: переключение среднего и дисперсии."""
    import statsmodels.api as sm
    out = {}
    n = len(r)
    for K in range(1, Kmax + 1):
        try:
            if K == 1:
                mu, sd = r.mean(), r.std()
                ll = float(np.sum(-0.5 * ((r - mu) / sd) ** 2 - np.log(sd) - 0.5 * np.log(2 * np.pi)))
                out[K] = dict(ll=ll, bic=-2 * ll + 2 * np.log(n), z=np.zeros(n, int),
                              sigma=np.array([sd]), mu=np.array([mu]))
                continue
            mod = sm.tsa.MarkovRegression(r, k_regimes=K, trend='c', switching_variance=True)
            res = mod.fit(search_reps=6, em_iter=15, maxiter=150, disp=False)
            z = np.asarray(res.smoothed_marginal_probabilities).argmax(axis=1)
            sg = np.sqrt(np.abs(res.params[-K:]))
            mu = np.asarray(res.params[:K])
            p = K * K + K - 1
            out[K] = dict(ll=float(res.llf), bic=-2 * res.llf + p * np.log(n),
                          z=z, sigma=sg, mu=mu)
        except Exception as e:
            out[K] = dict(oshibka=str(e)[:60])
    return out

# ------------------------------------------------ дирихле-процесс (число режимов)
def dpgmm(r, Kmax=10, seed=0, porog=0.02):
    from sklearn.mixture import BayesianGaussianMixture
    X = r.reshape(-1, 1)
    g = BayesianGaussianMixture(n_components=Kmax, covariance_type='full',
                                weight_concentration_prior_type='dirichlet_process',
                                weight_concentration_prior=1.0, max_iter=1000,
                                n_init=5, random_state=seed, reg_covar=1e-8).fit(X)
    z = g.predict(X)
    zan = np.array([np.mean(z == k) for k in range(Kmax)])
    K = int(np.sum(zan > porog))
    return dict(K=K, z=z, w=g.weights_, zan=zan, sigma=np.sqrt(g.covariances_.ravel()))

# --------------------------------- разладка (PELT) + кластеризация сегментов
def pelt(r, Kmax=6, seed=0):
    """Классический двухшаговый подход: разладка по дисперсии, затем кластеризация
    сегментов по log-дисперсии; число кластеров по BIC."""
    import ruptures as rpt
    from sklearn.mixture import GaussianMixture
    n = len(r)
    x = r.reshape(-1, 1)
    pen = 2 * np.log(n)                       # BIC-штраф на разладку в CostNormal
    alg = rpt.Pelt(model='normal', min_size=15, jump=1).fit(x)
    bkps = alg.predict(pen=pen)
    seg = np.split(np.arange(n), bkps[:-1])
    lv = np.array([np.log(np.var(r[s]) + 1e-12) for s in seg])
    dl = np.array([len(s) for s in seg], float)
    nseg = len(seg)
    from sklearn.cluster import KMeans
    best = None
    for K in range(1, min(Kmax, nseg) + 1):
        km = KMeans(K, n_init=20, random_state=seed).fit(lv.reshape(-1, 1), sample_weight=dl)
        cl = km.labels_
        zz = np.empty(n, int)
        for s, c in zip(seg, cl):
            zz[s] = c
        # правдоподобие ИСХОДНЫХ приращений при такой разметке
        ll = 0.0
        for k in range(K):
            m = zz == k
            if m.sum() < 2:
                continue
            ll += float(np.sum(-0.5 * ((r[m] - r[m].mean()) / r[m].std()) ** 2
                               - np.log(r[m].std()) - 0.5 * np.log(2 * np.pi)))
        b = -2 * ll + 2 * K * np.log(n)
        if best is None or b < best[0]:
            best = (b, K, zz)
    _, K, z = best
    sg = np.array([np.std(r[z == k]) if (z == k).any() else np.nan for k in range(K)])
    return dict(K=K, z=z, sigma=sg, nseg=nseg, bkps=bkps)

# ------------------------------------------- липкая HDP-HMM (слабый предел, Гиббс)
def hdphmm(r, L=10, iters=800, burn=300, seed=0, kappa_st=50.0, alpha=3.0, gam=3.0):
    """Sticky HDP-HMM, приближение слабого предела (Fox et al. 2011).
    Эмиссии N(mu, s2), сопряжённый приор NIG. Возвращает апостериорное
    распределение числа занятых состояний."""
    rng = np.random.default_rng(seed)
    n = len(r)
    m0, k0, a0, b0 = 0.0, 0.01, 2.0, np.var(r)
    z = rng.integers(0, 3, n)
    beta = np.ones(L) / L
    zan_hist = []
    z_last = None
    for it in range(iters):
        # --- параметры эмиссий
        mu = np.empty(L); s2 = np.empty(L)
        for k in range(L):
            m = z == k; nk = int(m.sum())
            if nk:
                xb = r[m].mean(); ss = np.sum((r[m] - xb) ** 2)
            else:
                xb = 0.0; ss = 0.0
            kn = k0 + nk; mn = (k0 * m0 + nk * xb) / kn
            an = a0 + nk / 2.0
            bn = b0 + 0.5 * ss + 0.5 * k0 * nk * (xb - m0) ** 2 / kn
            s2[k] = 1.0 / rng.gamma(an, 1.0 / bn)
            mu[k] = mn + np.sqrt(s2[k] / kn) * rng.normal()
        # --- матрица переходов
        C = np.zeros((L, L))
        np.add.at(C, (z[:-1], z[1:]), 1.0)
        A = np.empty((L, L))
        for j in range(L):
            par = alpha * beta + C[j] + kappa_st * np.eye(L)[j]
            g = rng.gamma(np.maximum(par, 1e-6)); A[j] = g / g.sum()
        # --- beta (упрощённо: пропорционально числу занятых переходов + gamma/L)
        mbar = (C > 0).sum(axis=0).astype(float)
        gb = rng.gamma(np.maximum(gam / L + mbar, 1e-6)); beta = gb / gb.sum()
        # --- прямой фильтр / обратная выборка
        lo = -0.5 * (r[:, None] - mu[None, :]) ** 2 / s2[None, :] - 0.5 * np.log(2 * np.pi * s2)[None, :]
        lo = np.exp(lo - lo.max(axis=1, keepdims=True))
        f = np.empty((n, L))
        v = np.ones(L) / L * lo[0]; f[0] = v / v.sum()
        for i in range(1, n):
            v = (f[i - 1] @ A) * lo[i]
            s = v.sum(); f[i] = v / (s if s > 0 else 1.0)
        z = np.empty(n, int)
        z[n - 1] = rng.choice(L, p=f[n - 1])
        for i in range(n - 2, -1, -1):
            p = f[i] * A[:, z[i + 1]]
            p = p / p.sum()
            z[i] = rng.choice(L, p=p)
        if it >= burn:
            zan_hist.append(int(np.sum(np.bincount(z, minlength=L) > 0.01 * n)))
            z_last = z.copy()
    zan_hist = np.array(zan_hist)
    K = int(np.bincount(zan_hist).argmax())
    # перенумеровать по занятости
    cnt = np.bincount(z_last, minlength=L)
    ordk = np.argsort(-cnt)
    remap = np.zeros(L, int)
    for i, k in enumerate(ordk):
        remap[k] = i
    zz = remap[z_last]
    keep = zz < K
    zz = np.where(keep, zz, 0)
    sg = np.array([np.std(r[zz == k]) if (zz == k).any() else np.nan for k in range(K)])
    return dict(K=K, z=zz, sigma=sg, post=np.bincount(zan_hist, minlength=L + 1) / len(zan_hist))
