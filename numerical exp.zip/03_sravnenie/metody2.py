"""Эталонные конвейеры второго уровня: непостоянная волатильность внутри режима.

Для рядов Н гауссова HMM мисспецифицирована: sigma(w) = b + 3 r w^2 меняется
вдоль траектории внутри одного режима. Здесь собраны классические (не
нейросетевые) методы, которые это умеют:

  hmm_smes    HMM со смесевыми эмиссиями (масштабная смесь нормальных) — стандартный
              непараметрический по форме эмиссии вариант; K по BIC
  msgarch     марковское переключение с GARCH внутри режима (Haas-Mittnik-Paolella,
              2004): K параллельных рекурсий дисперсии, точный фильтр Гамильтона
  yadro_sigma ядерная оценка sigma_j(w) по восстановленному драйверу — непараметрический
              аналог структурного предположения, без знания вида ветви
  lok_rv      локальная реализованная волатильность: эталон снизу для нормы E_L2
"""
import numpy as np, warnings
warnings.filterwarnings('ignore')
from scipy.optimize import minimize


# ------------------------------------------------- HMM со смесевыми эмиссиями
def hmm_smes(r, Kmax=5, M=3, restarts=8, seed=0):
    from hmmlearn.hmm import GMMHMM
    X = r.reshape(-1, 1); n = len(X); out = {}
    for K in range(1, Kmax + 1):
        best = None
        for s in range(restarts):
            m = GMMHMM(n_components=K, n_mix=M, covariance_type='diag', n_iter=200,
                       tol=1e-3, random_state=seed * 100 + s, min_covar=1e-8)
            try:
                m.fit(X); ll = m.score(X)
            except Exception:
                continue
            if np.isfinite(ll) and (best is None or ll > best[0]):
                best = (ll, m)
        if best is None:
            continue
        ll, m = best
        p = (K - 1) + K * (K - 1) + K * (3 * M - 1)
        z = m.predict(X)
        # sigma состояния = корень из полной дисперсии смеси
        sg = np.empty(K)
        for k in range(K):
            w = m.weights_[k]; mu = m.means_[k].ravel(); v = m.covars_[k].ravel()
            m1 = float(np.sum(w * mu)); m2 = float(np.sum(w * (v + mu ** 2)))
            sg[k] = np.sqrt(max(m2 - m1 ** 2, 1e-12))
        out[K] = dict(ll=ll, bic=-2 * ll + p * np.log(n), z=z, sigma=sg, model=m)
    return out


# ----------------------------------------------------------------- MS-GARCH
def _msg_ll(par, r, K, vernut=False):
    """Haas-Mittnik-Paolella: K параллельных рекурсий h_{j,t}, фильтр Гамильтона."""
    n = len(r)
    om = np.exp(par[:K])
    al = 1.0 / (1.0 + np.exp(-par[K:2 * K])) * 0.5
    be = 1.0 / (1.0 + np.exp(-par[2 * K:3 * K])) * 0.99
    su = al + be
    al = np.where(su >= 0.999, al * 0.999 / su, al)
    be = np.where(su >= 0.999, be * 0.999 / su, be)
    if K == 1:
        P = np.ones((1, 1))
    else:
        Q = par[3 * K:].reshape(K, K - 1)
        P = np.empty((K, K))
        for j in range(K):
            e = np.r_[0.0, Q[j]]
            e = np.exp(e - e.max()); P[j] = e / e.sum()
    v0 = float(np.var(r))
    h = om / np.maximum(1.0 - al - be, 1e-3)
    h = np.clip(h, 1e-8, 1e4)
    xi = np.ones(K) / K
    ll = 0.0
    H = np.empty((n, K)); XI = np.empty((n, K)); PR = np.empty((n, K))
    for t in range(n):
        pred = xi @ P if t > 0 else xi
        H[t] = h
        eta = np.exp(-0.5 * r[t] ** 2 / h) / np.sqrt(2 * np.pi * h)
        w = pred * eta
        s = w.sum()
        if not np.isfinite(s) or s <= 1e-300:
            return (1e10, None) if vernut else 1e10
        ll += np.log(s)
        xi = w / s
        XI[t] = xi; PR[t] = pred
        h = om + al * r[t] ** 2 + be * h
        h = np.clip(h, 1e-8, 1e4)
    if vernut:
        # сглаживание Кима
        SM = np.empty((n, K)); SM[-1] = XI[-1]
        for t in range(n - 2, -1, -1):
            pr = XI[t] @ P
            pr = np.where(pr > 1e-300, pr, 1e-300)
            SM[t] = XI[t] * ((SM[t + 1] / pr) @ P.T)
            SM[t] /= SM[t].sum()
        return -ll, dict(H=H, SM=SM, P=P, om=om, al=al, be=be)
    return -ll


def msgarch(r, Kmax=3, starts=3, seed=0):
    n = len(r); out = {}
    rng = np.random.default_rng(seed)
    v = float(np.var(r))
    for K in range(1, Kmax + 1):
        npar = 3 * K + (K * (K - 1) if K > 1 else 0)
        best = None
        for s in range(starts):
            x0 = np.empty(npar)
            x0[:K] = np.log(v * np.linspace(0.3, 1.5, K) * 0.1 * (1 + 0.2 * rng.normal(size=K)))
            x0[K:2 * K] = -2.0 + 0.5 * rng.normal(size=K)
            x0[2 * K:3 * K] = 2.0 + 0.5 * rng.normal(size=K)
            if K > 1:
                x0[3 * K:] = 3.0 + 0.5 * rng.normal(size=K * (K - 1))
            try:
                res = minimize(_msg_ll, x0, args=(r, K), method='L-BFGS-B',
                               options=dict(maxiter=300, maxfun=600))
            except Exception:
                continue
            if np.isfinite(res.fun) and (best is None or res.fun < best[0]):
                best = (res.fun, res.x)
        if best is None:
            continue
        nll, xb = best
        _, aux = _msg_ll(xb, r, K, vernut=True)
        ll = -nll
        z = aux['SM'].argmax(axis=1)
        sig_t = np.sqrt(aux['H'][np.arange(n), z])
        out[K] = dict(ll=ll, bic=-2 * ll + npar * np.log(n), z=z, sigma_t=sig_t,
                      sigma=np.array([np.median(sig_t[z == k]) if (z == k).any() else np.nan
                                      for k in range(K)]))
    return out


# ------------------------------------------- локальная реализованная волатильность
def lok_rv(Y, dt, h=40):
    dY = np.diff(Y, prepend=Y[0]); q = dY ** 2
    ker = np.ones(2 * h) / (2 * h * dt)
    pad = np.r_[np.full(h, q[1:h + 1].mean()), q, np.full(h, q[-h:].mean())]
    v = np.convolve(pad, ker, mode='same')[h:h + len(Y)]
    return np.sqrt(np.maximum(v, 1e-12))


def drayver(Y, sg):
    """Де-волатилизация: dW = dY / sigma, W_0 = 0."""
    dY = np.diff(Y)
    return np.r_[0.0, np.cumsum(dY / sg[1:])]


# ------------------------------------- ядерная оценка sigma_j(w) внутри режима
def yadro_sigma(r, z, Wh, K, hf=0.25):
    """Локально-линейная регрессия log r^2 на драйвер внутри каждого режима.

    Ничего не знает о виде ветви: это непараметрический аналог структурного
    предположения sigma = sigma_j(w).
    """
    n = len(r)
    x = Wh[1:]                                  # драйвер в конце приращения
    y = np.log(np.maximum(r ** 2, 1e-12))
    out = np.empty(n)
    for k in range(K):
        m = z == k
        if m.sum() < 30:
            out[m] = np.std(r[m]) if m.any() else np.nan
            continue
        xk, yk = x[m], y[m]
        b = max(hf * np.std(xk) * (m.sum()) ** (-0.2) * 5.0, 1e-3)
        U = (xk[None, :] - xk[:, None]) / b
        Wt = np.exp(-0.5 * U ** 2)
        D = xk[None, :] - xk[:, None]
        s0 = Wt.sum(1); s1 = (Wt * D).sum(1); s2 = (Wt * D ** 2).sum(1)
        t0 = (Wt * yk[None, :]).sum(1); t1 = (Wt * D * yk[None, :]).sum(1)
        den = s0 * s2 - s1 ** 2
        est = np.where(np.abs(den) > 1e-10, (s2 * t0 - s1 * t1) / np.where(np.abs(den) > 1e-10, den, 1.0),
                       yk.mean())
        # поправка на смещение log chi^2_1: E log z^2 = -1.2704 при z~N(0,1)
        out[m] = np.exp(0.5 * (est + 1.2704))
    return out


def yadro_sigma2(r, z, Wh, K, setka=(0.03, 0.05, 0.08, 0.12, 0.2, 0.3, 0.5)):
    """sigma_j(w) локально-линейной регрессией r^2 на драйвер; полоса по
    скользящему контролю (без подглядывания в истину)."""
    n = len(r); x = Wh[1:]; y = r ** 2
    out = np.empty(n)
    for k in range(K):
        m = z == k
        if m.sum() < 40:
            out[m] = np.std(r[m]) if m.any() else np.nan
            continue
        xk, yk = x[m], y[m]
        D = xk[None, :] - xk[:, None]
        best = None
        for b in setka:
            Wt = np.exp(-0.5 * (D / b) ** 2)
            np.fill_diagonal(Wt, 0.0)                    # исключение своей точки
            s0 = Wt.sum(1); s1 = (Wt * D).sum(1); s2 = (Wt * D ** 2).sum(1)
            t0 = (Wt * yk[None, :]).sum(1); t1 = (Wt * D * yk[None, :]).sum(1)
            den = s0 * s2 - s1 ** 2
            f = np.where(np.abs(den) > 1e-12, (s2 * t0 - s1 * t1) /
                         np.where(np.abs(den) > 1e-12, den, 1.0), yk.mean())
            cv = float(np.mean((yk - f) ** 2))
            if best is None or cv < best[0]:
                best = (cv, b)
        b = best[1]
        Wt = np.exp(-0.5 * (D / b) ** 2)
        s0 = Wt.sum(1); s1 = (Wt * D).sum(1); s2 = (Wt * D ** 2).sum(1)
        t0 = (Wt * yk[None, :]).sum(1); t1 = (Wt * D * yk[None, :]).sum(1)
        den = s0 * s2 - s1 ** 2
        f = np.where(np.abs(den) > 1e-12, (s2 * t0 - s1 * t1) /
                     np.where(np.abs(den) > 1e-12, den, 1.0), yk.mean())
        out[m] = np.sqrt(np.maximum(f, 1e-8))
    return out
