"""Переключающаяся стохастическая волатильность (Markov-switching SV).

    r_t = exp(h_t/2) eps_t,           eps_t ~ N(0,1)
    h_t = mu_{z_t} + phi (h_{t-1} - mu_{z_{t-1}}) + sigma_eta eta_t
    z_t — марковская цепь на K состояниях

So-Lam-Li (1998). Оценивание по Ким-Шепард-Чибу (1998): линеаризация
y* = log r^2 = h + log eps^2 и приближение log chi^2_1 смесью семи нормальных,
после чего h выбирается прямым фильтром с обратной выборкой, z — тем же приёмом
с парными потенциалами, параметры — сопряжёнными шагами.

Число режимов: BIC по правдоподобию, оценённому частичным фильтром в
апостериорных средних (точное правдоподобие требует интегрирования по (h,z)
совместно и недоступно в замкнутой форме).

Ничего нейросетевого: MCMC + частичный фильтр.
"""
import numpy as np

# смесь семи нормальных для log chi^2_1 (Kim-Shephard-Chib, табл. 4)
QM = np.array([0.00730, 0.10556, 0.00002, 0.04395, 0.34001, 0.24566, 0.25750])
MM = np.array([-10.12999, -3.97281, -8.56686, 2.77786, 0.61942, 1.79518, -1.08819]) - 1.2704
VM = np.array([5.79596, 2.61369, 5.17950, 0.16735, 0.64009, 0.34023, 1.26261])


def _ffbs_h(ys, cs, vs, a, phi, se2, mu_z1, rng):
    """Прямой фильтр + обратная выборка для h (скалярный Калман)."""
    n = len(ys)
    hf = np.empty(n); Pf = np.empty(n)
    # t = 0
    P0 = se2 / max(1.0 - phi * phi, 1e-4)
    Kg = P0 / (P0 + vs[0])
    hf[0] = mu_z1 + Kg * (ys[0] - cs[0] - mu_z1); Pf[0] = (1.0 - Kg) * P0
    for t in range(1, n):
        hp = a[t] + phi * hf[t - 1]
        Pp = phi * phi * Pf[t - 1] + se2
        Kg = Pp / (Pp + vs[t])
        hf[t] = hp + Kg * (ys[t] - cs[t] - hp)
        Pf[t] = (1.0 - Kg) * Pp
    h = np.empty(n)
    g = rng.standard_normal(n)
    h[n - 1] = hf[n - 1] + np.sqrt(max(Pf[n - 1], 1e-12)) * g[n - 1]
    for t in range(n - 2, -1, -1):
        d = phi * phi * Pf[t] + se2
        gain = phi * Pf[t] / d
        m = hf[t] + gain * (h[t + 1] - a[t + 1] - phi * hf[t])
        v = max(Pf[t] - gain * phi * Pf[t], 1e-12)
        h[t] = m + np.sqrt(v) * g[t]
    return h


def _ffbs_z(h, mu, phi, se2, A, rng):
    """Выборка цепи z: потенциал зависит от ПАРЫ (z_{t-1}, z_t)."""
    n = len(h); K = len(mu)
    lo = np.empty((n, K, K))          # lo[t, j, k] = log N(h_t | mu_k + phi(h_{t-1}-mu_j))
    d = h[1:, None, None] - (mu[None, None, :] + phi * (h[:-1, None, None] - mu[None, :, None]))
    lo[1:] = -0.5 * d * d / se2
    f = np.empty((n, K))
    v = -0.5 * (h[0] - mu) ** 2 / (se2 / max(1 - phi * phi, 1e-4))
    v = np.exp(v - v.max()); f[0] = v / v.sum()
    lA = np.log(np.maximum(A, 1e-300))
    for t in range(1, n):
        M = lo[t] + lA
        M = M - M.max()
        w = f[t - 1] @ np.exp(M)
        s = w.sum()
        f[t] = w / (s if s > 0 else 1.0)
    z = np.empty(n, int)
    u = rng.random(n)
    c = np.cumsum(f[n - 1]); z[n - 1] = int(np.searchsorted(c, u[n - 1] * c[-1]))
    for t in range(n - 2, -1, -1):
        p = f[t] * np.exp(lo[t + 1][:, z[t + 1]] - lo[t + 1][:, z[t + 1]].max()) * A[:, z[t + 1]]
        s = p.sum()
        if s <= 0:
            p = f[t]; s = p.sum()
        c = np.cumsum(p); z[t] = int(np.searchsorted(c, u[t] * c[-1]))
    return z


def podgon(r, K, iters=1200, burn=400, seed=0, ig=(2.5, 0.05), phi_pr=(0.9, 0.25)):
    rng = np.random.default_rng(seed)
    n = len(r)
    ys = np.log(r ** 2 + 1e-8)
    lv = float(np.log(np.var(r)))
    mu = lv + np.linspace(-0.7, 0.7, K) if K > 1 else np.array([lv])
    phi = 0.95; se2 = 0.05
    A = np.full((K, K), 0.02 / max(K - 1, 1)); np.fill_diagonal(A, 0.98)
    if K == 1:
        A = np.ones((1, 1))
    # старт: кластеризация сглаженного log r^2 -> разумная начальная разметка
    if K > 1:
        from sklearn.cluster import KMeans
        sm = np.convolve(ys, np.ones(31) / 31.0, mode='same')
        km = KMeans(K, n_init=10, random_state=seed).fit(sm.reshape(-1, 1))
        o = np.argsort(km.cluster_centers_.ravel())
        z = np.argsort(o)[km.labels_]
        mu = np.sort(km.cluster_centers_.ravel())
    else:
        z = np.zeros(n, int)
    h = np.convolve(ys, np.ones(11) / 11.0, mode='same')
    nak_mu = []; nak_z = []; nak_h = []; nak_p = []
    for it in range(iters):
        # --- индикаторы смеси
        lp = (-0.5 * (ys[:, None] - h[:, None] - MM[None, :]) ** 2 / VM[None, :]
              - 0.5 * np.log(VM)[None, :] + np.log(QM)[None, :])
        lp -= lp.max(axis=1, keepdims=True)
        P = np.exp(lp); P /= P.sum(axis=1, keepdims=True)
        u = rng.random(n)
        s = (P.cumsum(axis=1) < u[:, None]).sum(axis=1).clip(0, 6)
        cs = MM[s]; vs = VM[s]
        # --- h
        a = np.empty(n); a[0] = 0.0
        a[1:] = mu[z[1:]] - phi * mu[z[:-1]]
        h = _ffbs_h(ys, cs, vs, a, phi, se2, mu[z[0]], rng)
        # --- z
        if K > 1:
            z = _ffbs_z(h, mu, phi, se2, A, rng)
            C = np.zeros((K, K)); np.add.at(C, (z[:-1], z[1:]), 1.0)
            for j in range(K):
                g = rng.gamma(1.0 + C[j]); A[j] = g / g.sum()
        # --- mu (сопряжённо)
        D = np.zeros((n, K)); y = np.empty(n); wgt = np.empty(n)
        D[0, z[0]] = 1.0; y[0] = h[0]; wgt[0] = max(1 - phi * phi, 1e-4) / se2
        idx = np.arange(1, n)
        D[idx, z[1:]] += 1.0
        D[idx, z[:-1]] -= phi
        y[1:] = h[1:] - phi * h[:-1]; wgt[1:] = 1.0 / se2
        Pr = (D * wgt[:, None]).T @ D + np.eye(K) / 9.0
        bb = (D * wgt[:, None]).T @ y + lv / 9.0
        Sg = np.linalg.inv(Pr + 1e-9 * np.eye(K))
        mu = Sg @ bb + np.linalg.cholesky(Sg) @ rng.standard_normal(K)
        if K > 1:
            o = np.argsort(mu)                     # фиксация перестановки меток
            mu = mu[o]; inv = np.argsort(o); z = inv[z]; A = A[np.ix_(o, o)]
        # --- phi, sigma_eta^2
        x = h - mu[z]
        s11 = float(x[:-1] @ x[:-1]); s10 = float(x[:-1] @ x[1:])
        pv = 1.0 / (s11 / se2 + 1.0 / phi_pr[1] ** 2)
        pm = pv * (s10 / se2 + phi_pr[0] / phi_pr[1] ** 2)
        for _ in range(20):
            cand = pm + np.sqrt(pv) * rng.standard_normal()
            if -0.999 < cand < 0.999:
                phi = float(cand); break
        e = x[1:] - phi * x[:-1]
        se2 = float(1.0 / rng.gamma(ig[0] + (n - 1) / 2.0, 1.0 / (ig[1] + 0.5 * float(e @ e))))
        se2 = min(max(se2, 1e-5), 5.0)
        if it >= burn:
            nak_mu.append(mu.copy()); nak_z.append(z.copy())
            nak_h.append(h.copy()); nak_p.append((phi, se2))
    Z = np.array(nak_z); H = np.array(nak_h)
    zmod = np.array([np.bincount(Z[:, i], minlength=K).argmax() for i in range(n)])
    return dict(mu=np.mean(nak_mu, axis=0), phi=float(np.mean([p[0] for p in nak_p])),
                se2=float(np.mean([p[1] for p in nak_p])), A=A, z=zmod,
                h=H.mean(axis=0), sigma_t=np.exp(H / 2.0).mean(axis=0), K=K)


def pf_ll(r, par, npart=1500, seed=0):
    """Логарифм правдоподобия частичным фильтром в заданных параметрах."""
    rng = np.random.default_rng(seed)
    mu, phi, se2, A, K = par['mu'], par['phi'], par['se2'], par['A'], par['K']
    n = len(r); se = np.sqrt(se2)
    z = rng.integers(0, K, npart)
    h = mu[z] + np.sqrt(se2 / max(1 - phi * phi, 1e-4)) * rng.standard_normal(npart)
    cum = np.cumsum(A, axis=1)
    ll = 0.0
    for t in range(n):
        if t > 0:
            u = rng.random(npart)
            znew = (cum[z] < u[:, None]).sum(axis=1).clip(0, K - 1)
            h = mu[znew] + phi * (h - mu[z]) + se * rng.standard_normal(npart)
            z = znew
        lw = -0.5 * r[t] ** 2 / np.exp(h) - 0.5 * h
        m = lw.max()
        w = np.exp(lw - m)
        sw = w.sum()
        if not np.isfinite(sw) or sw <= 0:
            return -1e10
        ll += m + np.log(sw / npart) - 0.5 * np.log(2 * np.pi)
        w /= sw
        idx = rng.choice(npart, npart, p=w)
        h = h[idx]; z = z[idx]
    return float(ll)


def bic(r, par, npart=1500, seed=0):
    K = par['K']; n = len(r)
    p = K + 2 + K * (K - 1)
    ll = pf_ll(r, par, npart, seed)
    return -2 * ll + p * np.log(n), ll
