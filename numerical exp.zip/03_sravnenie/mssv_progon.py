"""MSSV на рядах Н: выбор K по BIC (частичный фильтр) + метрики разметки."""
import os, sys, os, pickle, time, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'sravnenie'))
import numpy as np
import obshee as O, mssv as MV

FN = os.environ.get('REZ_PATH','../rezultaty') + '/mssv_rez.pkl'
R = pickle.load(open(FN, 'rb')) if os.path.exists(FN) else {}
IT, BN = 1800, 800
IG, PP = (60.0, 1.0), (0.9, 0.25)

if __name__ == '__main__':
    for key in sys.argv[1:]:
        d = O.dannye(key); r = d['r']; si = O.sigma_ist(d)
        n = len(d['Y'])
        R.setdefault(key, {})
        for K in (1, 2, 3):
            if K in R[key]:
                continue
            t0 = time.time()
            f = MV.podgon(r, K, iters=IT, burn=BN, seed=3, ig=IG, phi_pr=PP)
            b, ll = MV.bic(r, f, npart=1200, seed=1)
            zt = O.tochki_iz_prirostov(f['z'], n)
            st = np.r_[f['sigma_t'][0], f['sigma_t']]
            acc, _, _ = O.sopostavit(zt, d['lab'], d['K'])
            R[key][K] = dict(bic=b, ll=ll, mu=f['mu'].tolist(), phi=f['phi'],
                             se=float(np.sqrt(f['se2'])), acc=acc,
                             ari=O.ari(zt, d['lab']), l2=O.l2_sigma(st, si))
            pickle.dump(R, open(FN, 'wb'))
            print('%s K=%d: BIC %.1f  метки %.3f ARI %.3f E_L2 %.3f  (%.0f с)'
                  % (key, K, b, acc, R[key][K]['ari'], R[key][K]['l2'], time.time() - t0), flush=True)
        b = {K: v['bic'] for K, v in R[key].items()}
        print('  -> %s: истина K=%d, MSSV выбирает %d' % (key, d['K'], min(b, key=b.get)), flush=True)
