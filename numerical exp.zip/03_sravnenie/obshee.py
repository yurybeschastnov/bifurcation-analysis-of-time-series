"""Общая часть: загрузка, истинные параметры, метрики."""
import numpy as np, os, sys
from scipy.optimize import linear_sum_assignment
import zagruzka as Z

ORD, BTC = Z.ORD, Z.BTC

def dannye(key):
    d = Z.gruz(key)
    Y, t = d['Y'], d['t']
    dt = float(np.median(np.diff(t)))
    d['dt'] = dt
    d['r'] = np.diff(Y) / np.sqrt(dt)      # нормированные приращения
    return d

def sigma_ist(d):
    """Истинная sigma в каждой точке ряда."""
    br, kind, W, lab = d['branches'], d['kind'], d['W'], d['lab']
    return np.array([Z.sigma(br[j], w, kind) for j, w in zip(lab, W)])

# ---------------------------------------------------------------- метрики
def sopostavit(pred, true, K):
    """Венгерское сопоставление предсказанных состояний истинным.
    Возвращает (точность, отображение). Kh может быть != K."""
    Kh = int(pred.max()) + 1
    C = np.zeros((Kh, K))
    for a in range(Kh):
        for b in range(K):
            C[a, b] = -np.sum((pred == a) & (true == b))
    ra, ca = linear_sum_assignment(C)
    m = {int(a): int(b) for a, b in zip(ra, ca)}
    # состояния без пары (Kh > K) отображаем в наиболее частый истинный
    for a in range(Kh):
        if a not in m:
            msk = pred == a
            m[a] = int(np.bincount(true[msk], minlength=K).argmax()) if msk.any() else 0
    pm = np.array([m[int(j)] for j in pred])
    return float(np.mean(pm == true)), m, pm

def ari(a, b):
    from sklearn.metrics import adjusted_rand_score
    return float(adjusted_rand_score(a, b))

def l2_sigma(sh, si):
    """Относительная L2-ошибка траектории волатильности."""
    return float(np.sqrt(np.sum((sh - si) ** 2) / np.sum(si ** 2)))

def tochki_iz_prirostov(z, n):
    """Метка приращения i (между i-1 и i) -> метка точки i; точка 0 = метка 1-го."""
    out = np.empty(n, int); out[1:] = z; out[0] = z[0]
    return out
