"""Оракульный тест MSSV: параметры строятся по ИСТИННЫМ меткам и истинной
волатильности, затем BIC оценивается частичным фильтром. Отчёт §6.4.
Кода этого теста в архиве нет — восстановлен по описанию."""
import numpy as np, pickle, os, sys, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0,'/home/claude/work/full2/03_sravnenie')
import obshee as O, mssv as MV

def orakul_par(r, si_r, lab, K):
    """si_r — истинная sigma на приращениях; lab — истинные метки приращений."""
    h = 2.0*np.log(si_r)
    mu = np.array([h[lab==k].mean() for k in range(K)])
    o = np.argsort(mu); mu = mu[o]; inv = np.argsort(o); z = inv[lab]
    x = h - mu[z]
    phi = float(x[:-1] @ x[1:] / max(x[:-1] @ x[:-1], 1e-12))
    phi = float(np.clip(phi, -0.999, 0.999))
    e = x[1:] - phi*x[:-1]; se2 = float(np.var(e))
    A = np.zeros((K,K)); np.add.at(A,(z[:-1],z[1:]),1.0)
    A += 1e-6; A /= A.sum(axis=1,keepdims=True)
    return dict(mu=mu, phi=phi, se2=se2, A=A, K=K), z

if __name__ == '__main__':
    MS = pickle.load(open(os.environ['REZ_PATH']+'/mssv_rez.pkl','rb'))
    OTCH = {'N1':6001.7,'N2':6508.1,'N3':7979.0,'N6':5936.3}
    print('%-4s %-3s %-9s %-9s %-22s %-9s %s'%('ряд','K','BIC K=1','BIC подг','BIC оракул (5 сидов)','в отчёте','вывод'))
    for key in ['N1','N2','N3','N6']:
        d = O.dannye(key); r = d['r']; K = d['K']
        si = O.sigma_ist(d); si_r = si[1:]; lab_r = d['lab'][1:]
        par, z = orakul_par(r, si_r, lab_r, K)
        bs = []
        for s in range(5):
            b, ll = MV.bic(r, par, npart=1200, seed=s)
            bs.append(b)
        b1 = MS[key][1]['bic']; bK = MS[key][K]['bic']
        m, sd = float(np.mean(bs)), float(np.std(bs))
        vyv = 'оракул бьёт K=1' if m < b1 else 'K=1 выигрывает'
        print('%-4s %-3d %-9.1f %-9.1f %-22s %-9.1f %s'%(
            key,K,b1,bK,'%.1f ± %.1f'%(m,sd),OTCH[key],vyv))
        print('     оракульные параметры: mu=%s phi=%.4f se=%.4f'%(
            np.round(par['mu'],3), par['phi'], np.sqrt(par['se2'])))
