"""Отбор участков биткойна в два прохода.

Первый проход дешёвый: по логарифму локальной волатильности одномерная
кластеризация (алгоритм Ллойда на отсортированных значениях). Он отсеивает
подавляющее большинство окон. Второй проход — марковская модель переключений
на выживших кандидатах, она и даёт окончательные признаки.
"""
import sys, pickle
import numpy as np
import zagruzka as Z
import msde as M
import markov as MK


def normirovat(Y0):
    Yc = np.asarray(Y0, float) - Y0[0]
    s = float(np.sqrt(np.sum(np.diff(Yc) ** 2)))
    Y = Yc / s
    n = len(Y)
    return Y, np.linspace(0.0, 1.0, n), 1.0 / (n - 1), s


def lloyd(x, K, n_iter=40, seed=0):
    """Одномерная кластеризация без sklearn: старт по квантилям."""
    c = np.quantile(x, np.linspace(0.5 / K, 1 - 0.5 / K, K))
    for _ in range(n_iter):
        lab = np.argmin(np.abs(x[:, None] - c[None, :]), axis=1)
        nc = np.array([x[lab == j].mean() if np.any(lab == j) else c[j] for j in range(K)])
        if np.allclose(nc, c, atol=1e-9):
            break
        c = nc
    lab = np.argmin(np.abs(x[:, None] - c[None, :]), axis=1)
    return c, lab


def probegi_max(z, K):
    gr = np.where(np.diff(np.r_[-1, z, -1]) != 0)[0]
    dl = {j: 0 for j in range(K)}
    for i in range(len(gr) - 1):
        j = int(z[gr[i]]); dl[j] = max(dl[j], int(gr[i + 1] - gr[i]))
    return dl


def sgladit(z, K, minlen=45):
    """Убираем куски короче minlen, приписывая их соседу слева."""
    z = z.copy()
    while True:
        gr = np.where(np.diff(np.r_[-1, z, -1]) != 0)[0]
        L = np.diff(gr)
        i = np.argmin(L)
        if L[i] >= minlen or len(L) <= K:
            break
        a, b = gr[i], gr[i + 1]
        z[a:b] = z[a - 1] if a > 0 else z[b]
    return z


def deshevo(Y, dt, K):
    """Дешёвый признак: кластеризация логарифма локальной волатильности."""
    lv = M.local_vol(Y, dt, 30)
    x = np.log(np.maximum(lv, 1e-8))
    c, lab = lloyd(x, K)
    o = np.argsort(c); rank = np.empty(K, int); rank[o] = np.arange(K)
    lab = rank[lab]; c = np.sort(c)
    lab = sgladit(lab, K)
    if len(np.unique(lab)) < K:
        return None
    sig = np.exp(c)
    razd = float(np.min(sig[1:] / sig[:-1]))
    dol = np.array([np.mean(lab == j) for j in range(K)])
    blok = int(min(probegi_max(lab, K).values()))
    perekl = int((np.diff(lab) != 0).sum())
    return dict(razd=razd, zan=float(dol.min()), blok=blok, perekl=perekl)


def hmm_priznaki(Y, dt, K, ntry=2, n_iter=80):
    r = np.diff(Y)
    best = None
    for s in range(ntry):
        try:
            out = MK.em(r, dt, K, n_iter=n_iter, seed=s)
        except Exception:
            continue
        if best is None or out[0] > best[0]:
            best = out
    if best is None:
        return None
    ll, mu, sig, A, g = best
    z = sgladit(np.argmax(g, axis=1), K)
    if len(np.unique(z)) < K:
        return None
    sig = np.sort(np.asarray(sig))
    if sig[0] <= 0:
        return None
    dol = np.array([np.mean(z == j) for j in range(K)])
    k = 2 * K + K * (K - 1) + (K - 1)
    return dict(razd=float(np.min(sig[1:] / sig[:-1])), zan=float(dol.min()),
                blok=int(min(probegi_max(z, K).values())),
                perekl=int((np.diff(z) != 0).sum()),
                sigma=sig, bic=float(-2 * ll + k * np.log(len(r))), z=z)


def ball(o, K):
    return (2.2 * np.log(o['razd']) + 1.0 * np.log(o['zan'] * K)
            + 0.55 * np.log(o['blok'] / 70.0) - 0.16 * max(0, o['perekl'] - 2 * K))


if __name__ == '__main__':
    # ------- проход 1
    gruby = []
    for key in ['btc', 'btcB', 'btcC']:
        Y0 = Z.gruz(key)['Y']
        for L in (760, 900, 1040):
            for i0 in range(0, len(Y0) - L, 40):
                Y, t, dt, s = normirovat(Y0[i0:i0 + L])
                for K in (2, 3, 4):
                    o = deshevo(Y, dt, K)
                    if o and o['razd'] >= 1.42 and o['zan'] >= 0.12 and o['blok'] >= 70 and o['perekl'] <= 18:
                        gruby.append((ball(o, K), key, i0, L, K))
        print('проход 1:', key, 'кандидатов', len(gruby), flush=True)
    gruby.sort(key=lambda z: -z[0])
    # оставляем разумное число лучших по каждому K
    otbor = []
    for K in (2, 3, 4):
        otbor += [g for g in gruby if g[4] == K][:110]
    print('на проход 2:', len(otbor), flush=True)

    # ------- проход 2
    KAND = []
    for n, (b0, key, i0, L, K) in enumerate(otbor):
        Y0 = Z.gruz(key)['Y']
        Y, t, dt, s = normirovat(Y0[i0:i0 + L])
        o = hmm_priznaki(Y, dt, K)
        if o is None:
            continue
        if o['razd'] >= 1.55 and o['zan'] >= 0.13 and o['blok'] >= 70 and K - 1 <= o['perekl'] <= 16:
            KAND.append(dict(key=key, i0=i0, L=L, K=K, ball=ball(o, K), **o))
        if (n + 1) % 40 == 0:
            print('  проход 2: %d/%d, отобрано %d' % (n + 1, len(otbor), len(KAND)), flush=True)
    KAND.sort(key=lambda z: -z['ball'])
    pickle.dump(KAND, open('kandidaty.pkl', 'wb'))
    print('\nвсего пригодных:', len(KAND))
    for K in (2, 3, 4):
        print('\n--- K = %d ---' % K)
        for z in [q for q in KAND if q['K'] == K][:14]:
            print('%-5s i0=%4d L=%4d балл=%5.2f разд=%.2f зан=%.2f блок=%4d перекл=%2d sigma=%s'
                  % (z['key'], z['i0'], z['L'], z['ball'], z['razd'], z['zan'],
                     z['blok'], z['perekl'], np.round(z['sigma'], 2)))
