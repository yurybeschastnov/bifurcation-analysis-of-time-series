"""Отдельный поиск участков с четырьмя режимами.

Для четырёх уровней требование «соседние отличаются в 1,55 раза» означает
разброс крайних уровней в 3,7 раза, что на биткойне встречается редко.
Порог соседнего разделения снижен, но добавлено требование на РАЗМАХ:
крайние уровни должны отличаться не менее чем втрое, иначе четыре режима
не видны глазом. Окна берутся длиннее: четырём режимам нужно место.
"""
import pickle
import numpy as np
import zagruzka as Z
from poisk2 import normirovat, deshevo, hmm_priznaki, ball

if __name__ == '__main__':
    gruby = []
    for key in ['btc', 'btcB', 'btcC']:
        Y0 = Z.gruz(key)['Y']
        for L in (1040, 1250, 1500, 1750):
            for i0 in range(0, len(Y0) - L, 40):
                Y, t, dt, s = normirovat(Y0[i0:i0 + L])
                o = deshevo(Y, dt, 4)
                if o and o['razd'] >= 1.20 and o['zan'] >= 0.10 and o['blok'] >= 55 and o['perekl'] <= 22:
                    gruby.append((ball(o, 4), key, i0, L))
        print('проход 1:', key, len(gruby), flush=True)
    gruby.sort(key=lambda z: -z[0])
    otbor = gruby[:220]
    print('на проход 2:', len(otbor), flush=True)

    KAND = []
    for n, (b0, key, i0, L) in enumerate(otbor):
        Y0 = Z.gruz(key)['Y']
        Y, t, dt, s = normirovat(Y0[i0:i0 + L])
        o = hmm_priznaki(Y, dt, 4)
        if o is None:
            continue
        razmah = float(o['sigma'][-1] / o['sigma'][0])
        if (o['razd'] >= 1.28 and razmah >= 3.0 and o['zan'] >= 0.10
                and o['blok'] >= 60 and o['perekl'] <= 20):
            KAND.append(dict(key=key, i0=i0, L=L, K=4, razmah=razmah, ball=ball(o, 4), **o))
        if (n + 1) % 40 == 0:
            print('  проход 2: %d/%d, отобрано %d' % (n + 1, len(otbor), len(KAND)), flush=True)
    KAND.sort(key=lambda z: -z['ball'])
    pickle.dump(KAND, open('kandidaty4.pkl', 'wb'))
    print('\nпригодных с K=4:', len(KAND))
    for z in KAND[:20]:
        print('%-5s i0=%4d L=%4d балл=%5.2f разд=%.2f размах=%.1f зан=%.2f блок=%4d перекл=%2d sigma=%s'
              % (z['key'], z['i0'], z['L'], z['ball'], z['razd'], z['razmah'], z['zan'],
                 z['blok'], z['perekl'], np.round(z['sigma'], 2)))
