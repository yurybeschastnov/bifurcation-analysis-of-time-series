"""Поиск участков биткойна с наглядной режимной структурой.

Отбор идёт по признакам, которые делают режимы видимыми ГЛАЗОМ на графике
логарифма цены, а не по одному лишь значению критерия:

  разделение   отношение соседних уровней волатильности не меньше порога;
  занятость    каждый режим занимает заметную долю участка;
  блочность    у каждого режима есть непрерывный кусок достаточной длины,
               иначе на глаз видно дрожание, а не режимы;
  умеренность  число переключений невелико, иначе картинка нечитаема.
"""
import numpy as np
import zagruzka as Z
import markov as MK


def normirovat(Y0):
    """Тот же перевод, что и во всём наборе: центр в начале, полная
    квадратичная вариация равна единице, время на отрезке [0, 1]."""
    Yc = Y0 - Y0[0]
    s = float(np.sqrt(np.sum(np.diff(Yc) ** 2)))
    Y = Yc / s
    n = len(Y)
    t = np.linspace(0.0, 1.0, n)
    return Y, t, 1.0 / (n - 1), s


def viterbi(r, mu, sd, A, pi):
    n, K = len(r), len(sd)
    lB = -0.5 * ((r[:, None] - mu[None, :]) / sd[None, :]) ** 2 - np.log(sd[None, :] * np.sqrt(2 * np.pi))
    lA = np.log(np.maximum(A, 1e-300))
    d = np.log(np.maximum(pi, 1e-300)) + lB[0]
    bk = np.zeros((n, K), int)
    for i in range(1, n):
        z = d[:, None] + lA
        bk[i] = np.argmax(z, axis=0)
        d = z[bk[i], np.arange(K)] + lB[i]
    z = np.empty(n, int); z[-1] = int(np.argmax(d))
    for i in range(n - 1, 0, -1):
        z[i - 1] = bk[i, z[i]]
    return z


def hmm_razmetka(Y, dt, K, ntry=4):
    r = np.diff(Y)
    best = MK.podobrat(r, dt, K, ntry=ntry)
    if best is None:
        return None
    ll, mu, sig, A, g = best
    z = np.argmax(g, axis=1)
    n = len(r)
    k = 2 * K + K * (K - 1) + (K - 1)
    return dict(ll=ll, sigma=np.asarray(sig), z=z, bic=-2 * ll + k * np.log(n))


def probegi(z):
    """Длины непрерывных кусков одной метки."""
    gr = np.where(np.diff(np.r_[-1, z, -1]) != 0)[0]
    return [(int(z[gr[i]]), int(gr[i + 1] - gr[i])) for i in range(len(gr) - 1)]


def ocenka(Y, dt, K):
    """Признаки наглядности участка при K режимах."""
    h = hmm_razmetka(Y, dt, K)
    if h is None:
        return None
    sig = np.sort(h['sigma'])
    if sig[0] <= 0:
        return None
    razd = float(np.min(sig[1:] / sig[:-1]))              # разделение уровней
    dol = np.array([np.mean(h['z'] == j) for j in range(K)])
    zan = float(dol.min())                                # занятость
    pr = probegi(h['z'])
    dlin = {j: 0 for j in range(K)}
    for j, L in pr:
        dlin[j] = max(dlin[j], L)
    blok = int(min(dlin.values()))                        # самый короткий «главный» кусок
    perekl = int((np.diff(h['z']) != 0).sum())
    return dict(razd=razd, zan=zan, blok=blok, perekl=perekl, sigma=sig,
                bic=h['bic'], z=h['z'])


def prigoden(o, K):
    if o is None:
        return False
    return (o['razd'] >= 1.55 and o['zan'] >= 0.13 and o['blok'] >= 70
            and K - 1 <= o['perekl'] <= 16)


def ball(o, K):
    """Чем больше, тем нагляднее. Разделение важнее всего, длинные блоки — следом."""
    return (2.2 * np.log(o['razd']) + 1.0 * np.log(o['zan'] / (1.0 / K))
            + 0.55 * np.log(o['blok'] / 70.0) - 0.16 * max(0, o['perekl'] - 2 * K))


if __name__ == '__main__':
    KAND = []
    for key in ['btc', 'btcB', 'btcC']:
        d = Z.gruz(key)
        Y0 = d['Y']
        for L in (760, 900, 1040):
            for i0 in range(0, len(Y0) - L, 80):
                seg = Y0[i0:i0 + L]
                Y, t, dt, s = normirovat(seg)
                for K in (2, 3, 4):
                    o = ocenka(Y, dt, K)
                    if prigoden(o, K):
                        KAND.append(dict(key=key, i0=i0, L=L, K=K, ball=ball(o, K), **o))
        print(key, 'просмотрено', flush=True)
    KAND.sort(key=lambda z: -z['ball'])
    print('\nвсего пригодных:', len(KAND))
    for K in (2, 3, 4):
        print('\n--- K = %d ---' % K)
        for z in [q for q in KAND if q['K'] == K][:12]:
            print('%-5s i0=%4d L=%4d  балл=%5.2f  разд=%.2f зан=%.2f блок=%4d перекл=%2d  sigma=%s'
                  % (z['key'], z['i0'], z['L'], z['ball'], z['razd'], z['zan'],
                     z['blok'], z['perekl'], np.round(z['sigma'], 2)))
    import pickle
    pickle.dump(KAND, open('kandidaty.pkl', 'wb'))
