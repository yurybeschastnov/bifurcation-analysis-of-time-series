import numpy as np, os
KAT = os.environ.get('RYADY_PATH', 'ryady')
LIN = {   # (c, a, b)
 'L1': [(0.0,0.1,0.9)],
 'L2': [(0.0,0.05,0.5),(0.3,-0.4,1.1)],
 'L3': [(0.0,0.05,0.4),(0.2,-0.35,0.8),(-0.16,-0.11,1.2)],
 'L4': [(0.0,0.05,0.7),(0.25,-0.3,0.95)],
 'L5': [(0.0,0.05,0.35),(0.18,-0.3,0.75),(-0.12,0.1,1.3)],
 'L6': [(0.0,0.05,0.3),(0.12,-0.2,0.65),(-0.1,0.15,1.05),(0.22,-0.35,1.55)],
}
CUB = {   # (c, a, b, r)
 'N1': [(0.0,0.05,0.5,0.2),(0.3,-0.25,1.1,0.02)],
 'N2': [(0.0,0.05,0.45,0.25),(0.22,-0.2,0.85,0.05),(-0.18,0.1,1.25,0.12)],
 'N3': [(0.0,0.05,0.35,0.45),(0.25,-0.2,1.15,0.03)],
 'N4': [(0.0,0.05,0.3,0.5),(0.2,-0.25,0.8,0.2),(-0.15,0.1,1.4,0.02)],
 'N5': [(0.0,0.05,0.3,0.55),(0.28,-0.25,0.95,0.15)],
 'N6': [(0.0,0.05,0.55,0.0),(0.3,-0.25,0.4,0.6)],
 'N7': [(0.0,0.05,0.35,0.0),(0.2,-0.22,0.8,0.0),(-0.15,0.12,0.6,0.55)],
}
FILE = {'L%d'%i: 'Л%d.txt'%i for i in range(1,7)}
FILE.update({'N%d'%i: 'Н%d.txt'%i for i in range(1,8)})
FILE.update({'btc':'btc.txt','btcB':'btcB.txt','btcC':'btcC.txt'})
ORD = ['L1','L2','L3','L4','L5','L6','N1','N2','N3','N4','N5','N6','N7']
BTC = ['btc','btcB','btcC']

def gruz(key):
    p = os.path.join(KAT, FILE[key])
    A = np.loadtxt(p, skiprows=1)
    d = dict(t=A[:,0], Y=A[:,1])
    if A.shape[1] > 2:
        d['W'] = A[:,2]; d['lab'] = A[:,3].astype(int)
        d['branches'] = LIN[key] if key in LIN else CUB[key]
        d['kind'] = 'aff' if key in LIN else 'cub'
        d['K'] = len(d['branches'])
    d['dt'] = float(np.median(np.diff(A[:,0])))
    return d

def gval(g, w, t, kind):
    if kind=='aff':
        c,a,b = g; return c + a*t + b*w
    c,a,b,r = g; return c + a*t + b*w + r*w**3

def sigma(g, w, kind):
    if kind=='aff':
        return np.abs(g[2]*np.ones_like(np.asarray(w,float)))
    return np.abs(g[2] + 3.0*g[3]*np.asarray(w,float)**2)
