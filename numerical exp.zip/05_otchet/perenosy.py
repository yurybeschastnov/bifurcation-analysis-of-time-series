"""Переносы для русских слов.

В этой установке TeX Live образцов переносов для русского языка нет: polyglossia
прямо сообщает «No hyphenation patterns were loaded for russian», а поставить их
неоткуда – сеть открыта только на pypi, github и npm. Без переносов длинные
термины («гетероскедастичность», «непараметрический») не помещаются в строку и
выезжают за поле; в журнале это Overfull \\hbox, а на странице – текст, вылезший
в поле.

Поэтому список исключений строится по самому тексту отчёта: все длинные русские
слова разбиваются на слоги простым правилом и выдаются как \\hyphenation{...}.
Список покрывает ровно те словоформы, которые в отчёте есть, а этого и
достаточно, поскольку переносы нужны только для встречающихся слов.

Правило разбиения:
  разрыв ставится после гласной;
  мягкий и твёрдый знаки и «й» никогда не начинают слог и уходят влево;
  из двух подряд идущих согласных первая уходит влево;
  с каждой стороны разрыва остаётся не меньше двух букв и хотя бы одна гласная.
"""
import re

GLAS = set('аеёиоуыэюя')
NEACH = set('ьъй')          # не могут начинать слог


def slogi(w):
    """Позиции допустимых разрывов внутри слова."""
    n = len(w)
    out = []
    for i, c in enumerate(w):
        if c not in GLAS:
            continue
        p = i + 1
        while p < n and w[p] in NEACH:
            p += 1
        if p + 1 < n and w[p] not in GLAS:
            if w[p + 1] in NEACH:
                p += 2                      # «…тиль-ность»: согласная с мягким знаком влево
            elif w[p + 1] not in GLAS:
                p += 1                      # «…стич-ность»: из двух согласных первая влево
        if p < 2 or n - p < 2:
            continue
        if not (set(w[:p]) & GLAS) or not (set(w[p:]) & GLAS):
            continue
        if out and p - out[-1] < 2:
            continue
        out.append(p)
    return out


def s_defisami(w):
    p = slogi(w)
    if not p:
        return None
    kus = []
    pred = 0
    for q in p:
        kus.append(w[pred:q]); pred = q
    kus.append(w[pred:])
    return '-'.join(kus)


def spisok(tekst, mini=10, maks_slov=4000):
    """\\hyphenation{...} по всем длинным русским словам текста."""
    slova = set()
    for w in re.findall(r'[А-Яа-яЁё]+', tekst):
        w = w.lower().replace('ё', 'е')
        if len(w) >= mini:
            slova.add(w)
    gotovo = []
    for w in sorted(slova):
        d = s_defisami(w)
        if d and '-' in d:
            gotovo.append(d)
        if len(gotovo) >= maks_slov:
            break
    if not gotovo:
        return ''
    # по 6 слов в строке, чтобы файл читался
    stroki = ['\\hyphenation{%']
    for i in range(0, len(gotovo), 6):
        stroki.append('  ' + ' '.join(gotovo[i:i + 6]) + '%')
    stroki.append('}')
    return '\n'.join(stroki)
