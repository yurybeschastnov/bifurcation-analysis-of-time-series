"""Проверка формы sigma_j(w) = |b_j + 3 r_j w^2| НЕПАРАМЕТРИЧЕСКИ.

Замысел. Прямая проверка «подставим восстановленный драйвер в формулу и
сравним с формулой» тавтологична: обе стороны считаются по одним и тем же
b_j, r_j. Поэтому волатильность оценивается способом, который о форме
b + 3 r w^2 ничего не знает: биннинг квадратов приращений (оценка коэффициента
диффузии в духе Флоренс-Змиру). Внутри режима j точки раскладываются по
значению драйвера, и в каждом бине

    sigma_бин = sqrt( среднее (dY)^2 / dt ).

Ни b_j, ни r_j в этой величине не участвуют.

Затем к полученным точкам подгоняются СОПЕРНИЧАЮЩИЕ формы:

  постоянная      sigma = b                   (то, что предполагают HMM и PELT)
  рычаг           sigma = b + c w             (волатильность растёт при падении;
                                               классический эффект рынка, НЕСИММЕТРИЧЕН)
  модель          sigma = b + beta w^2        (симметричная парабола: наша форма)
  полная          sigma = b + beta w^2 + c w  (вложенная, различает две предыдущие)

и сравниваются по BIC на бинах, взвешенных числом приращений.

Главная проверка – не то, что парабола подходит, а СОГЛАСОВАННОСТЬ:
beta должна равняться 3 r_j, где r_j взят из подгонки УРОВНЯ g_j и в оценку
sigma не входил вовсе. Отношение beta / (3 r_j), заметно отличное от единицы,
опровергает модель, даже если парабола легла хорошо.

Дополнительные предохранители:
  * точки у границ режима отбрасываются, иначе бин смешивает два режима;
  * половинная проверка: кривая строится отдельно по первой и второй половине
    времени внутри режима. Если U-образность есть свойство уровня, она
    воспроизводится в обеих; если это временной дрейф волатильности –
    не воспроизведётся;
  * разметка берётся и своя, и от гауссовой HMM, чтобы вывод не держался на
    разметке, полученной той же моделью.
"""
import os, sys, pickle
import numpy as np

import msde as M, pipeline as P, vetvi as V
import btc_kuski as BK


def sig_model(g, w, kind='cub'):
    r = g[3] if kind == 'cub' else 0.0
    return np.abs(g[2] + 3.0 * r * np.asarray(w) ** 2)


def otstup(z, m=6):
    """Маска точек, удалённых от смены режима не меньше чем на m отсчётов."""
    z = np.asarray(z)
    smena = np.zeros(len(z), bool)
    smena[1:] = z[1:] != z[:-1]
    idx = np.where(smena)[0]
    ok = np.ones(len(z), bool)
    for i in idx:
        ok[max(0, i - m):min(len(z), i + m)] = False
    ok[:m] = False; ok[-m:] = False
    return ok


def biny(w, prir, dt, nbin=8, minv=25):
    """Непараметрическая sigma по бинам драйвера. Формы не предполагает."""
    if len(w) < nbin * minv:
        nbin = max(3, len(w) // minv)
    if nbin < 3:
        return None
    kr = np.quantile(w, np.linspace(0, 1, nbin + 1))
    kr[0] -= 1e-9; kr[-1] += 1e-9
    out = []
    for i in range(nbin):
        m = (w >= kr[i]) & (w < kr[i + 1])
        if m.sum() < minv:
            continue
        kv = prir[m] ** 2 / dt
        s = float(np.sqrt(kv.mean()))
        # стандартная ошибка sigma: var(dY^2) даёт относительную ошибку
        # sigma^2 порядка sqrt(2/n), значит у sigma вдвое меньше
        se = s / np.sqrt(2.0 * m.sum())
        out.append((float(np.mean(w[m])), s, se, int(m.sum())))
    if len(out) < 3:
        return None
    a = np.array(out)
    return dict(w=a[:, 0], sig=a[:, 1], se=a[:, 2], n=a[:, 3].astype(int))


def podognat_formy(b):
    """Соперничающие формы на бинах, взвешенные обратной дисперсией."""
    w, s, se = b['w'], b['sig'], b['se']
    W = 1.0 / np.maximum(se, 1e-9) ** 2
    res = {}

    def mnk(X, imya):
        A = X * np.sqrt(W)[:, None]
        y = s * np.sqrt(W)
        koef, *_ = np.linalg.lstsq(A, y, rcond=None)
        pred = X @ koef
        hi2 = float(np.sum(W * (s - pred) ** 2))
        k = X.shape[1]
        res[imya] = dict(koef=koef, hi2=hi2, k=k,
                         bic=hi2 + k * np.log(len(s)),
                         r2=1 - np.sum(W * (s - pred) ** 2) / np.sum(W * (s - np.average(s, weights=W)) ** 2))
        return res[imya]

    e = np.ones_like(w)
    mnk(np.column_stack([e]), 'постоянная')
    mnk(np.column_stack([e, w]), 'рычаг')
    mnk(np.column_stack([e, w ** 2]), 'модель')
    mnk(np.column_stack([e, w ** 2, w]), 'полная')
    return res


def analiz_vetvi(Y, t, dt, W, z, keep, br, j, kind='cub', nbin=8, m_otstup=6):
    """Всё по одной ветви: бины, формы, согласованность beta и 3 r_j."""
    kk = np.asarray(keep, bool)
    Yk = np.asarray(Y)[kk]
    zj = np.asarray(z)
    ok = (zj == j) & otstup(zj, m_otstup)
    # приращения, у которых ОБА конца внутри режима и вдали от границы
    par = ok[:-1] & ok[1:]
    if par.sum() < 60:
        return None
    prir = np.diff(Yk)[par]
    wv = np.asarray(W)[:-1][par]
    b = biny(wv, prir, dt, nbin=nbin)
    if b is None:
        return None
    formy = podognat_formy(b)
    beta = formy['модель']['koef'][1]
    r_j = br[j][3] if kind == 'cub' else 0.0
    out = dict(biny=b, formy=formy, beta=float(beta), r_urovnya=float(r_j),
               beta_ozhid=float(3.0 * r_j), dolya=float(par.mean()),
               n_prir=int(par.sum()),
               pred_model=sig_model(br[j], b['w'], kind))
    out['otnoshenie'] = float(beta / (3.0 * r_j)) if abs(r_j) > 1e-6 else np.nan
    # половинная проверка
    idx = np.where(par)[0]
    sred = len(idx) // 2
    pol = []
    for chast in (idx[:sred], idx[sred:]):
        mm = np.zeros(len(par), bool); mm[chast] = True
        bb = biny(np.asarray(W)[:-1][mm], np.diff(Yk)[mm], dt, nbin=max(4, nbin // 2))
        if bb is None:
            pol.append(None); continue
        ff = podognat_formy(bb)
        pol.append(dict(biny=bb, beta=float(ff['модель']['koef'][1])))
    out['poloviny'] = pol
    return out


# --------------------------------------------------------------- неопределённость
def bootstrap_beta(w, prir, dt, nbin=8, B=400, seed=0):
    """Загрузочная выборка по приращениям: доверительный интервал для beta.

    Ресэмплируются сами приращения (внутри режима они по модели независимы),
    после чего вся процедура биннинга и подгонки повторяется целиком. Иначе
    интервал не учтёт случайность разбиения на бины.
    """
    rng = np.random.default_rng(seed)
    n = len(w)
    out = []
    for _ in range(B):
        idx = rng.integers(0, n, n)
        b = biny(w[idx], prir[idx], dt, nbin=nbin)
        if b is None:
            continue
        try:
            f = podognat_formy(b)
        except Exception:
            continue
        out.append(f['модель']['koef'][1])
    if len(out) < 50:
        return None
    a = np.sort(np.asarray(out))
    return dict(nizh=float(np.quantile(a, .025)), verh=float(np.quantile(a, .975)),
                sr=float(a.mean()), sd=float(a.std()))


def svodka_vetvi(Y, t, dt, W, z, keep, br, j, kind='cub', nbin=8, B=400, seed=0):
    """Полный разбор одной ветви вместе с доверительным интервалом."""
    a = analiz_vetvi(Y, t, dt, W, z, keep, br, j, kind, nbin=nbin)
    if a is None:
        return None
    kk = np.asarray(keep, bool)
    Yk = np.asarray(Y)[kk]
    zj = np.asarray(z)
    ok = (zj == j) & otstup(zj)
    par = ok[:-1] & ok[1:]
    bs = bootstrap_beta(np.asarray(W)[:-1][par], np.diff(Yk)[par], dt, nbin=nbin,
                        B=B, seed=seed)
    a['bootstrap'] = bs
    if bs and abs(a['beta_ozhid']) > 1e-9:
        # согласуется ли предсказание 3 r_j с непараметрической оценкой
        a['soglasie'] = bool(bs['nizh'] <= a['beta_ozhid'] <= bs['verh'])
    else:
        a['soglasie'] = None
    return a


# ------------------------------------------------- проверка по временным масштабам
def biny_masshtab(Y, W, z, keep, j, dt, k=1, nbin=8, minv=25, m_ots=6):
    """То же, но приращения берутся через k шагов (k*15 минут), без перекрытий.

    Нужна, чтобы отделить масштаб ИЗМЕРЕНИЯ волатильности от масштаба режима.
    Все k+1 точек приращения обязаны лежать внутри режима и вдали от границы,
    иначе приращение смешает два режима.
    """
    kk = np.asarray(keep, bool)
    Yk = np.asarray(Y)[kk]
    zz = np.asarray(z)
    ok = (zz == j) & otstup(zz, m_ots)
    n = len(Yk)
    st, sw, sp = [], [], []
    i = 0
    while i + k < n:
        if ok[i:i + k + 1].all():
            st.append(i); sw.append(W[i]); sp.append(Yk[i + k] - Yk[i])
            i += k                      # без перекрытий
        else:
            i += 1
    if len(st) < nbin * minv:
        nbin = max(3, len(st) // minv)
    if nbin < 3 or len(st) < 3 * minv:
        return None
    return biny(np.asarray(sw), np.asarray(sp), k * dt, nbin=nbin, minv=minv)


def masshtaby(Y, W, z, keep, br, j, dt, kind='cub', ks=(1, 2, 4), nbin=8):
    """beta на нескольких масштабах измерения волатильности."""
    r_j = br[j][3] if kind == 'cub' else 0.0
    out = {}
    for k in ks:
        b = biny_masshtab(Y, W, z, keep, j, dt, k=k, nbin=nbin)
        if b is None:
            out[k] = None; continue
        f = podognat_formy(b)
        be = f['модель']['koef'][1]
        out[k] = dict(beta=float(be), biny=b, formy=f,
                      otn=float(be / (3 * r_j)) if abs(r_j) > 1e-6 else np.nan,
                      luchshaya=min(f, key=lambda q: f[q]['bic']))
    return out
