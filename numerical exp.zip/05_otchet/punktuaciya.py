"""Приведение пунктуации отчётов к требуемому виду.

  1. Точка с запятой убирается. Слепая замена испортила бы грамматику, поэтому
     разбираются три случая:
       внутри скобок и в перечислении однородных членов -> запятая;
       в конце пункта списка                            -> точка;
       между самостоятельными предложениями             -> точка с прописной.
  2. Длинное тире (—) заменяется на короткое (–).
  3. Строки-разделители «---» удаляются.

  Разделители таблиц вида |---|---| и подобные НЕ трогаются: это разметка,
  а не пунктуация.
"""
import re, sys, os

TABL = re.compile(r'^\s*\|[\s:|-]+\|\s*$')
# Выключные формулы $$...$$ ищутся ПЕРВЫМИ и могут занимать несколько строк,
# поэтому текст обрабатывается целиком, а не построчно. Иначе внутри формулы
# менялась пунктуация: в f(X,w,t;\nu) точка с запятой отделяет аргументы от
# параметров, и замена её запятой меняет смысл записи.
MATEM = re.compile(r'\$\$.*?\$\$|\$[^$\n]*\$|\\\[.*?\\\]|`[^`]*`', re.S)


def _zashchitit(s):
    mat = []

    def spr(m):
        mat.append(m.group(0)); return '\x00%d\x00' % (len(mat) - 1)
    return MATEM.sub(spr, s), mat


def _vernut(s, mat):
    for i, m in enumerate(mat):
        s = s.replace('\x00%d\x00' % i, m)
    return s


def _bez_tochki_s_zapyatoj(s):
    if ';' not in s:
        return s

    # пункт списка, оканчивающийся точкой с запятой -> точка
    s = re.sub(r';\s*$', '.', s)

    # внутри скобок -> запятая
    def v_skobkah(m):
        return m.group(0).replace(';', ',')
    s = re.sub(r'\([^()]*\)', v_skobkah, s)

    # остальные: точка с прописной, если дальше начинается самостоятельное
    # предложение; запятая, если продолжается перечисление
    def razdelit(m):
        hvost = m.group(1)
        # перечисление узнаём по короткому продолжению без сказуемого
        korotko = len(hvost.split()) <= 4 and not hvost.rstrip().endswith('.')
        if korotko:
            return ', ' + hvost
        return '. ' + hvost[0].upper() + hvost[1:]
    s = re.sub(r';\s+(\S.*)$', razdelit, s)
    return s.replace(';', ',')


def obrabotat_tekst(s):
    """Формулы и код прячутся ДО построчного разбора и возвращаются после."""
    s, mat = _zashchitit(s)
    out = []
    for ln in s.split('\n'):
        if TABL.match(ln):
            out.append(ln); continue
        if ln.strip() == '---':
            continue                                   # строка-разделитель
        ln = _bez_tochki_s_zapyatoj(ln)
        ln = ln.replace('—', '–')
        out.append(ln)
    t = re.sub(r'\n{3,}', '\n\n', '\n'.join(out))
    return _vernut(t, mat)


def obrabotat_python(s):
    """Только СТРОКОВЫЕ ЛИТЕРАЛЫ, попадающие в отчёт: подписи и ячейки таблиц.

    Код не трогается: точка с запятой в Python осмысленна, а длинное тире
    встречается лишь в тексте подписей.
    """
    def zamena(m):
        telo = m.group(2)
        if '—' in telo:
            telo = telo.replace('—', '–')
        return m.group(1) + telo + m.group(3)
    return re.sub(r"(['\"])(.*?)(\1)", lambda m: m.group(0).replace('—', '–'), s)


if __name__ == '__main__':
    baza = os.path.dirname(os.path.abspath(__file__))
    itog = []
    for f in ['tekst_1.md', 'tekst_2.md', 'tekst_3.md', 'mini_forma.md']:
        p = os.path.join(baza, f)
        if not os.path.exists(p):
            continue
        s0 = open(p).read()
        if f == 'mini_forma.md':
            s0 = re.sub(r'(?s)^---\n.*?\n---\n', '', s0, count=1)   # заголовочный блок
        s1 = obrabotat_tekst(s0)
        open(p, 'w').write(s1)
        itog.append((f, s0.count(';') - s1.count(';'), s0.count('—') - s1.count('—')))
    for f in ['sborka.py', 'sborka_mini.py', 'tablicy.py', 'tablicy_btc.py',
              'tablicy_sravnenie.py', 'ris_dannye.py', 'ris_sravnenie.py',
              'ris_kalib.py', 'ris_btc.py', 'ris_forma.py', 'stil.py']:
        p = os.path.join(baza, f)
        if not os.path.exists(p):
            continue
        s0 = open(p).read()
        s1 = obrabotat_python(s0)
        if s1 != s0:
            open(p, 'w').write(s1)
            itog.append((f, 0, s0.count('—') - s1.count('—')))
    for f, tz, td in itog:
        print('  %-24s точек с запятой убрано %3d, тире заменено %3d' % (f, tz, td))
