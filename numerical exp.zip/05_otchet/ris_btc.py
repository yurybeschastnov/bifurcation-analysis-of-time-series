"""Рисунки по участкам биткойна.

  btc_obzor    все пять участков: логарифм цены и локальная волатильность
  btc_bic      выбор числа ветвей и класса ветви по BIC на каждом участке
  btc_XX       участок в подробностях: разметка, ветви, sigma_j(w), sigma_t

Истинных режимов на реальных данных нет, поэтому ни ARI, ни доли верных меток,
ни E_L2 здесь не существует ни для одного метода. Показано то, что определено:
на чём остановился критерий, как легла разметка и какая вышла волатильность.
Рядом даётся BIC + гауссова HMM – не как «истина», а как привычная точка
отсчёта: если два независимых подхода видят одно и то же, это довод в пользу
того, что структура есть в данных, а не в методе.
"""
import os, sys, pickle
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from stil import *
import msde as M, pipeline as P, vetvi as V
import markov as MK
import btc_kuski as BK

REZ = pickle.load(open(os.path.join(os.environ.get('BTC_REZ', '.'), 'btc_rez.pkl'), 'rb'))
KLASS = {'aff': 'аффинные', 'cub': 'кубические'}


def gval(g, t, w, kind):
    r = g[3] if kind == 'cub' else 0.0
    return g[0] + g[1] * t + g[2] * np.asarray(w) + r * np.asarray(w) ** 3


def sigv(g, w, kind):
    r = g[3] if kind == 'cub' else 0.0
    return np.abs(g[2] + 3.0 * r * np.asarray(w) ** 2)


def vybor(tag):
    """Выбор класса ветви и числа ветвей по BIC – правилом самого метода."""
    kand = {}
    for k in REZ:
        if not k.startswith('bic|' + tag + '|'):
            continue
        _, _, kind, N = k.split('|')
        if REZ[k]:
            kand[(kind, int(N))] = REZ[k]
    if not kand:
        return None
    luch = min(kand, key=lambda z: kand[z]['bic'])
    return dict(kind=luch[0], N=luch[1], bic=kand, tabl=kand[luch])


def podgonka(tag, kind, N):
    return REZ.get('%s|%s|%d' % (tag, kind, N))


def razmetka(tag):
    """Путь, метки и sigma по выбранной подгонке, развёрнутые на полную сетку."""
    v = vybor(tag)
    d = BK.kusok(tag)
    Y, t, dt = d['Y'], d['t'], d['dt']
    keep = P.censor_mask(Y, t, dt); bref = M.local_vol(Y, dt, 40)
    fit = podgonka(tag, v['kind'], v['N'])
    br, kind = fit['branches'], v['kind']
    kap = v['tabl']['kappa']
    ll, W, pv, dol = V.put(Y, t, dt, br, kind, keep, bref, kappa=kap, po_vetvi=True)
    lm, gam = V.put_summa(Y, t, dt, br, kind, keep, bref, kappa=kap)
    z_keep = np.argmax(gam, axis=1) if gam is not None else np.asarray(pv)
    s_keep = np.array([sigv(br[j], w, kind) for j, w in zip(z_keep, W)])
    # перенумеруем ветви по возрастанию медианной sigma: так цвета на всех
    # участках означают одно и то же – от спокойного режима к бурному
    med = [np.median(s_keep[z_keep == j]) if np.any(z_keep == j) else np.inf
           for j in range(len(br))]
    por = np.argsort(med)
    novyj = np.empty(len(br), int); novyj[por] = np.arange(len(br))
    z_keep = novyj[z_keep]
    br = [br[j] for j in por]
    kk = np.asarray(keep, bool)
    idx = np.where(kk)[0]
    n = len(Y)
    poz = np.clip(np.searchsorted(idx, np.arange(n)), 0, len(idx) - 1)
    poz2 = np.clip(poz - 1, 0, len(idx) - 1)
    bl = np.where(np.abs(idx[poz] - np.arange(n)) <= np.abs(idx[poz2] - np.arange(n)),
                  poz, poz2)
    return dict(z=z_keep[bl], sigma=s_keep[bl], W=W, keep=kk, branches=br,
                kind=kind, N=v['N'], d=d, kappa=kap,
                perekl=int((np.diff(z_keep) != 0).sum()))


def hmm_etalon(tag, Kmax=6):
    """BIC + гауссова HMM как привычная точка отсчёта."""
    d = BK.kusok(tag)
    r = np.diff(d['Y'])
    out = {}
    for K in range(1, Kmax + 1):
        res = MK.podobrat(r, d['dt'], K, ntry=3)
        if res is None:
            continue
        k = 2 * K + K * (K - 1) + (K - 1)
        out[K] = dict(bic=-2 * res[0] + k * np.log(len(r)),
                      sigma=np.asarray(res[2]), g=res[4])
    Kb = min(out, key=lambda q: out[q]['bic'])
    g = out[Kb]['g']
    z = np.argmax(g, axis=1)
    zt = np.r_[z[0], z]
    sg = np.asarray(out[Kb]['sigma'])
    return dict(K=Kb, z=zt, sigma=sg[np.clip(zt, 0, len(sg) - 1)], krivaya=out)


# --------------------------------------------------------------------------
def ris_obzor():
    """Все пять участков разом: сам ряд и локальная волатильность."""
    fig, axs = plt.subplots(5, 2, figsize=(7.4, 8.6),
                            gridspec_kw=dict(width_ratios=[1.6, 1], hspace=.75, wspace=.24))
    for i, q in enumerate(BK.KUSKI):
        d = BK.kusok(q['tag'])
        Y, t, dt = d['Y'], d['t'], d['dt']
        lv = M.local_vol(Y, dt, 30)
        ax = axs[i, 0]
        ax.plot(t, Y, color='k', lw=.5)
        ax.set_ylabel('$Y_t$', fontsize=8)
        ax.set_title('%s – %s, $n=%d$: %s' % (q['tag'], q['ryad'], d['n'], q['opis']),
                     fontsize=8)
        ax.tick_params(labelsize=7)
        ax = axs[i, 1]
        ax.plot(t, lv, color=PAL[1], lw=.6)
        ax.set_ylabel('лок. $\\sigma$', fontsize=8)
        ax.set_title('видно режимов: %d' % q['vid'], fontsize=8)
        ax.tick_params(labelsize=7)
        for a in axs[i]:
            a.set_xlabel('$t$', fontsize=8)
    fig.suptitle('Пять участков логарифма цены биткойна\n'
                 'слева – сам ряд, справа – локальная волатильность (окно 30)',
                 fontsize=9.5, y=.998)
    fig.tight_layout(rect=(0, 0, 1, .945))
    return sohr(fig, 'btc_obzor')


def RB_vse(tag):
    """Все степени, которые вообще рассматривались, включая недопустимые."""
    out = set()
    for k in REZ:
        if k.startswith('bic|' + tag + '|'):
            out.add((k.split('|')[2], int(k.split('|')[3])))
    return out


def ris_bic():
    """Выбор числа и класса ветвей на каждом участке."""
    fig, axs = plt.subplots(1, 5, figsize=(7.4, 3.3))
    for ax, q in zip(axs, BK.KUSKI):
        tag = q['tag']
        v = vybor(tag)
        b = v['bic']
        Ns = sorted({N for _, N in RB_vse(tag)})
        mn = min(x['bic'] for x in b.values())
        w = .38
        for i, kind in enumerate(('aff', 'cub')):
            val_ = [b[(kind, N)]['bic'] - mn if (kind, N) in b else np.nan for N in Ns]
            ax.bar(np.array(Ns) + (i - .5) * w, val_, w,
                   color=(SER if kind == v['kind'] else '#bdbdbd'),
                   alpha=1.0 if kind == v['kind'] else .8,
                   label=KLASS[kind])
        ax.axvline(v['N'], color='#c62828', lw=.8, ls='--', alpha=.8)
        # если какая-то степень недопустима по связям модели, это надо показать,
        # иначе пропуск столбца читается как несчитанный случай
        ned = [N for N in Ns if all((k, N) not in b for k in ('aff', 'cub'))]
        for N in ned:
            ax.text(N, ax.get_ylim()[1] * .5, 'модель\nнедопустима',
                    ha='center', va='center', fontsize=6, color='#c62828', rotation=90)
        ax.set_title('%s: выбрано\n$N=%d$, %s' % (tag, v['N'], KLASS[v['kind']]), fontsize=7.4)
        ax.set_xticks(Ns); ax.tick_params(labelsize=6.5)
        ax.locator_params(axis='y', nbins=4)
        ax.set_xlabel('$N$', fontsize=8)
        if ax is axs[0]:
            ax.set_ylabel('$\\Delta$BIC', fontsize=8)
            ruch = ax.get_legend_handles_labels()
    # Полосы сверху вниз: общий заголовок, легенда, заголовки панелей, оси.
    # Положение задаётся subplots_adjust, а не tight_layout: последний не знает
    # о фигурных артистах (suptitle и fig.legend) и укладывал их поверх подписей.
    fig.subplots_adjust(left=.075, right=.99, top=.70, bottom=.135, wspace=.52)
    fig.legend(*ruch, loc='lower center', bbox_to_anchor=(.5, .855), ncol=2,
               fontsize=7.2, frameon=False, columnspacing=2.0, handlelength=1.4)
    fig.suptitle('Выбор числа ветвей $N$ и класса ветви по BIC на точном '
                 'маргинальном правдоподобии', fontsize=9, y=.985)
    return sohr(fig, 'btc_bic')


def ris_uchastok(tag):
    """Участок в подробностях."""
    rz = razmetka(tag)
    d = rz['d']; Y, t, dt = d['Y'], d['t'], d['dt']
    br, kind, K = rz['branches'], rz['kind'], rz['N']
    z = rz['z']
    et = hmm_etalon(tag)

    fig = plt.figure(figsize=(7.4, 6.9))
    gs = fig.add_gridspec(4, 3, height_ratios=[1.55, 1.35, 1.15, 1.15],
                          hspace=.85, wspace=.32)

    # --- ряд с восстановленной разметкой
    ax = fig.add_subplot(gs[0, :])
    for j in range(K):
        m = z == j
        gr = np.where(np.diff(np.r_[0, m.astype(int), 0]) != 0)[0].reshape(-1, 2)
        for a0, a1 in gr:
            ax.axvspan(t[a0], t[min(a1, len(t) - 1)], color=PAL[j % len(PAL)],
                       alpha=.16, lw=0)
    ax.plot(t, Y, color='k', lw=.55)
    ax.set_ylabel('$Y_t$'); ax.set_xlabel('$t$')
    ax.set_title('%s (%s, точки %d…%d): разметка предложенным методом, '
                 '$N=%d$, %s ветви, переключений %d'
                 % (tag, d['ryad'], d['i0'], d['i0'] + d['L'], K,
                    KLASS[kind], rz['perekl']), fontsize=8)
    zk0 = rz['z'][rz['keep']]
    ruch = []
    for j in range(K):
        wj = rz['W'][zk0 == j]
        sj = sigv(br[j], wj, kind) if len(wj) else np.array([0.0])
        ruch.append(Patch(facecolor=PAL[j % len(PAL)], alpha=.32,
                          label='$g_{%d}$: $\\sigma$ %.2f…%.2f (медиана %.2f), '
                                'занятость %.2f'
                                % (j + 1, sj.min(), sj.max(), np.median(sj),
                                   float(np.mean(zk0 == j)))))
    ax.legend(handles=ruch, loc='upper left', bbox_to_anchor=(1.005, 1.0), fontsize=6.4)

    # --- волатильность: метод против эталона
    ax = fig.add_subplot(gs[1, :])
    ax.plot(t, rz['sigma'], color=SER, lw=.9, label='предложенный метод')
    ax.plot(t, et['sigma'], color=PAL[0], lw=.8, alpha=.85,
            label='BIC + гауссова HMM ($\\hat K=%d$)' % et['K'])
    ax.plot(t, M.local_vol(Y, dt, 30), color='#9e9e9e', lw=.6, alpha=.8,
            label='локальная RV (окно 30)')
    ax.set_ylabel('$\\sigma_t$'); ax.set_xlabel('$t$')
    ax.set_title('восстановленная волатильность', fontsize=8)
    ax.legend(loc='upper left', bbox_to_anchor=(1.005, 1.0), fontsize=6.8)

    # --- ветви и профили sigma
    W = rz['W']
    wg = np.linspace(W.min() - .12, W.max() + .12, 300)
    tk = np.asarray(t)[rz['keep']]
    for c, tt in enumerate([0.20, 0.50, 0.80]):
        ax = fig.add_subplot(gs[2, c])
        i0 = int(tt * (len(tk) - 1))
        for j in range(K):
            ax.plot(wg, gval(br[j], tk[i0], wg, kind), color=PAL[j % len(PAL)], lw=1.0)
        sl = slice(max(0, i0 - 110), min(len(tk), i0 + 110))
        ax.plot(W[sl], np.asarray(Y)[rz['keep']][sl], color='k', lw=1.4, alpha=.55)
        ax.set_xlabel('$w$', fontsize=8); ax.tick_params(labelsize=6.5)
        ax.locator_params(axis='both', nbins=4)
        if c == 0:
            ax.set_ylabel('$g_j(w,t)$', fontsize=8)
        # подпись момента времени НАД осями, а не внутри
        ax.text(.5, 1.03, '$t=%.2f$' % tt, transform=ax.transAxes,
                ha='center', va='bottom', fontsize=7)
    # Профили sigma рисуются ТОЛЬКО на области, которую ветвь реально посещает.
    # На полной сетке кубическая ветвь уходит вверх на порядок, и панель
    # заполняется значениями, которых в данных нет: масштаб задавала экстраполяция.
    zk = rz['z'][rz['keep']]
    for c, tt in enumerate([0.20, 0.50, 0.80]):
        ax = fig.add_subplot(gs[3, c])
        vsp = []
        for j in range(K):
            wj = W[zk == j]
            if len(wj) < 5:
                continue
            gj = np.linspace(wj.min(), wj.max(), 200)
            sj = sigv(br[j], gj, kind)
            ax.plot(gj, sj, color=PAL[j % len(PAL)], lw=1.2)
            vsp.append(sj)
        if vsp:
            ax.set_ylim(0, max(x.max() for x in vsp) * 1.08)
        ax.set_xlabel('$w$', fontsize=8); ax.tick_params(labelsize=6.5)
        ax.locator_params(axis='both', nbins=4)
        if c == 0:
            ax.set_ylabel('$\\sigma_j(w)$', fontsize=8)
        ax.text(.5, 1.03, '$t=%.2f$' % tt, transform=ax.transAxes,
                ha='center', va='bottom', fontsize=7)
    return sohr(fig, 'btc_' + {'Б1': 'B1', 'Б2': 'B2', 'Б3': 'B3',
                               'Б4': 'B4', 'Б5': 'B5'}[tag])


def svodka():
    """Текстовая сводка: что выбрал метод и что выбрал эталон."""
    stroki = []
    for q in BK.KUSKI:
        tag = q['tag']
        v = vybor(tag)
        rz = razmetka(tag)
        et = hmm_etalon(tag)
        sig = sorted(np.median(rz['sigma'][rz['z'] == j])
                     for j in range(rz['N']) if np.any(rz['z'] == j))
        rr = ([g[3] for g in rz['branches']] if v['kind'] == 'cub' else [])
        zan = sorted(np.mean(rz['z'] == j) for j in range(rz['N']))
        stroki.append(dict(tag=tag, ryad=q['ryad'], i0=q['i0'], L=q['L'], vid=q['vid'],
                           N=v['N'], kind=v['kind'], K_hmm=et['K'],
                           perekl=rz['perekl'], sigma=sig, kappa=rz['kappa'],
                           r=sorted(rr), zan=zan, opis=q['opis']))
    return stroki


if __name__ == '__main__':
    zad = sys.argv[1:] if len(sys.argv) > 1 else ['obzor', 'bic'] + BK.TAGI
    for z in zad:
        if z == 'obzor':
            ris_obzor()
        elif z == 'bic':
            ris_bic()
        elif z == 'svodka':
            import json
            s = svodka()
            for r in s:
                print('%-3s %-5s N=%d %-10s HMM K=%d перекл=%2d sigma=%s'
                      % (r['tag'], r['ryad'], r['N'], KLASS[r['kind']], r['K_hmm'],
                         r['perekl'], np.round(r['sigma'], 3)))
            pickle.dump(s, open(os.path.join(os.environ.get('BTC_REZ', '.'),
                                             'btc_svodka.pkl'), 'wb'))
        elif z in BK.TAGI:
            ris_uchastok(z)
