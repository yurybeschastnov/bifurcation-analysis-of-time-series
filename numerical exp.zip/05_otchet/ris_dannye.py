"""Рисунки группы А: данные и восстановление.

  ryad_XX     траектория с истинными и восстановленными режимами + ветви + sigma
  sigma_traj  восстановление траектории волатильности, предложенный метод vs эталоны
  drayver     восстановленный драйвер против истинного
"""
import os, sys, os, pickle
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'otchet'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'sravnenie'))
sys.path.insert(0, os.environ.get('MSDE_PATH', '.'))
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from stil import *
import obshee as O
import avtor as A


def gval(g, t, w, kind):
    r = g[3] if kind == 'cub' else 0.0
    return g[0] + g[1] * t + g[2] * w + r * np.asarray(w) ** 3


def sigv(g, w, kind):
    r = g[3] if kind == 'cub' else 0.0
    return np.abs(g[2] + 3.0 * r * np.asarray(w) ** 2)


def ris_ryad(key):
    """Траектория, ветви в три момента времени, профиль волатильности."""
    d = O.dannye(key)
    Y, t, W, lab = d['Y'], d['t'], d['W'], d['lab']
    br, kind, K = d['branches'], d['kind'], d['K']
    rz = A.razmetka(key)
    _, _, zh = O.sopostavit(rz['z'], lab, K)   # перестановка меток под истинные

    fig = plt.figure(figsize=(7.4, 6.6))
    gs = fig.add_gridspec(4, 3, height_ratios=[1.5, 1.5, 1.2, 1.2], hspace=.62, wspace=.30)

    # --- траектория с истинными режимами
    ax = fig.add_subplot(gs[0, :])
    for j in range(K):
        m = lab == j
        gr = np.where(np.diff(np.r_[0, m.astype(int), 0]) != 0)[0].reshape(-1, 2)
        for a0, a1 in gr:
            ax.axvspan(t[a0], t[min(a1, len(t) - 1)], color=PAL[j % len(PAL)], alpha=.16, lw=0)
    ax.plot(t, Y, color='k', lw=.55)
    ax.set_ylabel('$Y_t$'); ax.set_xlabel('$t$')
    ax.set_title('ряд %s: истинные режимы' % RUS[key], fontsize=9)
    ax.legend(handles=[Patch(facecolor=PAL[j % len(PAL)], alpha=.32,
                             label='$g_{%d}$: $\\sigma\\in[%.2f,\\,%.2f]$'
                                   % (j + 1, sigv(br[j], W[lab == j], kind).min(),
                                      sigv(br[j], W[lab == j], kind).max()))
                       for j in range(K)],
              loc='upper left', bbox_to_anchor=(1.005, 1.0), fontsize=7)

    # --- траектория с восстановленными режимами
    ax = fig.add_subplot(gs[1, :])
    for j in range(int(zh.max()) + 1):
        m = zh == j
        gr = np.where(np.diff(np.r_[0, m.astype(int), 0]) != 0)[0].reshape(-1, 2)
        for a0, a1 in gr:
            ax.axvspan(t[a0], t[min(a1, len(t) - 1)], color=PAL[j % len(PAL)], alpha=.16, lw=0)
    ax.plot(t, Y, color='k', lw=.55)
    osh = np.where(zh != lab)[0]
    if len(osh):
        ax.plot(t[osh], Y[osh], '.', ms=1.6, color='#c62828')
    ax.set_ylabel('$Y_t$'); ax.set_xlabel('$t$')
    ax.set_title('восстановлено предложенным методом: доля верных меток %.3f, ARI %.3f'
                 % (AV[key]['acc'], AV[key]['ari']), fontsize=9)

    # --- ветви в три момента
    wg = np.linspace(W.min() - .12, W.max() + .12, 300)
    for c, tt in enumerate([0.20, 0.50, 0.80]):
        ax = fig.add_subplot(gs[2, c])
        i0 = int(tt * (len(t) - 1))
        for j in range(K):
            ax.plot(wg, gval(br[j], t[i0], wg, kind), color=PAL[j % len(PAL)], lw=1.1)
        sl = slice(max(0, i0 - 110), min(len(t), i0 + 110))
        ax.plot(W[sl], Y[sl], color='k', lw=1.6, alpha=.55)
        ax.set_xlabel('$w$')
        if c == 0:
            ax.set_ylabel('$g_j(w,t)$')
        # подпись момента времени НАД осями: внутри них она ложилась на кривые
        ax.text(.5, 1.03, '$t=%.2f$' % tt, transform=ax.transAxes,
                ha='center', va='bottom', fontsize=7.5)

    # --- профиль волатильности
    for c, tt in enumerate([0.20, 0.50, 0.80]):
        ax = fig.add_subplot(gs[3, c])
        for j in range(K):
            ax.plot(wg, sigv(br[j], wg, kind), color=PAL[j % len(PAL)], lw=1.1)
        ax.set_xlabel('$w$')
        if c == 0:
            ax.set_ylabel('$\\sigma_j(w)$')
        # подпись момента времени НАД осями: внутри них она ложилась на кривые
        ax.text(.5, 1.03, '$t=%.2f$' % tt, transform=ax.transAxes,
                ha='center', va='bottom', fontsize=7.5)
    return sohr(fig, 'ryad_' + key)


def ris_sigma_traj():
    """Восстановление траектории волатильности на четырёх показательных рядах.

    Легенда общая и вынесена под заголовок: в прежнем варианте она стояла
    внутри осей и на Н6 закрывала главный пик волатильности, а на Н3 её текст
    перечёркивался кривыми. Значения E_L2 переехали из легенды в подпись
    панели, поэтому легенда короткая и одна на весь рисунок.
    """
    pok = ['L6', 'N1', 'N3', 'N6']
    fig, axs = plt.subplots(2, 2, figsize=(7.4, 5.4))
    ruch = None
    for ax, key in zip(axs.ravel(), pok):
        d = O.dannye(key); si = O.sigma_ist(d); t = d['t']
        rz = A.razmetka(key)
        ax.plot(t, si, color='k', lw=1.0, label='истинная', zorder=5)
        ax.plot(t, rz['sigma'], color=SER, lw=.9, alpha=.9, label='предложенный метод')
        import metody as MT, metody2 as M2
        H = MT.hmm(d['r'], Kmax=6, restarts=8)
        Kb = min(H, key=lambda q: H[q]['bic'])
        zt = O.tochki_iz_prirostov(H[Kb]['z'], len(d['Y']))
        sg = np.asarray(H[Kb]['sigma'], float)
        st = sg[np.clip(zt, 0, len(sg) - 1)]
        ax.plot(t, st, color=PAL[0], lw=.8, alpha=.85, label='BIC + гауссова HMM')
        rv = M2.lok_rv(d['Y'], d['dt'], 20)
        ax.plot(t, rv, color='#9e9e9e', lw=.7, alpha=.8, label='локальная RV')
        # метрики уходят в заголовок панели: в легенде они делали её вчетверо
        # длиннее. Заголовок в две строки – в одну строку соседние панели
        # смыкались подписями («…(RV)ряд Н1:»)
        ax.set_title('ряд %s\n$E_{L2}$: %.3f  /  %.3f (HMM, $\\hat K$=%d)  /  %.3f (RV)'
                     % (RUS[key], AV[key]['l2'], O.l2_sigma(st, si), Kb,
                        O.l2_sigma(rv, si)), fontsize=7.6)
        ax.set_xlabel('$t$'); ax.set_ylabel('$\\sigma_t$')
        if ruch is None:
            ruch = ax.get_legend_handles_labels()
        # запас сверху, чтобы кривые не подходили к заголовку вплотную
        y0, y1 = ax.get_ylim()
        ax.set_ylim(y0, y1 + .10 * (y1 - y0))
    fig.legend(*ruch, loc='upper center', bbox_to_anchor=(.5, .995), ncol=4,
               fontsize=7.2, frameon=False, columnspacing=1.6, handlelength=1.6)
    fig.tight_layout(rect=(0, 0, 1, .945), h_pad=2.0)
    return sohr(fig, 'sigma_traj')


def kalibrovka_drayvera(W_ist, W_oc):
    """Аффинная замена, связывающая восстановленный драйвер с истинным.

    Драйвер опознаётся лишь с точностью до аффинной замены. Пусть
    w' = alpha*w + beta. Положим в ветви c'_j = c_j - beta*b_j/alpha и
    b'_j = b_j/alpha; тогда

        g'_j(w', t) = c'_j + a_j t + b'_j w' = c_j + a_j t + b_j w = g_j(w, t),

    то есть наблюдаемый ряд Y_t не меняется ВООБЩЕ. Значит никакой критерий,
    построенный по Y, различить (w, g) и (w', g') не может: это не погрешность
    оценивания, а точная ненаблюдаемость.

    Волатильность при этом наблюдаема: sigma'_j(w') = b'_j = b_j/alpha, а
    приращение самого драйвера растянуто в alpha раз, поэтому в наблюдаемом
    ряде множители сокращаются. Именно поэтому E_L2 мал даже там, где облако
    (W, hat W) далеко от диагонали.

    Для кубических ветвей член r_j w^3 сокращается только при alpha = 1,
    beta = 0, поэтому там произвол снят самой моделью и калибровка выходит
    близкой к тождественной – что и видно на рядах Н.
    """
    A = np.column_stack([np.asarray(W_ist, float), np.ones(len(W_ist))])
    sol, *_ = np.linalg.lstsq(A, np.asarray(W_oc, float), rcond=None)
    return float(sol[0]), float(sol[1])          # alpha, beta


def ris_drayver():
    """Качество восстановления драйвера с учётом аффинной неопределённости.

    Прежняя версия рисовала только облако (W, hat W) и диагональ y = x. На
    ряде Л2 облако лежит на прямой с alpha ~ 0,8 и beta ~ 1,5 и потому далеко
    от диагонали, из-за чего рисунок читался как провал метода, хотя это
    ненаблюдаемая величина. Теперь в каждой паре панелей:

      слева   как есть, с ПОДОГНАННОЙ прямой и выписанными alpha, beta;
              диагональ показана бледной для сопоставления масштабов;
      справа  после снятия произвола, (hat W - beta)/alpha против W,
              с диагональю как честной линией отсчёта.
    """
    pok = ['L2', 'N1', 'N3', 'N5']
    fig, axs = plt.subplots(2, 4, figsize=(7.4, 4.3),
                            gridspec_kw=dict(wspace=.42, hspace=.55))
    for c, key in enumerate(pok):
        d = O.dannye(key)
        rz = A.razmetka(key)
        kk = rz['keep']
        Wi = np.asarray(d['W'])[kk]; Wo = np.asarray(rz['W'])
        al, be = kalibrovka_drayvera(Wi, Wo)
        r2 = np.corrcoef(Wi, Wo)[0, 1] ** 2

        ax = axs[0, c]
        ax.plot(Wi, Wo, '.', ms=.7, color=SER, alpha=.55, zorder=2)
        lo = min(Wi.min(), Wo.min()); hi = max(Wi.max(), Wo.max())
        gg = np.array([lo, hi])
        ax.plot(gg, gg, color='#bdbdbd', lw=.8, ls=':', zorder=1, label='$y=x$')
        ax.plot(gg, al * gg + be, color='#c62828', lw=.9, ls='--', zorder=3,
                label='подогнанная $\\hat\\alpha w+\\hat\\beta$')
        ax.set_title('%s, $R^2=%.4f$' % (RUS[key], r2), fontsize=8)
        # параметры калибровки – внутрь осей, в свободный угол: в заголовке
        # они делали строку такой длины, что соседние заголовки смыкались
        ax.text(.04, .96, '$\\hat\\alpha=%.2f$\n$\\hat\\beta=%+.2f$' % (al, be),
                transform=ax.transAxes, ha='left', va='top', fontsize=6.6,
                color='#c62828',
                bbox=dict(boxstyle='round,pad=.22', fc='white', ec='none', alpha=.75))
        ax.set_xlabel('$W_t$ истинный', fontsize=7.5)
        ax.tick_params(labelsize=6.5)
        ax.locator_params(axis='both', nbins=4)
        if c == 0:
            ax.set_ylabel('$\\hat W_t$ как есть', fontsize=7.5)
        if c == 0:
            ruch = ax.get_legend_handles_labels()

        ax = axs[1, c]
        Wn = (Wo - be) / al
        ax.plot(Wi, Wn, '.', ms=.7, color=SER, alpha=.55, zorder=2)
        lo = min(Wi.min(), Wn.min()); hi = max(Wi.max(), Wn.max())
        ax.plot([lo, hi], [lo, hi], color='#c62828', lw=.9, ls='--', zorder=3)
        osh = float(np.sqrt(np.mean((Wn - Wi) ** 2)) / np.std(Wi))
        ax.set_title('после снятия произвола', fontsize=8)
        ax.text(.04, .96, 'ср.кв. %.3f\nот $\\sigma_W$' % osh,
                transform=ax.transAxes, ha='left', va='top', fontsize=6.6,
                color='#c62828',
                bbox=dict(boxstyle='round,pad=.22', fc='white', ec='none', alpha=.75))
        ax.set_xlabel('$W_t$ истинный', fontsize=7.5)
        ax.tick_params(labelsize=6.5)
        ax.locator_params(axis='both', nbins=4)
        if c == 0:
            ax.set_ylabel('$(\\hat W_t-\\hat\\beta)/\\hat\\alpha$', fontsize=7.5)
    fig.legend(*ruch, loc='upper center', bbox_to_anchor=(.5, .995), ncol=2,
               fontsize=7.2, frameon=False, columnspacing=2.0, handlelength=2.0)
    fig.tight_layout(rect=(0, 0, 1, .935), w_pad=1.4, h_pad=1.2)
    return sohr(fig, 'drayver')


if __name__ == '__main__':
    zad = sys.argv[1:] if len(sys.argv) > 1 else ORD
    # «--zanovo» пересобирает даже готовые файлы. Без этого правки стиля
    # и подписей молча не доходили до рисунков приложения А: защита est()
    # пропускала генерацию, если файл уже лежал на месте.
    zanovo = '--zanovo' in zad
    zad = [z for z in zad if z != '--zanovo']
    for key in zad:
        if key in ORD:
            if zanovo or not est('ryad_' + key):
                ris_ryad(key)
        elif key == 'sigma':
            ris_sigma_traj()
        elif key == 'drayver':
            ris_drayver()
