"""Рисунки к проверке формы sigma_j(w) = |b_j + 3 r_j w^2|.

Сбор данных отделён от рисования: sobrat_vse() считает один раз и сохраняет,
рисунки читают готовое. Иначе загрузочные выборки пересчитывались бы для
каждого рисунка заново.
"""
import os, sys, pickle
import numpy as np
import matplotlib.pyplot as plt
from stil import *
import proverka_formy as PF

FAJL = os.path.join(os.environ.get('BTC_REZ', '.'), 'forma_rez.pkl')
CVET = {'постоянная': '#9e9e9e', 'рычаг': PAL[1], 'модель': '#c62828', 'полная': PAL[0]}
R_MIN = 0.05


def _lambda(par, B=400):
    """Объединённый масштаб beta_i = lambda * 3 r_i с загрузочным интервалом."""
    def odin(seed=None):
        rng = np.random.default_rng(seed)
        ch = de = 0.0
        for w, p, dt, pred in par:
            if seed is not None:
                i = rng.integers(0, len(w), len(w)); w, p = w[i], p[i]
            b = PF.biny(w, p, dt, nbin=8)
            if b is None:
                return None
            f = PF.podognat_formy(b)
            ve = 1.0 / max(np.mean(b['se']), 1e-9) ** 2
            ch += ve * pred * f['модель']['koef'][1]; de += ve * pred * pred
        return ch / de if de > 0 else None
    L = odin(None)
    BS = np.sort([x for x in (odin(s) for s in range(B)) if x is not None])
    if L is None or len(BS) < 50:
        return None
    return (float(L), float(np.quantile(BS, .025)), float(np.quantile(BS, .975)))


def _vetvi_btc(tagi, B=400):
    import ris_btc as RB
    razb, par = [], []
    for tag in tagi:
        rz = RB.razmetka(tag); d = rz['d']
        Y, t, dt = d['Y'], d['t'], d['dt']
        zk = np.asarray(rz['z'][rz['keep']])
        kk = np.asarray(rz['keep'], bool); Yk = np.asarray(Y)[kk]
        for j in range(rz['N']):
            a = PF.svodka_vetvi(Y, t, dt, rz['W'], zk, rz['keep'], rz['branches'],
                                j, rz['kind'], B=B, seed=17 + j)
            if a is None:
                continue
            a.update(tag=tag, j=j, g=rz['branches'][j],
                     vkl=abs(a['r_urovnya']) >= R_MIN)
            a['mash'] = PF.masshtaby(Y, np.asarray(rz['W']), zk, rz['keep'],
                                     rz['branches'], j, dt, rz['kind'])
            razb.append(a)
            if a['vkl']:
                ok = (zk == j) & PF.otstup(zk); pr = ok[:-1] & ok[1:]
                par.append((np.asarray(rz['W'])[:-1][pr], np.diff(Yk)[pr], dt,
                            a['beta_ozhid']))
    return razb, par


def _vetvi_sint(istinnye=True, B=400):
    import obshee as O, avtor as A
    razb, par = [], []
    for key in ['N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']:
        d = O.dannye(key); Y, t, dt = d['Y'], d['t'], d['dt']
        if istinnye:
            br = d['branches']; keep = np.ones(len(Y), bool)
            zk = np.asarray(d['lab']); W = np.asarray(d['W']); Yk = np.asarray(Y)
        else:
            rz = A.razmetka(key)
            br = rz['branches']; keep = np.asarray(rz['keep'], bool)
            zk = np.asarray(rz['z_keep']); W = np.asarray(rz['W'])
            Yk = np.asarray(Y)[keep]
        for j in range(len(br)):
            if abs(br[j][3]) < R_MIN:
                continue
            a = PF.svodka_vetvi(Y, t, dt, W, zk, keep, br, j, 'cub', B=B, seed=31 + j)
            if a is None:
                continue
            a.update(tag=key, j=j, g=br[j], vkl=True)
            razb.append(a)
            ok = (zk == j) & PF.otstup(zk); pr = ok[:-1] & ok[1:]
            par.append((W[:-1][pr], np.diff(Yk)[pr], dt, a['beta_ozhid']))
    return razb, par


def sobrat_vse(tagi_v, B=400):
    import btc_kuski as BK
    D = {}
    for imya, fn in [('sint_ist', lambda: _vetvi_sint(True, B)),
                     ('sint_pod', lambda: _vetvi_sint(False, B)),
                     ('btc_B', lambda: _vetvi_btc(BK.TAGI, B)),
                     ('btc_V', lambda: _vetvi_btc(tagi_v, B) if tagi_v else ([], []))]:
        print('  считаю:', imya, flush=True)
        D[imya] = fn()
    D['lam'] = {}
    for k in ['sint_ist', 'sint_pod', 'btc_B', 'btc_V']:
        D['lam'][k] = _lambda(D[k][1], B=B) if D[k][1] else None
        print('  масштаб %-9s %s' % (k, D['lam'][k]), flush=True)
    pickle.dump(D, open(FAJL, 'wb'))
    return D


# ------------------------------------------------------------------ рисунки
def ris_bity(razb, imya, zag, maks=8):
    r = sorted([x for x in razb if x['vkl']], key=lambda a: -abs(a['beta_ozhid']))[:maks]
    n = len(r)
    nc = min(4, n); nr = int(np.ceil(n / nc))
    fig, axs = plt.subplots(nr, nc, figsize=(7.4, 2.05 * nr + .95), squeeze=False)
    ruch = None
    for k, a in enumerate(r):
        ax = axs[k // nc][k % nc]; b = a['biny']
        ax.errorbar(b['w'], b['sig'], yerr=1.96 * b['se'], fmt='o', ms=3.2, color='k',
                    lw=.8, capsize=1.8, zorder=4, label='непараметрическая оценка')
        wg = np.linspace(b['w'].min(), b['w'].max(), 200); g = a['g']
        ax.plot(wg, np.abs(g[2] + 3.0 * g[3] * wg ** 2), color='#c62828', lw=1.5,
                zorder=3, label='модель $|b_j+3r_jw^2|$: свободных параметров нет')
        ax.axhline(a['formy']['постоянная']['koef'][0], color='#9e9e9e', lw=1.1,
                   ls='--', zorder=2, label='постоянная $\\sigma$ (предположение HMM и PELT)')
        ax.set_title('%s, ветвь %d\n$3r_j=%.2f$,  измерено $\\beta=%.2f$'
                     % (a['tag'], a['j'] + 1, a['beta_ozhid'], a['beta']), fontsize=7.2)
        ax.tick_params(labelsize=6.5); ax.locator_params(axis='both', nbins=4)
        ax.set_xlabel('$w$', fontsize=8)
        if k % nc == 0:
            ax.set_ylabel('$\\sigma$', fontsize=8)
        if ruch is None:
            ruch = ax.get_legend_handles_labels()
    for k in range(n, nr * nc):
        axs[k // nc][k % nc].axis('off')
    fig.legend(*ruch, loc='lower center', bbox_to_anchor=(.5, .925), ncol=3,
               fontsize=6.8, frameon=False, columnspacing=1.4, handlelength=1.8)
    fig.suptitle(zag, fontsize=8.8, y=.995)
    fig.subplots_adjust(left=.09, right=.985, top=.855 if nr > 1 else .70,
                        bottom=.09 if nr > 1 else .22, hspace=.62, wspace=.36)
    return sohr(fig, imya)


def ris_soperniki(a, imya='forma_soperniki'):
    b = a['biny']
    fig, ax = plt.subplots(figsize=(7.4, 3.2))
    ax.errorbar(b['w'], b['sig'], yerr=1.96 * b['se'], fmt='o', ms=4.5, color='k',
                lw=.9, capsize=2.2, zorder=5, label='непараметрическая оценка')
    wg = np.linspace(b['w'].min(), b['w'].max(), 250); e = np.ones_like(wg)
    for nm, X in [('постоянная', np.column_stack([e])),
                  ('рычаг', np.column_stack([e, wg])),
                  ('модель', np.column_stack([e, wg ** 2])),
                  ('полная', np.column_stack([e, wg ** 2, wg]))]:
        f = a['formy'][nm]
        ax.plot(wg, X @ f['koef'], color=CVET[nm], lw=1.4,
                ls='--' if nm == 'постоянная' else '-',
                label='%s, BIC %.1f' % (nm, f['bic']))
    ax.set_xlabel('$w$'); ax.set_ylabel('$\\sigma$')
    ax.set_title('Соперничающие формы, участок %s, ветвь %d' % (a['tag'], a['j'] + 1),
                 fontsize=9)
    # легенда в две строки НАД заголовком: в одну строку она в ширину не влезала
    # и накладывалась на него
    h, l = ax.get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', bbox_to_anchor=(.5, .87), ncol=3,
               fontsize=7, frameon=False, columnspacing=1.8, handlelength=1.8)
    fig.subplots_adjust(left=.09, right=.98, top=.80, bottom=.14)
    return sohr(fig, imya)


def ris_masshtaby(razb, imya='forma_masshtaby'):
    """beta на разных масштабах ИЗМЕРЕНИЯ волатильности."""
    ks = [(1, '15 мин'), (2, '30 мин'), (4, '60 мин')]
    fig, ax = plt.subplots(figsize=(7.4, 3.2))
    r = [a for a in razb if a['vkl'] and a.get('mash')]
    x = np.arange(len(r)); w = .26
    for i, (k, nm) in enumerate(ks):
        v = [(a['mash'][k]['otn'] if a['mash'].get(k) else np.nan) for a in r]
        ax.bar(x + (i - 1) * w, v, w, color=[SER, PAL[0], PAL[1]][i], alpha=.9, label=nm)
    ax.axhline(1.0, color='#c62828', lw=1.1, ls='--', zorder=4)
    ax.axhline(0.0, color='#616161', lw=.8, ls=':', zorder=4)
    ax.set_xticks(x)
    ax.set_xticklabels(['%s\nв%d' % (a['tag'], a['j'] + 1) for a in r], fontsize=6.4)
    ax.set_ylabel('$\\beta\\,/\\,3r_j$', fontsize=9)
    ax.set_title('Устойчивость к масштабу ИЗМЕРЕНИЯ волатильности\n'
                 'красная черта – предсказание модели; столбцов нет там, '
                 'где непересекающихся приращений не хватило', fontsize=8.4)
    legenda_sverhu(ax, ncol=3, y=1.02, fontsize=7.2)
    fig.tight_layout(rect=(0, 0, 1, .84))
    return sohr(fig, imya)


def ris_svodka(D, imya='forma_svodka'):
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.4),
                            gridspec_kw=dict(width_ratios=[1.7, 1], wspace=.36))
    ax = axs[0]
    gr = [('синтетика Н\nмодель верна', 'sint_ist', '#9e9e9e'),
          ('биткойн Б1…Б5\nотбор не под форму', 'btc_B', SER),
          ('биткойн В1…В3\nотбор под форму', 'btc_V', PAL[1])]
    podp = []
    for x, (nm, k, cv) in enumerate(gr):
        v = [d['otnoshenie'] for d in D[k][0]
             if d['vkl'] and np.isfinite(d['otnoshenie'])]
        if not v:
            podp.append((x, nm + '\n(нет данных)')); continue
        ax.scatter(np.full(len(v), x) + np.linspace(-.17, .17, len(v)), v, s=17,
                   color=cv, zorder=3, alpha=.85)
        ax.plot([x - .27, x + .27], [np.median(v)] * 2, color='k', lw=1.8, zorder=4)
        podp.append((x, '%s\nмедиана %.2f' % (nm, np.median(v))))
    ax.axhline(1.0, color='#c62828', lw=1.1, ls='--', zorder=2)
    ax.axhline(0.0, color='#616161', lw=.8, ls=':', zorder=2)
    ax.set_xticks([p for p, _ in podp])
    ax.set_xticklabels([n for _, n in podp], fontsize=6.5)
    ax.set_ylabel('$\\beta\\,/\\,3r_j$', fontsize=9)
    ax.set_title('Измеренная кривизна против предсказанной\n'
                 'точка – ветвь, чёрная черта – медиана', fontsize=8.2)
    ax.set_ylim(-.7, 2.8)

    ax = axs[1]
    nm = [('синтетика,\nистинные', 'sint_ist'), ('синтетика,\nподогнанные', 'sint_pod'),
          ('биткойн\nБ1…Б5', 'btc_B'), ('биткойн\nВ1…В3', 'btc_V')]
    for i, (n_, k) in enumerate(nm):
        dd = D['lam'].get(k)
        if dd is None:
            continue
        L, lo, hi = dd
        ax.errorbar([i], [L], yerr=[[L - lo], [hi - L]], fmt='o', ms=5,
                    color=SER if i >= 2 else '#9e9e9e', lw=1.5, capsize=3)
    ax.axhline(1.0, color='#c62828', lw=1.1, ls='--')
    ax.axhline(0.0, color='#616161', lw=.8, ls=':')
    ax.set_xticks(range(len(nm))); ax.set_xticklabels([n for n, _ in nm], fontsize=6.5)
    ax.set_ylabel('$\\lambda$', fontsize=9)
    ax.set_title('Объединённый масштаб\n$\\beta_i=\\lambda\\cdot 3r_i$', fontsize=8.2)
    fig.suptitle('Кривизна волатильности против предсказанной формой уровня',
                 fontsize=9, y=.99)
    fig.tight_layout(rect=(0, 0, 1, .90))
    return sohr(fig, imya)


def ris_poloviny(razb, imya='forma_poloviny'):
    """Половинный контроль: свойство уровня или временной дрейф."""
    r = [a for a in razb if a['vkl'] and a.get('poloviny')
         and all(p is not None for p in a['poloviny'])][:6]
    n = len(r); nc = min(3, n); nr = int(np.ceil(n / nc))
    fig, axs = plt.subplots(nr, nc, figsize=(7.4, 2.3 * nr + .7), squeeze=False)
    ruch = None
    for k, a in enumerate(r):
        ax = axs[k // nc][k % nc]
        for i, (p, cv, nm) in enumerate(zip(a['poloviny'], [SER, PAL[1]],
                                            ['первая половина времени',
                                             'вторая половина времени'])):
            b = p['биny'] if 'биny' in p else p['biny']
            ax.errorbar(b['w'], b['sig'], yerr=1.96 * b['se'], fmt='o', ms=3,
                        color=cv, lw=.8, capsize=1.6, label=nm, alpha=.9)
        wg = np.linspace(a['biny']['w'].min(), a['biny']['w'].max(), 200); g = a['g']
        ax.plot(wg, np.abs(g[2] + 3.0 * g[3] * wg ** 2), color='#c62828', lw=1.3,
                label='модель')
        ax.set_title('%s, ветвь %d' % (a['tag'], a['j'] + 1), fontsize=7.6)
        ax.tick_params(labelsize=6.5); ax.locator_params(axis='both', nbins=4)
        ax.set_xlabel('$w$', fontsize=8)
        if k % nc == 0:
            ax.set_ylabel('$\\sigma$', fontsize=8)
        if ruch is None:
            ruch = ax.get_legend_handles_labels()
    for k in range(n, nr * nc):
        axs[k // nc][k % nc].axis('off')
    fig.legend(*ruch, loc='lower center', bbox_to_anchor=(.5, .925), ncol=3,
               fontsize=7, frameon=False, columnspacing=1.6, handlelength=1.6)
    fig.suptitle('Половинный контроль: если U-образность есть свойство уровня, '
                 'она воспроизводится в обеих половинах', fontsize=8.6, y=.995)
    fig.subplots_adjust(left=.09, right=.985, top=.875, bottom=.12,
                        hspace=.75, wspace=.34)
    return sohr(fig, imya)


if __name__ == '__main__':
    import btc_kuski as BK
    import ris_btc as RB
    gotovo = [q['tag'] for q in BK.FORMA if RB.vybor(q['tag'])]
    print('участки В с готовой подгонкой:', gotovo or 'пока нет', flush=True)
    if 'peresch' in sys.argv or not os.path.exists(FAJL):
        D = sobrat_vse(gotovo, B=int(os.environ.get('BOOT', 400)))
    else:
        D = pickle.load(open(FAJL, 'rb'))
    ris_bity(D['btc_B'][0], 'forma_bity_B',
             'Биткойн Б1…Б5: участки отобраны по наглядности режимов, НЕ по форме волатильности')
    if D['btc_V'][0]:
        ris_bity(D['btc_V'][0], 'forma_bity_V',
                 'Биткойн В1…В3: участки отобраны по силе зависимости волатильности от уровня')
    ris_bity(D['sint_ist'][0], 'forma_bity_sint',
             'Синтетика Н: модель верна по построению – калибровка процедуры')
    kand = [a for a in D['btc_B'][0] if a['vkl']]
    if kand:
        ris_soperniki(max(kand, key=lambda a: a['formy']['постоянная']['bic']
                          - a['formy']['модель']['bic']))
    ris_masshtaby(D['btc_B'][0])
    ris_poloviny(D['btc_B'][0])
    ris_svodka(D)
