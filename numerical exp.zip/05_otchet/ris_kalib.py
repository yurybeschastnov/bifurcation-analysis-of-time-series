"""Рисунки группы В: аттестация эталонов и контрольные опыты.

  kalibrovka   эталоны на данных из их собственных классов
  lozhnye      контрольный опыт: режимов нет, волатильность гладко зависит от драйвера
  perebor      сверка правдоподобий с точным перебором и сеточной рекурсией
  mssv_orakul  оракульный тест MSSV
"""
import os, sys, os, pickle, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'otchet'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'sravnenie'))
sys.path.insert(0, os.environ.get('MSDE_PATH', '.'))
import numpy as np
import matplotlib.pyplot as plt
from stil import *
import obshee as O, metody as MT, metody2 as M2, kalibrovka as KB

KESH = os.environ.get('REZ_PATH','../rezultaty') + '/kesh_kalib.pkl'


def schitat():
    if os.path.exists(KESH):
        return pickle.load(open(KESH, 'rb'))
    D = {}
    # --- тест 1: гауссова HMM, K=3
    r, z = KB.sim_hmm(seed=0)
    H = MT.hmm(r, Kmax=6, restarts=10)
    D['hmm_krivaya'] = {k: v['bic'] for k, v in H.items()}
    Kb = min(H, key=lambda k: H[k]['bic'])
    D['hmm_test'] = dict(K=Kb, sigma=np.sort(H[Kb]['sigma']).tolist(),
                         ist=[0.35, 0.75, 1.30], ari=O.ari(H[Kb]['z'], z))
    Hd = MT.hdphmm(r, iters=500, burn=200, seed=0)
    D['hdp_test'] = dict(K=Hd['K'], post=Hd['post'].tolist(), ari=O.ari(Hd['z'], z))
    # --- тест 2: кусочно-постоянная дисперсия
    r2, z2 = KB.sim_kus(seed=0)
    P = MT.pelt(r2, Kmax=6)
    D['pelt_test'] = dict(K=P['K'], nseg=P['nseg'], sigma=np.sort(P['sigma']).tolist(),
                          ist=[0.4, 0.6, 1.2, 1.5], ari=O.ari(P['z'], z2))
    # --- тест 4: режимов нет, sigma гладко зависит от драйвера
    r4, z4, s4 = KB.sim_gladk(seed=0)
    H4 = MT.hmm(r4, Kmax=6, restarts=10)
    D['lozh'] = dict(hmm_bic=min(H4, key=lambda k: H4[k]['bic']),
                     hmm_icl=min(H4, key=lambda k: H4[k]['icl']),
                     hdp=MT.hdphmm(r4, iters=500, burn=200, seed=0)['K'],
                     pelt=MT.pelt(r4, Kmax=6)['K'],
                     dp=MT.dpgmm(r4)['K'],
                     sig=s4, r=r4)
    pickle.dump(D, open(KESH, 'wb'))
    return D


def ris_kalibrovka(D):
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 3.1))
    # (а) кривая BIC гауссовой HMM на данных своего класса
    ax = axs[0]
    kr = D['hmm_krivaya']; Ns = sorted(kr); mn = min(kr.values())
    ax.bar(Ns, [kr[N] - mn for N in Ns], .62,
           color=[SER if N == 3 else '#bdbdbd' for N in Ns])
    ax.set_xlabel('$K$'); ax.set_ylabel('$\\Delta$BIC')
    ax.set_title('(а) HMM на данных HMM,\nистинное $K=3$', fontsize=8.5)
    # (б) восстановленные sigma
    ax = axs[1]
    x = np.arange(3)
    ax.bar(x - .2, D['hmm_test']['ist'], .38, color='k', alpha=.75, label='истинные')
    ax.bar(x + .2, D['hmm_test']['sigma'], .38, color=PAL[0], label='HMM')
    ax.set_xticks(x); ax.set_xticklabels(['$\\sigma_1$', '$\\sigma_2$', '$\\sigma_3$'])
    ax.set_title('(б) восстановление $\\sigma$,\nARI = %.3f' % D['hmm_test']['ari'], fontsize=8.5)
    ax.set_ylim(0, max(D['hmm_test']['sigma'] + D['hmm_test']['ist']) * 1.12)
    legenda_sverhu(ax, ncol=2, y=1.20, fontsize=7)
    # (в) PELT на кусочно-постоянных данных
    ax = axs[2]
    x = np.arange(4)
    ax.bar(x - .2, D['pelt_test']['ist'], .38, color='k', alpha=.75, label='истинные')
    sg = D['pelt_test']['sigma'] + [np.nan] * (4 - len(D['pelt_test']['sigma']))
    ax.bar(x + .2, sg[:4], .38, color=PAL[3], label='PELT')
    ax.set_xticks(x); ax.set_xticklabels(['$\\sigma_%d$' % (i + 1) for i in range(4)])
    ax.set_title('(в) PELT на кусочно-постоянной\nдисперсии, ARI = %.3f'
                 % D['pelt_test']['ari'], fontsize=8.5)
    ax.set_ylim(0, np.nanmax(np.r_[sg[:4], D['pelt_test']['ist']]) * 1.12)
    legenda_sverhu(ax, ncol=2, y=1.20, fontsize=7)
    fig.suptitle('Аттестация эталонов: каждый метод на данных из собственного класса',
                 fontsize=9.5, y=1.04)
    fig.tight_layout(rect=(0, 0, 1, .97))
    return sohr(fig, 'kalibrovka')


def ris_lozhnye(D):
    """Контрольный опыт: режимов нет."""
    L = D['lozh']
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 2.9),
                            gridspec_kw=dict(width_ratios=[1.45, 1]))
    ax = axs[0]
    n = len(L['sig']); t = np.linspace(0, 1, n)
    ax.plot(t, L['sig'], color='k', lw=.9)
    ax.set_xlabel('$t$'); ax.set_ylabel('$\\sigma_t$')
    ax.set_title('(а) порождающая волатильность: $\\sigma=0{,}35+0{,}45\\,W_t^2$,\n'
                 'режимов нет, истинное $K=1$', fontsize=8.5)
    ax = axs[1]
    nm = ['BIC+HMM', 'ICL+HMM', 'HDP-HMM', 'PELT', 'проц. Дирихле']
    vv = [L['hmm_bic'], L['hmm_icl'], L['hdp'], L['pelt'], L['dp']]
    col = [PAL[0], PAL[1], PAL[2], PAL[3], PAL[4]]
    ax.barh(np.arange(len(nm)), vv, .62, color=col)
    ax.axvline(1, color='#c62828', lw=1.2, ls='--', label='верный ответ $K=1$')
    for i, v in enumerate(vv):
        ax.text(v + .08, i, str(v), va='center', fontsize=8)
    ax.set_yticks(np.arange(len(nm))); ax.set_yticklabels(nm, fontsize=7.5)
    ax.set_xlabel('$\\hat K$'); ax.set_xlim(0, max(vv) + 1.1)
    ax.invert_yaxis()
    ax.set_title('(б) оценки числа режимов', fontsize=8.5)
    # Легенда СПРАВА от панели. Внутри осей она упиралась в столбец процесса
    # Дирихле, а над панелью налезала на её же заголовок: заголовок и легенда
    # претендуют на одну и ту же полосу. Справа полоса своя, и место под неё
    # резервируется явно через subplots_adjust.
    legenda_sprava(ax, fontsize=7)
    fig.subplots_adjust(left=.075, right=.775, top=.84, bottom=.155, wspace=.30)
    return sohr(fig, 'lozhnye')


def ris_mssv_orakul():
    """Оракульный тест MSSV: BIC при подгонке и при истинных параметрах."""
    # ИСПРАВЛЕНО: значения вычисляются (03_sravnenie/orakul_mssv.py),
    # а не вписаны константами
    OR = pickle.load(open(os.path.join(os.environ.get('REZ_PATH', '.'),
                                       'mssv_orakul.pkl'), 'rb'))
    ORAK = {k: v['bic'] for k, v in OR.items()}
    fig, ax = plt.subplots(figsize=(7.4, 3.1))
    ks = list(ORAK)
    x = np.arange(len(ks))
    b1 = [MS[k][1]['bic'] for k in ks]
    bK = [MS[k][O.dannye(k)['K']]['bic'] for k in ks]
    bO = [ORAK[k] for k in ks]; sdO = [OR[k]['sd'] for k in ks]
    base = np.array(b1)
    ax.bar(x - .26, np.zeros(len(ks)), .24, color='#90a4ae', label='$K=1$ (подгонка)')
    ax.bar(x, np.array(bK) - base, .24, color='#546e7a', label='$K=K_{ист}$ (подгонка)')
    ax.bar(x + .26, np.array(bO) - base, .24, color='#8e24aa',
           yerr=sdO, error_kw=dict(lw=.8, capsize=2),
           label='$K=K_{ист}$ (оракульные параметры)')
    ax.axhline(0, color='k', lw=.8)
    ax.set_xticks(x); ax.set_xticklabels([RUS[k] for k in ks])
    ax.set_ylabel('BIC относительно $K=1$')
    ax.set_title('Оракульный тест MSSV: значения ниже нуля означают,\n'
                 'что один режим проигрывает и выбор $K=1$ есть отказ оценивания',
                 fontsize=9)
    # легенда над заголовком: внутри осей она перекрывала столбцы рядов Н3 и Н6
    legenda_sverhu(ax, ncol=3, y=1.22, fontsize=7)
    fig.tight_layout(rect=(0, 0, 1, .88))
    return sohr(fig, 'mssv_orakul')


if __name__ == '__main__':
    D = schitat()
    z = sys.argv[1:] if len(sys.argv) > 1 else ['kal', 'lozh', 'orak']
    if 'kal' in z:
        ris_kalibrovka(D)
    if 'lozh' in z:
        ris_lozhnye(D)
    if 'orak' in z:
        ris_mssv_orakul()
