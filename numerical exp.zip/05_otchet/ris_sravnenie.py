"""Рисунки группы Б: сравнение конвейеров.

  vybor_K      матрица выбора числа режимов по всем конвейерам и рядам
  metriki_L    столбчатые диаграммы метрик, эксперимент Л
  metriki_N    то же, эксперимент Н
  bic_avtor    кривые BIC предложенного метода, запасы до соседних степеней
  razdelenie   ошибка выбора K против ошибки оценивания
  etalon_sniz  E_L2 против эталона снизу (локальная реализованная волатильность)
"""
import sys, os, pickle
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from stil import *
import obshee as O

PORYAD_L = ['avtor', 'pelt', 'hmm_bic', 'hmm_aic', 'yadro', 'hdphmm', 'hmm_icl', 'dp_hmm']
PORYAD_N = ['avtor', 'hmm_bic', 'hmm_aic', 'yadro', 'hmm_icl', 'smes', 'hdphmm', 'pelt',
            'dp_hmm', 'mssv']

# честные запасы при N=K+1 (см. tablicy.tab_bic)
CHEST = pickle.load(open(os.path.join(os.environ.get('REZ_PATH', '.'),
                                      'zapas_chestnyi.pkl'), 'rb'))


def ris_vybor_K():
    """Матрица: строки – конвейеры, столбцы – ряды, цвет – ошибка в K."""
    fig, axs = plt.subplots(1, 2, figsize=(7.6, 3.7),
                            gridspec_kw=dict(width_ratios=[6, 7], wspace=.95))
    for ax, (gr, por, nm) in zip(axs, [(LR, PORYAD_L, 'эксперимент Л'),
                                       (NR, PORYAD_N, 'эксперимент Н')]):
        ist = [O.dannye(r)['K'] for r in gr]
        M = np.full((len(por), len(gr)), np.nan)
        for i, tg in enumerate(por):
            for j, r in enumerate(gr):
                v = val(r, tg, 'K')
                if v is not None:
                    M[i, j] = v - ist[j]
        cmap = ListedColormap(['#1565c0', '#64b5f6', '#e8f5e9', '#ffcc80', '#ef6c00', '#b71c1c'])
        im = ax.imshow(np.clip(M, -2, 3), cmap=cmap, vmin=-2.5, vmax=3.5, aspect='auto')
        for i in range(len(por)):
            for j in range(len(gr)):
                if np.isfinite(M[i, j]):
                    ax.text(j, i, '%d' % (M[i, j] + ist[j]), ha='center', va='center',
                            fontsize=7.5, color='k')
                else:
                    ax.text(j, i, '–', ha='center', va='center', fontsize=7, color='#9e9e9e')
        ax.set_xticks(range(len(gr)))
        ax.set_xticklabels(['%s\n(K=%d)' % (RUS[r], k) for r, k in zip(gr, ist)], fontsize=7)
        ax.set_yticks(range(len(por)))
        ax.set_yticklabels([KON[t][0] for t in por], fontsize=7)
        ax.set_title(nm, fontsize=9)
        ax.grid(False)
        # доля верных справа
        for i, tg in enumerate(por):
            v = [val(r, tg, 'K') for r in gr]
            ok = sum(1 for a, b in zip(v, ist) if a == b)
            n = sum(1 for a in v if a is not None)
            ax.text(len(gr) - .42, i, '%d/%d' % (ok, n), ha='left', va='center',
                    fontsize=7.5, fontweight='bold' if tg == 'avtor' else 'normal',
                    clip_on=False)
    fig.suptitle('Определение числа режимов: оценка $\\hat K$ (цвет – отклонение от истинного)',
                 fontsize=9.5, y=1.02)
    return sohr(fig, 'vybor_K')


def _bars(ax, gr, por, pole, title, luchshe='max'):
    n = len(por); w = .8 / n
    x = np.arange(len(gr))
    for i, tg in enumerate(por):
        v = [val(r, tg, pole) for r in gr]
        vv = [np.nan if a is None else a for a in v]
        ax.bar(x + i * w - .4 + w / 2, vv, w, color=KON[tg][1],
               alpha=1.0 if tg == 'avtor' else .78,
               edgecolor='k' if tg == 'avtor' else 'none', linewidth=.6,
               label=KON[tg][0])
    ax.set_xticks(x); ax.set_xticklabels([RUS[r] for r in gr], fontsize=8)
    ax.set_title(title, fontsize=9)
    ax.set_axisbelow(True)


def ris_metriki(gr, por, imya, zag):
    """Три метрики столбцами.

    Легенда одна на весь рисунок и вынесена над верхней панелью. Прежде их было
    две: общая над первой панелью и вторая ВНУТРИ третьей панели, где она
    ложилась на столбцы и её пересекала штриховая линия эталона снизу. Эталон
    снизу теперь входит в ту же общую легенду.
    """
    fig, axs = plt.subplots(3, 1, figsize=(7.4, 8.0))
    _bars(axs[0], gr, por, 'acc', '%s: доля верных режимных меток' % zag)
    axs[0].set_ylim(0.3, 1.10)
    _bars(axs[1], gr, por, 'ari', '%s: скорректированный индекс Ранда (ARI)' % zag)
    axs[1].set_ylim(0, 1.10)
    _bars(axs[2], gr, por, 'l2', '%s: относительная ошибка волатильности $E_{L2}$' % zag)
    axs[2].set_ylabel('$E_{L2}$')
    # эталон снизу
    rv = [min(RES[r]['rv'].values()) for r in gr]
    axs[2].plot(np.arange(len(gr)), rv, 'k--', lw=.9, marker='o', ms=3,
                label='эталон снизу: локальная RV')
    ymax = max([v for v in [val(r, t, 'l2') for r in gr for t in por] if v is not None])
    axs[2].set_ylim(0, ymax * 1.18)
    # Общая легенда: столбцы из первой панели плюс эталон снизу из третьей.
    # Третья панель содержит ТЕ ЖЕ столбцы, поэтому её ручки берутся только для
    # подписей, которых ещё нет: иначе легенда выходила задвоенной.
    h0, l0 = axs[0].get_legend_handles_labels()
    h2, l2 = axs[2].get_legend_handles_labels()
    dop = [(h, l) for h, l in zip(h2, l2) if l not in l0]
    hh = h0 + [h for h, _ in dop]
    ll = l0 + [l for _, l in dop]
    fig.legend(hh, ll, loc='upper center', bbox_to_anchor=(.5, .997),
               ncol=4, fontsize=7.0, frameon=False, columnspacing=1.4,
               handlelength=1.4)
    nlin = int(np.ceil(len(hh) / 4.0))
    fig.tight_layout(rect=(0, 0, 1, .975 - .020 * nlin))
    return sohr(fig, imya)


def ris_bic_avtor():
    """Кривые BIC предложенного метода по всем рядам."""
    fig, axs = plt.subplots(2, 7, figsize=(7.4, 3.4), sharex=False)
    for ax, key in zip(axs.ravel(), ORD):
        b = dict(BIC[key]['bic']); K = BIC[key]['K']
        if key in CHEST:                      # запас при K+1 – по достижимому ll
            b[K + 1] = b[K] + CHEST[key]
        Ns = sorted(b); mn = min(b.values())
        d = [b[N] - mn for N in Ns]
        col = [SER if N == K else '#bdbdbd' for N in Ns]
        ax.bar(Ns, d, .62, color=col)
        ax.axvline(K, color='#c62828', lw=.7, ls='--', alpha=.7)
        ax.set_title(RUS[key], fontsize=8)
        ax.set_xticks(Ns); ax.tick_params(labelsize=6.5)
        if ax is axs.ravel()[0] or ax is axs.ravel()[7]:
            ax.set_ylabel('$\\Delta$BIC', fontsize=7.5)
    axs.ravel()[-1].axis('off')
    fig.suptitle('BIC предложенного метода: превышение над минимумом по числу ветвей $N$\n'
                 '(тёмный столбец – истинное $K$; поиск включает $N=K+2$)', fontsize=9, y=1.06)
    fig.tight_layout()
    return sohr(fig, 'bic_avtor')


def ris_razdelenie():
    """Метрики при K, выбранном самим методом, против K подаренного."""
    par = [('hmm_bic', 'hmm_pri_K', 'гауссова HMM'),
           ('yadro', 'yadro_pri_K', 'ядерная $\\sigma_j(w)$'),
           ('smes', 'smes_pri_K', 'HMM, смеси')]
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 3.4))
    ruch = [None]
    for ax, (gr, nm) in zip(axs, [(LR, 'эксперимент Л'), (NR, 'эксперимент Н')]):
        met = ['ari', 'l2']
        lab = []; v1 = []; v2 = []
        for t1, t2, im in par:
            a1 = [RES[r].get(t1) for r in gr]; a2 = [RES[r].get(t2) for r in gr]
            if not any(a2):
                continue
            f = lambda A, p: np.median([x[p] for x in A if x])
            lab.append(im); v1.append(f(a1, 'ari')); v2.append(f(a2, 'ari'))
        av = np.median([AV[r]['ari'] for r in gr])
        x = np.arange(len(lab))
        ax.bar(x - .2, v1, .38, color='#90a4ae', label='$K$ выбирает сам метод')
        ax.bar(x + .2, v2, .38, color='#546e7a', label='$K$ подарено')
        ax.axhline(av, color=SER, lw=1.4, ls='-',
                   label='предложенный метод (%.3f)' % av)
        ax.set_xticks(x); ax.set_xticklabels(lab, fontsize=7.5)
        ax.set_ylabel('ARI (медиана)'); ax.set_title(nm, fontsize=9)
        ax.set_ylim(0, 1.12)
        if ruch[0] is None:
            ruch[0] = ax.get_legend_handles_labels()
    # легенда общая и НАД панелями: внутри осей она ложилась на столбцы,
    # а столбцы здесь доходят почти до верха области рисования
    fig.legend(*ruch[0], loc='upper center', bbox_to_anchor=(.5, .90), ncol=3,
               fontsize=7.0, frameon=False, columnspacing=1.8, handlelength=1.5)
    fig.suptitle('Разделение источников ошибки: выбор числа режимов против качества разметки',
                 fontsize=9.5, y=.995)
    fig.tight_layout(rect=(0, 0, 1, .845))
    return sohr(fig, 'razdelenie')


def ris_etalon():
    """E_L2 предложенного метода против локальной RV при разных окнах."""
    fig, ax = plt.subplots(figsize=(7.4, 3.2))
    x = np.arange(len(ORD))
    for h, c in zip([10, 20, 40, 80], ['#cfd8dc', '#b0bec5', '#90a4ae', '#78909c']):
        ax.plot(x, [RES[r]['rv'][h] for r in ORD], color=c, lw=.9, marker='.', ms=4,
                label='локальная RV, $h=%d$' % h)
    ax.plot(x, [AV[r]['l2'] for r in ORD], color=SER, lw=1.8, marker='o', ms=4.5,
            label='предложенный метод')
    ax.set_xticks(x); ax.set_xticklabels([RUS[r] for r in ORD], fontsize=8)
    ax.set_ylabel('$E_{L2}$')
    ax.set_title('Восстановление волатильности против эталона снизу без режимной структуры',
                 fontsize=9)
    # легенда над заголовком: при loc='upper center' она стояла внутри осей и
    # кривая локальной RV при h=80 проходила прямо сквозь неё
    legenda_sverhu(ax, ncol=5, y=1.14, fontsize=7)
    # предел по данным, а не заданный вручную: при ylim=0.30 верхняя кривая
    # локальной RV при h=80 обрезалась на рядах Л5, Л6 и Н5
    vsyo = [RES[r]['rv'][h] for r in ORD for h in (10, 20, 40, 80)] + \
           [AV[r]['l2'] for r in ORD]
    ax.set_ylim(0, max(vsyo) * 1.06)
    fig.tight_layout(rect=(0, 0, 1, .90))
    return sohr(fig, 'etalon_sniz')


def ris_po_ryadam():
    """Сравнение по каждому ряду с НАИЛУЧШИМ эталоном на этом ряде."""
    ATT = [t for t in KON if t != 'avtor' and KON[t][2]]

    def luch(r, pole, minim=False):
        v = {t: val(r, t, pole) for t in ATT if val(r, t, pole) is not None}
        b = (min if minim else max)(v, key=v.get)
        return b, v[b]

    fig, axs = plt.subplots(2, 2, figsize=(7.4, 5.9),
                            gridspec_kw=dict(width_ratios=[6, 7], hspace=.42, wspace=.24))
    ruch = [None]
    for col, (gr, nm) in enumerate([(LR, 'эксперимент Л'), (NR, 'эксперимент Н')]):
        for row, (pole, podp, minim) in enumerate(
                [('ari', 'ARI', False), ('l2', '$E_{L2}$', True)]):
            ax = axs[row, col]
            x = np.arange(len(gr))
            am = [val(r, 'avtor', pole) for r in gr]
            ab = [luch(r, pole, minim)[1] for r in gr]
            for i, (a, b) in enumerate(zip(am, ab)):
                pob = (a > b) if not minim else (a < b)
                c = '#2e7d32' if (pob and abs(a - b) > 1e-3) else (
                    '#c62828' if (not pob and abs(a - b) > 1e-3) else '#9e9e9e')
                ax.plot([i, i], [b, a], color=c, lw=1.6, zorder=1, alpha=.75)
            ax.plot(x, ab, 'o', ms=5.0, color='#90a4ae', zorder=2,
                    label='лучший эталон на этом ряде')
            ax.plot(x, am, 'o', ms=5.5, color=SER, zorder=3,
                    label='предложенный метод')
            ax.set_xticks(x); ax.set_xticklabels([RUS[r] for r in gr], fontsize=8)
            ax.set_ylabel(podp)
            if row == 0:
                ax.set_title(nm, fontsize=9)
                if col == 0:
                    ruch[0] = ax.get_legend_handles_labels()
            if pole == 'ari':
                ax.set_ylim(0, 1.14)
    # Легенда вынесена в полосу между общим заголовком и заголовками панелей.
    # Внутри осей она попадала на точки рядов Л1 и Н1, где ARI близок к единице,
    # а при выключке по верхнему краю налезала на подписи «эксперимент Л/Н»,
    # поэтому привязка идёт НИЖНИМ краем легенды.
    fig.legend(*ruch[0], loc='lower center', bbox_to_anchor=(.5, .905), ncol=2,
               fontsize=7.2, frameon=False, columnspacing=2.2, handlelength=1.4)
    fig.suptitle('Сравнение по каждому ряду с наилучшим аттестованным эталоном\n'
                 'зелёный отрезок – выигрыш, красный – проигрыш, серый – разница '
                 'менее 0,001', fontsize=9.5, y=.995)
    fig.tight_layout(rect=(0, 0, 1, .845))
    return sohr(fig, 'po_ryadam')


if __name__ == '__main__':
    zad = sys.argv[1:] if len(sys.argv) > 1 else ['K', 'mL', 'mN', 'bic', 'razd', 'etal', 'ryad']
    for z in zad:
        if z == 'K':
            ris_vybor_K()
        elif z == 'mL':
            ris_metriki(LR, PORYAD_L, 'metriki_L', 'эксперимент Л')
        elif z == 'mN':
            ris_metriki(NR, PORYAD_N, 'metriki_N', 'эксперимент Н')
        elif z == 'bic':
            ris_bic_avtor()
        elif z == 'razd':
            ris_razdelenie()
        elif z == 'etal':
            ris_etalon()
        elif z == 'ryad':
            ris_po_ryadam()
