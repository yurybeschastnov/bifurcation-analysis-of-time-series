"""Сборка мини-отчёта о форме режимной волатильности.

Таблицы считаются здесь по forma_rez.pkl, а не вписываются в текст руками.
Вёрстка таблиц – тот же tab_latex с измеренными ширинами, переносы – тот же
perenosy, контроль переполнений – тот же.
"""
import os, re, sys, pickle, subprocess
import numpy as np
import tab_latex as TL
import perenosy as PN

BAZA = os.environ.get('OTCH_PATH', os.path.dirname(os.path.abspath(__file__)))
RIS = os.environ.get('RIS_PATH', os.path.join(BAZA, '..', '07_risunki_350dpi'))
REZ = os.environ.get('BTC_REZ', '.')
D = pickle.load(open(os.path.join(REZ, 'forma_rez.pkl'), 'rb'))

RISUNKI = {
    'FIG_FORMA_SINT': ('forma_bity_sint',
        'Калибровка на синтетике Н, где модель верна по построению. Точки – '
        'непараметрическая оценка с 95-процентными интервалами, красная кривая – '
        'предсказание $|b_j+3r_jw^2|$ по ИСТИННЫМ параметрам, без подгонки.'),
    'FIG_FORMA_BITY_B': ('forma_bity_B',
        'Биткойн, участки Б1…Б5. Отбор этих участков вёлся по наглядности '
        'режимной структуры и к волатильности как функции уровня отношения не '
        'имел. Красная кривая – предсказание модели, свободных параметров в ней '
        'нет: $b_j$ и $r_j$ взяты из подгонки уровня. Серая штриховая – '
        'постоянная волатильность, то есть предположение HMM и PELT.'),
    'FIG_FORMA_SOPERNIKI': ('forma_soperniki',
        'Четыре соперничающие формы на ветви с наибольшим перевесом. '
        'Постоянная – предположение эталонов, рычаг – классический рыночный '
        'эффект роста волатильности при падении цены, модель – симметричная '
        'парабола, полная – вложенная, различающая две предыдущие.'),
    'FIG_FORMA_SVODKA': ('forma_svodka',
        'Слева: отношение измеренной кривизны к предсказанной по всем ветвям. '
        'Справа: объединённая оценка масштаба $\\lambda$ в $\\beta_i=\\lambda\\cdot3r_i$ '
        'с 95-процентными интервалами. Совпадение синтетики с единицей – '
        'калибровка, дающая смысл числу по биткойну.'),
    'FIG_FORMA_MASSHTABY': ('forma_masshtaby',
        'Устойчивость к масштабу ИЗМЕРЕНИЯ волатильности: приращения соседних '
        'баров (15 минут), через один (30 минут) и через три (60 минут), без '
        'перекрытий. Столбцы отсутствуют там, где непересекающихся приращений '
        'не хватило для восьми бинов.'),
    'FIG_FORMA_POLOVINY': ('forma_poloviny',
        'Половинный контроль. Кривая строится отдельно по первой и второй '
        'половине времени внутри режима. Совпадение означает, что U-образность '
        'есть свойство уровня, а не временной дрейф волатильности.'),
}


def _vkl(nabor):
    return [a for a in D[nabor][0] if a['vkl']]


def _dvustoronnyaya(a):
    b = a['biny']; w, n = b['w'], b['n']
    lev, prav = n[w < 0].sum(), n[w >= 0].sum()
    return min(lev, prav) / max(lev + prav, 1) > 0.15


def tab_kalib():
    L = ['| набор | ветвей | $\\lambda$ | 95-процентный интервал | истина |', '|---|---|---|---|---|']
    for k, nm in [('sint_ist', 'синтетика Н, истинные ветви и метки'),
                  ('sint_pod', 'синтетика Н, подогнанные ветви и метки')]:
        d = D['lam'].get(k)
        if not d:
            continue
        L.append('| %s | %d | **%.3f** | %.3f … %.3f | 1,000 |'
                 % (nm, len(_vkl(k)), d[0], d[1], d[2]))
    return '\n'.join(L)


def tab_svodka():
    L = ['| участок | ветвь | $3r_j$ | измеренное $\\beta$ | 95-процентный интервал | '
         'лучшая форма | обе стороны |', '|---|---|---|---|---|---|---|']
    for a in sorted(_vkl('btc_B'), key=lambda z: (z['tag'], z['j'])):
        bs = a['bootstrap']; f = a['formy']
        luch = min(f, key=lambda k: f[k]['bic'])
        L.append('| %s | %d | %.2f | %.2f | %.2f … %.2f | %s | %s |'
                 % (a['tag'], a['j'] + 1, a['beta_ozhid'], a['beta'],
                    bs['nizh'], bs['verh'], luch,
                    'да' if _dvustoronnyaya(a) else '–'))
    return '\n'.join(L)


def tab_moshnost():
    d = D['lam']['btc_B']
    L = ['| гипотеза о масштабе $\\lambda$ | смысл | итог |', '|---|---|---|']
    for v, sm in [(0.0, 'постоянная $\\sigma$ внутри режима – предположение эталонов'),
                  (0.5, 'кривизна вдвое меньше предсказанной'),
                  (1.0, '**предсказание модели**'),
                  (1.5, 'кривизна в полтора раза больше'),
                  (2.0, 'кривизна вдвое больше')]:
        itog = 'совместимо' if d[1] <= v <= d[2] else '**отвергнуто**'
        L.append('| $\\lambda=%.1f$ | %s | %s |' % (v, sm, itog))
    L.append('')
    L.append('Оценка: $\\lambda=%.3f$, интервал $[%.3f,\\ %.3f]$ по %d ветвям.'
             % (d[0], d[1], d[2], len(_vkl('btc_B'))))
    return '\n'.join(L)


def tab_simmetriya():
    L = ['| участок | ветвь | BIC постоянной | BIC рычага | BIC модели | перевес над рычагом |',
         '|---|---|---|---|---|---|']
    for a in _vkl('btc_B'):
        if not _dvustoronnyaya(a):
            continue
        f = a['formy']
        L.append('| %s | %d | %.1f | %.1f | **%.1f** | %.1f |'
                 % (a['tag'], a['j'] + 1, f['постоянная']['bic'], f['рычаг']['bic'],
                    f['модель']['bic'], f['рычаг']['bic'] - f['модель']['bic']))
    return '\n'.join(L)


def tab_masshtaby():
    L = ['| масштаб | что это | величина |', '|---|---|---|']
    L.append('| измерение $\\sigma$ | приращение между соседними барами | 15 минут |')
    L.append('| проверка устойчивости | непересекающиеся приращения через 1 и 3 бара | 30 и 60 минут |')
    sp = []
    for a in _vkl('btc_B'):
        m = a.get('mash') or {}
        for k in (1, 2, 4):
            if m.get(k) and np.isfinite(m[k]['otn']):
                sp.append((k, m[k]['otn']))
    for k, nm in [(1, '15 минут'), (2, '30 минут'), (4, '60 минут')]:
        v = [x for kk, x in sp if kk == k]
        if v:
            L.append('| медиана $\\beta/3r_j$ при измерении на %s | устойчивость формы | %.2f (ветвей %d) |'
                     % (nm, np.median(v), len(v)))
    L.append('| длительность режима | сколько живёт сам режим | 37 … 366 часов |')
    L.append('| пробег драйвера по параболе | время попадания в крайний бин по $w$ | 2 … 236 часов |')
    return '\n'.join(L)


TABLICY = {
    'TABLE_FORMA_KALIB': ('Калибровка процедуры на синтетике', tab_kalib),
    'TABLE_FORMA_SVODKA': ('Биткойн Б1…Б5: измеренная кривизна против предсказанной', tab_svodka),
    'TABLE_FORMA_MOSHNOST': ('Что тест отвергает и что нет', tab_moshnost),
    'TABLE_FORMA_SIMMETRIYA': ('Ветви, на которых симметрия проверяема', tab_simmetriya),
    'TABLE_FORMA_MASSHTABY': ('Три временных масштаба задачи', tab_masshtaby),
}


def sobrat():
    s = open(os.path.join(BAZA, 'mini_forma.md')).read()
    s = re.sub(r'(?s)^---.*?\n---\n', '', s, count=1)
    n_ris = 0
    for m, (imya, podp) in RISUNKI.items():
        p = os.path.abspath(os.path.join(RIS, imya + '.png'))
        if not os.path.exists(p):
            print('  ВНИМАНИЕ: нет рисунка', imya); s = s.replace(m + '\n', ''); continue
        s = s.replace(m, '![%s](%s)\n' % (podp, p)); n_ris += 1
    n_tab = 0
    for m, (zag, fn) in TABLICY.items():
        md = fn()
        telo = '\n'.join(x for x in md.split('\n') if x.strip().startswith('|'))
        hvost = '\n'.join(x for x in md.split('\n') if not x.strip().startswith('|')).strip()
        tex = TL.tablica_v_latex(telo, zag)
        s = s.replace(m, tex + (('\n\n' + hvost) if hvost else '')); n_tab += 1
    ost = re.findall(r'(FIG_[A-Z_]+|TABLE_[A-Z_]+)', s)
    print('  рисунков %d, таблиц %d, незаменённых меток: %s'
          % (n_ris, n_tab, sorted(set(ost)) or 'нет'))
    open(os.path.join(BAZA, 'mini_forma_gotovo.md'), 'w').write(s)
    open(os.path.join(BAZA, 'perenosy.tex'), 'w').write(PN.spisok(s) + '\n')
    return s


if __name__ == '__main__':
    sobrat()
    titul = r"""\begin{titlepage}\centering\vspace*{2.2cm}
{\Large\bfseries\sffamily Форма режимной волатильности на биткойне\par}
\vspace{0.7cm}
{\large проверка предсказания $\sigma_j(w)=|b_j+3r_jw^2|$\\ непараметрическими средствами\par}
\vspace{1.2cm}
{\normalsize дополнение к отчёту по вычислительному эксперименту\par}
\vspace{2.2cm}
{\small Все рисунки построены с разрешением 350 dpi\par}
\vfill\end{titlepage}"""
    open(os.path.join(BAZA, 'titul_mini.tex'), 'w').write(titul)
    # pandoc делает .tex, xelatex компилирует – как в основном отчёте.
    # Прямая сборка PDF пандоком тянет шаблон с lmodern, которого здесь нет.
    cmd = ['pandoc', 'mini_forma_gotovo.md', '-s', '-o', 'mini_forma.tex',
           '--pdf-engine=xelatex',
           '-V', 'documentclass=article', '-V', 'fontsize=10pt',
           '-V', 'mainfont=DejaVu Serif', '-V', 'sansfont=DejaVu Sans',
           '-V', 'monofont=DejaVu Sans Mono',
           '-V', 'mainfontoptions=Scale=0.92', '-V', 'sansfontoptions=Scale=0.92',
           '-V', 'monofontoptions=Scale=0.82',
           '-H', os.path.join(BAZA, 'pre_otchet.tex'),
           '-B', os.path.join(BAZA, 'titul_mini.tex'),
           '--toc', '--toc-depth=2', '-f', 'markdown+raw_tex']
    r = subprocess.run(cmd, cwd=BAZA, capture_output=True, text=True)
    if r.returncode:
        print(r.stdout[-2000:]); print(r.stderr[-2000:]); sys.exit(1)
    # lmodern в этой установке нет, а pandoc вставляет его безусловно;
    # под xelatex он не нужен. Основной конвейер поступает так же.
    tp = os.path.join(BAZA, 'mini_forma.tex')
    tt = open(tp).read().replace('\n\\usepackage{lmodern}', '\n%\\usepackage{lmodern}')
    open(tp, 'w').write(tt)
    for _ in range(3):
        subprocess.run(['xelatex', '-interaction=nonstopmode', 'mini_forma.tex'],
                       cwd=BAZA, stdout=subprocess.DEVNULL)
    # контроль вёрстки: тот же, что и в основном отчёте
    log = os.path.join(BAZA, 'mini_forma.log')
    if os.path.exists(log):
        txt = open(log, errors='replace').read()
        pl = [float(m.group(1)) for m in re.finditer(r'Overfull \\hbox \(([0-9.]+)pt too wide\)', txt)]
        pl = [x for x in pl if x >= 1.0]
        print('  переполнений строк:', len(pl) if pl else 'нет')
    print('готово:', os.path.join(BAZA, 'mini_forma.pdf'))
