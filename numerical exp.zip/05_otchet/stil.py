"""Единый стиль рисунков отчёта. Все рисунки 350 dpi.

Стиль наследует оформление предыдущего отчёта: без верхней и правой рамок,
светлая сетка, зелёно-оранжевая палитра, шрифт 8.5 pt.

ПРАВИЛО РАЗМЕЩЕНИЯ ЛЕГЕНД. Легенда никогда не рисуется внутри осей. В прежнем
наборе легенды ставились с loc='upper left' и подобными, и на рядах Н3 и Н6
текст легенды перечёркивался кривыми, а на рисунке метрик через легенду
проходила штриховая линия эталона снизу. Здесь есть ровно два разрешённых
места:

    legenda_sverhu(...)   над областью рисования, в строку;
    legenda_sprava(...)   справа от области рисования, в столбец.

Обе функции резервируют место через параметры компоновки, а не накладывают
легенду поверх данных. Прямой вызов ax.legend() перехватывается и переводится
в размещение над осями, чтобы правило нельзя было обойти по недосмотру.
"""
import os, sys, pickle
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'sravnenie'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.size': 8.5, 'axes.linewidth': .7, 'legend.frameon': False,
    'savefig.dpi': 350, 'figure.dpi': 110, 'savefig.bbox': 'tight',
    'savefig.pad_inches': .05, 'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': True, 'grid.alpha': .25, 'grid.linewidth': .5,
    'font.family': 'DejaVu Sans'})

PAL = ['#2e7d32', '#ef6c00', '#c62828', '#5e35b1', '#0277bd', '#00838f', '#6d4c41']
SER = '#37474f'          # цвет предложенного метода
OUT = os.environ.get('RIS_PATH', '../risunki_350dpi')
os.makedirs(OUT, exist_ok=True)

LR = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6']
NR = ['N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
ORD = LR + NR
RUS = {k: k.replace('L', 'Л').replace('N', 'Н') for k in ORD}
BTC = ['btc', 'btcB', 'btcC']

B = os.environ.get('REZ_PATH', '../rezultaty')
RES = pickle.load(open(B + '/konveyer.pkl', 'rb'))
AV = pickle.load(open(B + '/avtor_metriki.pkl', 'rb'))
BIC = pickle.load(open(B + '/avtor_bic.pkl', 'rb'))
MS = pickle.load(open(B + '/mssv_rez.pkl', 'rb'))

# конвейеры: тег -> (краткое имя, цвет, аттестован)
KON = {
    'avtor':   ('предложенный метод',        SER,     True),
    'hmm_bic': ('BIC + гауссова HMM',        PAL[0],  True),
    'hmm_aic': ('AIC + гауссова HMM',        '#8d6e63', True),
    'hmm_icl': ('ICL + гауссова HMM',        PAL[1],  True),
    'hdphmm':  ('липкая HDP-HMM',            PAL[2],  True),
    'pelt':    ('PELT + кластеризация',      PAL[3],  True),
    'dp_hmm':  ('процесс Дирихле + HMM',     PAL[4],  True),
    'yadro':   ('BIC + ядерная $\\sigma_j(w)$', PAL[5], True),
    'smes':    ('HMM, смесевые эмиссии',     PAL[6],  True),
    'mssv':    ('MSSV',                      '#8e24aa', True),
    'mssv_pri_K': ('MSSV при подаренном $K$', '#ce93d8', False),
    'msgarch': ('MS-GARCH (не аттестован)',  '#9e9e9e', False),
}


def val(key, tag, pole):
    """Значение метрики pole для конвейера tag на ряде key."""
    import obshee as O
    if tag == 'avtor':
        return AV[key].get(pole)
    if tag == 'mssv':
        # ИСПРАВЛЕНО: раньше колонка K бралась из собственного выбора метода,
        # а метрики – из подгонки при ИСТИННОМ K. Это единственный конвейер,
        # которому дарился K, и это противоречило принципу «сравниваются
        # конвейеры целиком». Теперь всё берётся из собственного выбора.
        if key not in MS:
            return None
        b = {k: v['bic'] for k, v in MS[key].items()}
        Kv = min(b, key=b.get)
        return Kv if pole == 'K' else MS[key].get(Kv, {}).get(pole)
    if tag == 'mssv_pri_K':
        if key not in MS:
            return None
        Kist = O.dannye(key)['K']
        return Kist if pole == 'K' else MS[key].get(Kist, {}).get(pole)
    return RES[key].get(tag, {}).get(pole)


# --------------------------------------------------------------- легенды
_rodnoj_legend = matplotlib.axes.Axes.legend


def legenda_sverhu(ax, ncol=None, y=1.02, fontsize=6.8, handles=None, labels=None,
                   **kw):
    """Легенда НАД осями, в строку. Место резервируется компоновкой."""
    if handles is None:
        handles, labels = ax.get_legend_handles_labels()
    if not handles:
        return None
    if ncol is None:
        ncol = min(len(handles), 5 if len(handles) > 6 else len(handles))
    kw.setdefault('columnspacing', 1.1)
    kw.setdefault('handlelength', 1.3)
    kw.setdefault('handletextpad', .5)
    kw.setdefault('borderaxespad', 0.)
    return _rodnoj_legend(ax, handles, labels, loc='lower left',
                          bbox_to_anchor=(0., y, 1., .12), mode='expand',
                          ncol=ncol, fontsize=fontsize, frameon=False, **kw)


def legenda_sprava(ax, fontsize=6.8, handles=None, labels=None, **kw):
    """Легенда СПРАВА от осей, в столбец."""
    if handles is None:
        handles, labels = ax.get_legend_handles_labels()
    if not handles:
        return None
    kw.setdefault('handlelength', 1.3)
    kw.setdefault('handletextpad', .5)
    kw.setdefault('borderaxespad', 0.)
    return _rodnoj_legend(ax, handles, labels, loc='upper left',
                          bbox_to_anchor=(1.012, 1.0), ncol=1,
                          fontsize=fontsize, frameon=False, **kw)


def _legend_perehvat(self, *a, **kw):
    """Перехват ax.legend(): если место не задано явно наружу – ставим сверху.

    Проверяется bbox_to_anchor: наружным считается якорь, выходящий за
    единичный квадрат осей. Всё остальное (loc='upper left' и подобное)
    означает легенду внутри осей и заменяется размещением над ними.
    """
    b = kw.get('bbox_to_anchor')
    naruzhu = b is not None and (len(b) < 2 or b[0] >= 1.0 or b[1] >= 1.0
                                 or b[0] < 0 or b[1] < 0)
    if naruzhu:
        return _rodnoj_legend(self, *a, **kw)
    kw.pop('loc', None); kw.pop('bbox_to_anchor', None); kw.pop('mode', None)
    ncol = kw.pop('ncol', None)
    fs = kw.pop('fontsize', 6.8)
    return legenda_sverhu(self, ncol=ncol, fontsize=fs, **kw)


matplotlib.axes.Axes.legend = _legend_perehvat


# ------------------------------------------------- контроль налезания текста
def _pryamougolniki(fig):
    """Экранные прямоугольники всех подписей и текстовых объектов рисунка."""
    fig.canvas.draw()
    rend = fig.canvas.get_renderer()
    out = []
    for ax in fig.axes:
        elem = list(ax.texts) + ax.get_xticklabels() + ax.get_yticklabels()
        elem += [ax.title, ax.xaxis.label, ax.yaxis.label]
        for e in elem:
            try:
                if not e.get_visible() or not e.get_text().strip():
                    continue
                out.append((e.get_text(), e.get_window_extent(renderer=rend)))
            except Exception:
                continue
    return out


def proverit_nalezanie(fig, imya, dopusk=4.0):
    """Ищет пересекающиеся подписи и сообщает о них.

    Нужна потому, что налезание видно только после компоновки: до отрисовки
    размеры текста неизвестны. Возвращает список пар, которые пересекаются.
    """
    R = _pryamougolniki(fig)
    plohо = []
    for i in range(len(R)):
        for j in range(i + 1, len(R)):
            a, b = R[i][1], R[j][1]
            w = min(a.x1, b.x1) - max(a.x0, b.x0)
            h = min(a.y1, b.y1) - max(a.y0, b.y0)
            if w > dopusk and h > dopusk:
                plohо.append((R[i][0], R[j][0], round(w, 1), round(h, 1)))
    if plohо:
        print('  ВНИМАНИЕ [%s]: налезают подписи:' % imya, flush=True)
        for a, b, w, h in plohо[:8]:
            print('      «%s» × «%s» (%.0f×%.0f px)' % (a[:38], b[:38], w, h), flush=True)
    return plohо


NALEZANIYA = {}


def sohr(fig, imya, proverka=True):
    if proverka:
        NALEZANIYA[imya] = proverit_nalezanie(fig, imya)
    p = os.path.join(OUT, imya + '.png')
    fig.savefig(p, dpi=350)
    plt.close(fig)
    print('  сохранено:', imya, flush=True)
    return p


def est(imya):
    return os.path.exists(os.path.join(OUT, imya + '.png'))
