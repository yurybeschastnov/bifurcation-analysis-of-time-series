"""Перевод markdown-таблиц в LaTeX с ИЗМЕРЕННЫМИ ширинами колонок.

Зачем понадобилось. Pandoc берёт относительные ширины колонок из ширины ячеек
в исходном markdown и при отсутствии явных указаний раздаёт всем колонкам
поровну. В таблицах метрик колонок девять, поэтому первая получает одну девятую
ширины текста, то есть около 18 мм, тогда как в ней стоят «предложенный метод»
и «BIC + ядерная sigma_j(w)». Слово «предложенный» в 18 мм не помещается и
целиком выезжает в соседнюю колонку – в отчёте это выглядело как «предложенн0.989»,
слово и число напечатаны друг поверх друга. То же в таблице параметров, где
кортеж коэффициентов рвался посреди числа.

Что делается здесь.

  1. Ширина КАЖДОЙ ячейки измеряется настоящим xelatex тем же шрифтом и кеглем,
     каким набирается отчёт. Никаких оценок «полwidth на символ».
  2. Отдельно измеряется самое длинное неразрывное слово ячейки. Это нижняя
     граница ширины колонки: колонка уже неё обязана дать переполнение.
  3. Числовые колонки распознаются и прижимаются вправо; они не переносятся.
  4. Если естественные ширины укладываются в ширину текста, ставятся колонки
     естественной ширины и переносов нет вовсе. Если нет – сжимаются только
     текстовые колонки, не ниже длиннейшего слова. Если и это не помещается,
     понижается кегль таблицы.

Результат проверяется по журналу LaTeX: Overfull \\hbox в таблицах быть не должно.
"""
import os, re, subprocess, tempfile
import numpy as np

TEKST_MM = 166.0                      # ширина текста: A4 минус поля 2,2 см
PT_V_MM = 0.3514598
TEKST_PT = TEKST_MM / PT_V_MM

# Измерять надо ТЕМ ЖЕ шрифтом, каким набирается отчёт. DejaVu Serif заметно
# шире Latin Modern, и измерение шрифтом по умолчанию занижает ширины на
# десятки процентов – колонки выходят узкими, и переполнение возвращается.
PREAMBULA_MERA = r"""
\documentclass[10pt]{article}
\usepackage{amsmath,amssymb}
\usepackage{fontspec}
\setmainfont{DejaVu Serif}[Scale=0.92]
\setsansfont{DejaVu Sans}[Scale=0.92]
\setmonofont{DejaVu Sans Mono}[Scale=0.82]
\usepackage{unicode-math}
\setmathfont{latinmodern-math.otf}
\setmathfont{DejaVu Serif}[range={up/{greek,Greek},bfup/{greek,Greek}}]
\usepackage{booktabs,array}
\begin{document}
"""


def md_v_tex(s):
    """Markdown-разметка ячейки в LaTeX.

    Математика прячется под метки ДО разбора разметки, иначе выделение,
    охватывающее формулу, не распознаётся: в ячейке «**оракул бьёт $K=1$**»
    звёздочки попадали в разные куски и оставались в тексте как есть.
    """
    mat = []

    def spryatat(m):
        mat.append(m.group(0))
        return '\x00%d\x00' % (len(mat) - 1)

    s = re.sub(r'\$[^$]*\$', spryatat, s)
    s = s.replace('\\', '\\textbackslash{}')
    s = re.sub(r'\*\*(.+?)\*\*', r'\\textbf{\1}', s)
    s = re.sub(r'(?<!\*)\*([^*]+?)\*(?!\*)', r'\\emph{\1}', s)
    s = s.replace('&', '\\&').replace('%', '\\%').replace('#', '\\#')
    s = s.replace('_', '\\_')
    for i, m in enumerate(mat):
        s = s.replace('\x00%d\x00' % i, m)
    return s


def slova(s):
    """Разбиение ячейки на неразрывные куски: математика целиком, остальное по пробелам."""
    kuski = re.split(r'(\$[^$]*\$)', s)
    out = []
    for i, k in enumerate(kuski):
        if i % 2 == 1:
            out.append(k)
        else:
            out += [w for w in k.split() if w]
    return out or ['']


_KESH = {}


def izmerit(stroki):
    """Ширина каждой строки в пунктах, измеренная настоящим xelatex."""
    nov = [s for s in dict.fromkeys(stroki) if s not in _KESH]
    if nov:
        with tempfile.TemporaryDirectory() as kat:
            tex = [PREAMBULA_MERA,
                   r'\newwrite\vyhod', r'\immediate\openout\vyhod=shiriny.txt']
            for i, s in enumerate(nov):
                tex.append(r'\sbox0{%s}\immediate\write\vyhod{%d \the\wd0}' % (s, i))
            tex.append(r'\immediate\closeout\vyhod')
            tex.append(r'\mbox{}\end{document}')
            open(os.path.join(kat, 'm.tex'), 'w').write('\n'.join(tex))
            subprocess.run(['xelatex', '-interaction=nonstopmode', 'm.tex'],
                           cwd=kat, capture_output=True)
            p = os.path.join(kat, 'shiriny.txt')
            if not os.path.exists(p):
                raise RuntimeError('измерение ширин не удалось: xelatex не создал файл')
            for ln in open(p):
                q = ln.split()
                if len(q) == 2 and q[1].endswith('pt'):
                    _KESH[nov[int(q[0])]] = float(q[1][:-2])
    return {s: _KESH.get(s, 0.0) for s in stroki}


CHISLO = re.compile(r'^[-+±]?\d+([.,]\d+)?(\s*[/±…]\s*\d+([.,]\d+)?)?$')
# ячейка целиком в математике («$-10{,}549$») ведёт себя как число: не переносится
MAT_CELIKOM = re.compile(r'^\$[^$]*\$$')


def chislovaya(kletki):
    """Колонка числовая, если каждая непустая ячейка – число (возможно полужирное)."""
    est = False
    for k in kletki:
        c = re.sub(r'\*\*|\*', '', k).strip()
        if c in ('', '–', '–', '-'):
            continue
        est = True
        if not (CHISLO.match(c) or MAT_CELIKOM.match(c)):
            return False
    return est


def razdelit_stroku(x):
    """Разбиение строки таблицы по '|' с защитой математики.

    Вертикальная черта встречается внутри формул («\\max|\\Delta Y|»), и наивное
    разбиение порождало лишние пустые колонки: таблица из трёх колонок
    становилась пятиколоночной, а лишние пустые колонки выдавливали таблицу
    за поле.
    """
    mat = []

    def spryatat(m):
        mat.append(m.group(0))
        return '\x01%d\x01' % (len(mat) - 1)

    z = re.sub(r'\$[^$]*\$', spryatat, x)
    kletki = [c.strip() for c in z.strip().strip('|').split('|')]
    out = []
    for c in kletki:
        for i, m in enumerate(mat):
            c = c.replace('\x01%d\x01' % i, m)
        out.append(c)
    return out


def razobrat(md):
    """Строки markdown-таблицы -> (заголовок, тело)."""
    ln = [x.strip() for x in md.strip().split('\n') if x.strip().startswith('|')]
    ryady = []
    for x in ln:
        if re.match(r'^\|[\s:|-]+\|$', x):
            continue
        ryady.append(razdelit_stroku(x))
    n = max(len(r) for r in ryady)
    ryady = [r + [''] * (n - len(r)) for r in ryady]
    return ryady[0], ryady[1:]


def tablica_v_latex(md, podpis, kegl='small', metka=None):
    """Полный LaTeX-код таблицы с измеренными ширинами колонок."""
    zag, telo = razobrat(md)
    ncol = len(zag)
    # шапка набирается полужирным, поэтому и измеряться должна полужирной:
    # иначе колонка выходит уже своей шапки и та выезжает в соседнюю
    zag_tex = [('\\textbf{%s}' % md_v_tex(c)) if c else '' for c in zag]
    kletki = [zag_tex] + [[md_v_tex(c) for c in r] for r in telo]

    # измеряем целые ячейки и самые длинные слова
    vse = [c for r in kletki for c in r]
    vse_slova = [md_v_tex(w) for r in telo for c in r for w in slova(c)]
    vse_slova += ['\\textbf{%s}' % md_v_tex(w) for c in zag for w in slova(c)]
    W = izmerit(vse + vse_slova)

    polnaya, minimum = [], []
    for j in range(ncol):
        polnaya.append(max(W.get(kletki[i][j], 0.0) for i in range(len(kletki))))
        m = max([W.get('\\textbf{%s}' % md_v_tex(w), 0.0) for w in slova(zag[j])] or [0.0])
        for r in telo:
            for w in slova(r[j]):
                m = max(m, W.get(md_v_tex(w), 0.0))
        minimum.append(m)
    polnaya = np.array(polnaya); minimum = np.array(minimum)

    chisl = [chislovaya([r[j] for r in telo]) for j in range(ncol)]
    # числовая колонка не переносится никогда: её минимум равен полной ширине
    minimum = np.where(chisl, polnaya, minimum)

    KEGLI = [('small', 0.90), ('footnotesize', 0.80), ('scriptsize', 0.68)]
    dostup = {k: v for k, v in KEGLI}
    mash = dostup.get(kegl, 0.90)
    sep = 6.0                                    # 2*\tabcolsep при \tabcolsep=3pt
    ZAPAS = 1.04                                 # запас на неточность измерения
    for imya, m in KEGLI[[k for k, _ in KEGLI].index(kegl):]:
        mash = m
        zapas = TEKST_PT - sep * ncol
        if (minimum * mash * 1.04).sum() <= zapas:
            kegl = imya
            break
    else:
        kegl, mash = KEGLI[-1]

    p = polnaya * mash * ZAPAS
    mn = minimum * mash * ZAPAS
    zapas = TEKST_PT - sep * ncol
    if p.sum() <= zapas:
        shir = p                                  # всё помещается естественно
    else:
        # сжимаем только те колонки, которые можно переносить
        shir = p.copy()
        gibk = np.array([not c for c in chisl])
        izb = p.sum() - zapas
        zap_gibk = (p - mn)[gibk].sum()
        if zap_gibk > 0:
            shir[gibk] = p[gibk] - izb * (p - mn)[gibk] / zap_gibk
        shir = np.maximum(shir, mn)
        if shir.sum() > zapas:                    # крайний случай – режем всё
            shir = shir * zapas / shir.sum()

    spec = []
    for j in range(ncol):
        if chisl[j]:
            spec.append('r')
        else:
            spec.append('>{\\raggedright\\arraybackslash}p{%.2fpt}' % shir[j])

    L = [r'\begin{table}[H]', r'\centering', r'\%s' % kegl,
         r'\setlength{\tabcolsep}{3pt}', r'\renewcommand{\arraystretch}{1.12}',
         r'\begin{tabular}{%s}' % ''.join(spec), r'\toprule']
    L.append(' & '.join(kletki[0]) + r' \\')
    L.append(r'\midrule')
    for r in kletki[1:]:
        L.append(' & '.join(r) + r' \\')
    L.append(r'\bottomrule')
    L.append(r'\end{tabular}')
    L.append(r'\caption{%s}' % md_v_tex(podpis))
    if metka:
        L.append(r'\label{%s}' % metka)
    L.append(r'\end{table}')
    return '\n'.join(L)


def tablica_v_latex_bez_podpisi(md, kegl='small'):
    """Та же вёрстка, но без \\caption: для перечней внутри текста, которые не
    должны попадать в общую нумерацию таблиц с результатами."""
    polnyj = tablica_v_latex(md, '', kegl=kegl)
    return '\n'.join(x for x in polnyj.split('\n') if not x.startswith('\\caption'))
