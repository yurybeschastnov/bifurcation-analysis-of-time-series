"""Генерация всех таблиц отчёта в markdown. Числа берутся только из
последних результатов сравнения (konveyer.pkl, avtor_metriki.pkl, mssv_rez.pkl).
"""
import sys, pickle, os
import numpy as np
from stil import *
import obshee as O

CHEST = pickle.load(open(os.path.join(os.environ.get('REZ_PATH', '.'),
                                      'zapas_chestnyi.pkl'), 'rb'))

POR_L = ['avtor', 'pelt', 'hmm_bic', 'hmm_aic', 'yadro', 'hdphmm', 'hmm_icl', 'dp_hmm']
POR_N = ['avtor', 'dp_hmm', 'hmm_bic', 'hmm_aic', 'yadro', 'hmm_icl', 'smes', 'hdphmm',
         'pelt', 'mssv', 'msgarch']
IMYA = {t: KON[t][0].replace('$\\sigma_j(w)$', '$\\sigma_j(w)$') for t in KON}


def zhirn(s, cond):
    return '**%s**' % s if cond else s


def tab_K(gr, por, zag):
    ist = [O.dannye(r)['K'] for r in gr]
    L = ['### %s\n' % zag]
    L.append('| конвейер | ' + ' | '.join(RUS[r] for r in gr) + ' | верно |')
    L.append('|---|' + '---|' * (len(gr) + 1))
    L.append('| *истинное $K$* | ' + ' | '.join('*%d*' % k for k in ist) + ' | |')
    for tg in por:
        v = [val(r, tg, 'K') for r in gr]
        if not any(x is not None for x in v):
            continue
        ok = sum(1 for a, b in zip(v, ist) if a == b)
        n = sum(1 for a in v if a is not None)
        cell = []
        for a, b in zip(v, ist):
            if a is None:
                cell.append('–')
            elif a == b:
                cell.append(str(a))
            else:
                cell.append('**%d**' % a)
        L.append('| %s | %s | %s |' % (IMYA[tg], ' | '.join(cell),
                                       zhirn('%d/%d' % (ok, n), tg == 'avtor')))
    L.append('')
    L.append('Полужирным в клетках выделены ошибочные оценки.\n')
    return '\n'.join(L)


def tab_metr(gr, por, pole, zag, fmt='%.3f', luchshe='max', nizhe=False):
    L = ['### %s\n' % zag]
    L.append('| конвейер | ' + ' | '.join(RUS[r] for r in gr) + ' | медиана |')
    L.append('|---|' + '---|' * (len(gr) + 1))
    # лучший в каждом столбце
    best = {}
    for j, r in enumerate(gr):
        vv = [(val(r, t, pole), t) for t in por if val(r, t, pole) is not None
              and KON[t][2]]
        if vv:
            best[j] = (max if luchshe == 'max' else min)(vv)[1]
    for tg in por:
        v = [val(r, tg, pole) for r in gr]
        if not any(x is not None for x in v):
            continue
        vv = [x for x in v if x is not None]
        cell = []
        for j, a in enumerate(v):
            if a is None:
                cell.append('–')
            else:
                cell.append(zhirn(fmt % a, best.get(j) == tg))
        L.append('| %s | %s | %s |' % (IMYA[tg], ' | '.join(cell),
                                       zhirn(fmt % np.median(vv), tg == 'avtor')))
    if nizhe:
        rv = [min(RES[r]['rv'].values()) for r in gr]
        L.append('| *эталон снизу: локальная RV* | ' +
                 ' | '.join('*%s*' % (fmt % x) for x in rv) +
                 ' | *%s* |' % (fmt % np.median(rv)))
    L.append('')
    return '\n'.join(L)


def tab_svod():
    L = ['### Сводные показатели по обоим экспериментам\n']
    L.append('| конвейер | $K$ на Л | $K$ на Н | $K$ всего | ARI, медиана | '
             '$E_{L2}$, медиана |')
    L.append('|---|---|---|---|---|---|')
    for tg in ['avtor', 'hmm_bic', 'hmm_aic', 'yadro', 'pelt', 'dp_hmm', 'hdphmm',
               'hmm_icl', 'smes', 'mssv']:
        ok = []; tot = []
        for gr in (LR, NR):
            v = [val(r, tg, 'K') for r in gr]
            ist = [O.dannye(r)['K'] for r in gr]
            ok.append(sum(1 for a, b in zip(v, ist) if a == b))
            tot.append(sum(1 for a in v if a is not None))
        ari = [val(r, tg, 'ari') for r in ORD]
        l2 = [val(r, tg, 'l2') for r in ORD]
        ari = [x for x in ari if x is not None]
        l2 = [x for x in l2 if x is not None]
        f = lambda a, b: ('%d/%d' % (a, b)) if b else '–'
        L.append('| %s | %s | %s | %s | %.3f | %.3f |' % (
            IMYA[tg], f(ok[0], tot[0]), f(ok[1], tot[1]),
            zhirn(f(sum(ok), sum(tot)), tg == 'avtor'),
            np.median(ari), np.median(l2)))
    L.append('')
    return '\n'.join(L)


def tab_bic():
    """Запасы информационного критерия.

    ИСПРАВЛЕНО: запас при N=K+1 считается по ДОСТИЖИМОМУ правдоподобию, а не
    по сохранённой подгонке. Модель с K+1 ветвями всегда способна воспроизвести
    K-ветвевую (лишняя ветвь выводится за полосу волатильности и нигде не
    допустима), поэтому sup ll(K+1) >= ll(K), и запас при N=K+1 ограничен
    сверху штрафом p log n. Сохранённые подгонки этого предела местами не
    достигали, отчего прежняя таблица завышала запас до +42,1."""
    L = ['### Запасы информационного критерия предложенного метода\n']
    L.append('| ряд | $K$ | $\\Delta$BIC при $N=K-1$ | при $N=K+1$ | при $N=K+2$ | '
             'минимальный запас |')
    L.append('|---|---|---|---|---|---|')
    for r in ORD:
        b = dict(BIC[r]['bic']); K = BIC[r]['K']
        if r in CHEST:
            b[K + 1] = b[K] + CHEST[r]
        f = lambda N: ('%+.1f' % (b[N] - b[K])) if N in b else '–'
        zap = min(b[N] - b[K] for N in b if N != K)
        L.append('| %s | %d | %s | %s | %s | **%+.1f** |'
                 % (RUS[r], K, f(K - 1), f(K + 1), f(K + 2), zap))
    L.append('')
    return '\n'.join(L)


def tab_ryady():
    L = ['### Параметры порождающих моделей\n']
    L.append('| ряд | $K$ | тип ветви | коэффициенты $(c_j,\\,a_j,\\,b_j[,\\,r_j])$ | '
             'переключений | $\\sigma$: мин…макс |')
    L.append('|---|---|---|---|---|---|')
    for r in ORD:
        d = O.dannye(r)
        si = O.sigma_ist(d)
        ко = ' / '.join('(' + ', '.join('%.2f' % x for x in g) + ')' for g in d['branches'])
        L.append('| %s | %d | %s | %s | %d | %.2f…%.2f |' % (
            RUS[r], d['K'], 'аффинная' if d['kind'] == 'aff' else 'кубическая',
            ко, int((np.diff(d['lab']) != 0).sum()), si.min(), si.max()))
    L.append('')
    return '\n'.join(L)


def tab_mssv():
    L = ['### Оракульный тест переключающейся стохастической волатильности\n']
    L.append('| ряд | $K$ ист. | BIC при $K=1$ | BIC при $K_{ист}$ (подгонка) | '
             'BIC при $K_{ист}$ (оракул) | вывод |')
    L.append('|---|---|---|---|---|---|')
    ORAK = pickle.load(open(os.path.join(
        os.environ.get('REZ_PATH', '.'), 'mssv_orakul.pkl'), 'rb'))
    for r in ['N1', 'N2', 'N3', 'N6']:
        K = O.dannye(r)['K']
        b1 = MS[r][1]['bic']; bK = MS[r][K]['bic']; bo = ORAK[r]['bic']
        vyv = ('**оракул бьёт $K=1$** – отказ оценивания' if bo < b1
               else '$K=1$ выигрывает честно')
        L.append('| %s | %d | %.1f | %.1f | %.1f ± %.1f | %s |'
                 % (RUS[r], K, b1, bK, bo, ORAK[r]['sd'], vyv))
    L.append('')
    return '\n'.join(L)


KRAT = {'hmm_bic': 'HMM/BIC', 'hmm_icl': 'HMM/ICL', 'hdphmm': 'HDP-HMM',
        'pelt': 'PELT', 'dp_hmm': 'Дирихле', 'yadro': 'ядерная',
        'smes': 'HMM/смеси', 'mssv': 'MSSV'}


def tab_po_ryadam(gr, zag):
    ATT = [t for t in KON if t != 'avtor' and KON[t][2]]

    def dostupno(r):
        # ИСПРАВЛЕНО: раньше знаменатель был len(ATT)=8 независимо от того,
        # сколько конвейеров реально просчитано. На рядах Л их шесть
        # (smes и msgarch идут только на Н), MSSV есть лишь на четырёх Н.
        return [t for t in ATT if val(r, t, 'K') is not None]

    def luch(r, pole, minim=False):
        v = {t: val(r, t, pole) for t in ATT if val(r, t, pole) is not None}
        b = (min if minim else max)(v, key=v.get)
        return b, v[b]

    L = ['### %s\n' % zag]
    L.append('| ряд | $K$ | эталонов с верным $K$ | ARI: метод / лучший эталон | '
             'исход | $E_{L2}$: метод / лучший эталон | исход |')
    L.append('|---|---|---|---|---|---|---|')
    pob = [0, 0, 0]; pob2 = [0, 0, 0]
    for r in gr:
        Ki = O.dannye(r)['K']; Km = val(r, 'avtor', 'K')
        dost = dostupno(r)
        ug = sum(1 for t in dost if val(r, t, 'K') == Ki)
        b, vb = luch(r, 'ari'); a = val(r, 'avtor', 'ari')
        b2, vb2 = luch(r, 'l2', minim=True); l = val(r, 'avtor', 'l2')
        zn = lambda d: ('**выигрыш**' if d > 1e-3 else ('проигрыш' if d < -1e-3 else 'ничья'))
        i1 = zn(a - vb); i2 = zn(vb2 - l)
        for i, s_ in ((0, i1), (1, i2)):
            (pob if i == 0 else pob2)[0 if 'выигрыш' in s_ else (1 if s_ == 'ничья' else 2)] += 1
        L.append('| %s | %d %s | %d из %d | %.3f / %.3f (%s) | %s | %.3f / %.3f (%s) | %s |'
                 % (RUS[r], Km, 'верно' if Km == Ki else '**ошибка**', ug, len(dost),
                    a, vb, KRAT.get(b, b), i1,
                    l, vb2, KRAT.get(b2, b2), i2))
    L.append('')
    L.append('**Итог по группе.** Число режимов: %d верно из %d. '
             'ARI: выигрыш на %d рядах, ничья на %d, проигрыш на %d. '
             '$E_{L2}$: выигрыш на %d, ничья на %d, проигрыш на %d.\n'
             % (sum(1 for r in gr if val(r, 'avtor', 'K') == O.dannye(r)['K']), len(gr),
                pob[0], pob[1], pob[2], pob2[0], pob2[1], pob2[2]))
    return '\n'.join(L)


if __name__ == '__main__':
    ch = []
    ch.append(tab_ryady())
    ch.append(tab_K(LR, POR_L, 'Эксперимент Л. Определение числа режимов'))
    ch.append(tab_metr(LR, POR_L, 'acc', 'Эксперимент Л. Доля верных режимных меток'))
    ch.append(tab_metr(LR, POR_L, 'ari', 'Эксперимент Л. Скорректированный индекс Ранда'))
    ch.append(tab_metr(LR, POR_L, 'l2', 'Эксперимент Л. Относительная ошибка волатильности $E_{L2}$',
                       luchshe='min', nizhe=True))
    ch.append(tab_K(NR, POR_N, 'Эксперимент Н. Определение числа режимов'))
    ch.append(tab_metr(NR, POR_N, 'acc', 'Эксперимент Н. Доля верных режимных меток'))
    ch.append(tab_metr(NR, POR_N, 'ari', 'Эксперимент Н. Скорректированный индекс Ранда'))
    ch.append(tab_metr(NR, POR_N, 'l2', 'Эксперимент Н. Относительная ошибка волатильности $E_{L2}$',
                       luchshe='min', nizhe=True))
    ch.append(tab_po_ryadam(LR, 'Эксперимент Л. Сравнение по рядам с наилучшим эталоном'))
    ch.append(tab_po_ryadam(NR, 'Эксперимент Н. Сравнение по рядам с наилучшим эталоном'))
    ch.append(tab_svod())
    ch.append(tab_bic())
    ch.append(tab_mssv())
    open(os.path.join(os.environ.get('OTCH_PATH', os.path.dirname(os.path.abspath(__file__))), 'tablicy.md'), 'w').write('\n'.join(ch))
    print('таблиц сгенерировано:', len(ch))
