"""Таблицы раздела о биткойне.

Все числа берутся из btc_rez.pkl и считаются здесь, а не вписываются в текст.
Это то же требование, что и для остальных таблиц отчёта: вписанные константы
уже один раз разошлись с результатами прогонов.
"""
import os, sys, pickle
import numpy as np
from stil import *
import btc_kuski as BK
import ris_btc as RB


def tab_btc_uchastki():
    L = ['### Участки биткойна: отбор и постановка\n']
    L.append('| участок | ряд | точки | $n$ | режимов видно | уровни $\\sigma$ при отборе |')
    L.append('|---|---|---|---|---|---|')
    import poisk2 as PS
    import markov as MK
    for q in BK.KUSKI:
        d = BK.kusok(q['tag'])
        o = PS.hmm_priznaki(d['Y'], d['dt'], q['vid'], ntry=3, n_iter=120)
        sig = ' / '.join('%.2f' % x for x in o['sigma']) if o else '–'
        L.append('| %s | %s | %d…%d | %d | %d | %s |'
                 % (q['tag'], q['ryad'], q['i0'], q['i0'] + q['L'], d['n'],
                    q['vid'], sig))
    L.append('')
    L.append('Уровни в последнем столбце – марковская модель переключений, '
             'применённая ПРИ ОТБОРЕ участков. Это не результат и не эталон, '
             'а инструмент отбора: он отвечает на вопрос, видно ли режимы глазом.\n')
    return '\n'.join(L)


def tab_btc_vybor():
    S = RB.svodka()
    L = ['### Биткойн: что выбрал предложенный метод\n']
    L.append('| участок | видно | $N$, класс | $\\hat K$, BIC + HMM | переключений | '
             'медианы $\\sigma_j$ | кривизны $r_j$ |')
    L.append('|---|---|---|---|---|---|---|')
    sovp = 0
    kub = 0
    for r in S:
        sovp += (r['N'] == r['vid'])
        kub += (r['kind'] == 'cub')
        L.append('| %s | %d | **%d**, %s | %d | %d | %s | %s |'
                 % (r['tag'], r['vid'], r['N'], RB.KLASS[r['kind']], r['K_hmm'],
                    r['perekl'], ' / '.join('%.2f' % x for x in r['sigma']),
                    ' / '.join('%.2f' % x for x in r['r']) if r['r'] else '–'))
    L.append('')
    L.append('Кубический класс ветви выбран на %d участках из %d. Число ветвей '
             'совпало с числом режимов, видимых на глаз, на %d участках из %d. '
             'На остальных метод берёт на одну ветвь больше. Это НЕ доля верных '
             'ответов: верного ответа на реальных данных не существует.\n'
             % (kub, len(S), sovp, len(S)))
    return '\n'.join(L)


def tab_btc_bic():
    L = ['### Биткойн: запасы информационного критерия\n']
    L.append('| участок | выбрано | $\\Delta$BIC до $N-1$ | до $N+1$ | '
             'до лучшего в другом классе | минимальный запас |')
    L.append('|---|---|---|---|---|---|')
    for q in BK.KUSKI:
        v = RB.vybor(q['tag'])
        b = v['bic']
        best = b[(v['kind'], v['N'])]['bic']
        def d(kind, N):
            k = (kind, N)
            return ('%+.1f' % (b[k]['bic'] - best)) if k in b else '–'
        drug = 'cub' if v['kind'] == 'aff' else 'aff'
        vd = [b[k]['bic'] for k in b if k[0] == drug]
        zap = min(x['bic'] for k, x in b.items() if k != (v['kind'], v['N'])) - best
        L.append('| %s | $N=%d$, %s | %s | %s | %s | **%+.1f** |'
                 % (q['tag'], v['N'], RB.KLASS[v['kind']],
                    d(v['kind'], v['N'] - 1), d(v['kind'], v['N'] + 1),
                    ('%+.1f' % (min(vd) - best)) if vd else '–', zap))
    L.append('')
    L.append('Запас – насколько информационный критерий у выбранного решения '
             'лучше ближайшего соперника. Соперники берутся и по числу ветвей, '
             'и по классу ветви: класс метод выбирает тем же критерием.\n')
    return '\n'.join(L)


if __name__ == '__main__':
    ch = [tab_btc_uchastki(), tab_btc_vybor(), tab_btc_bic()]
    p = os.path.join(os.environ.get('OTCH_PATH', os.path.dirname(os.path.abspath(__file__))),
                     'tablicy_btc.md')
    open(p, 'w').write('\n'.join(ch))
    print('таблиц по биткойну:', len(ch))
