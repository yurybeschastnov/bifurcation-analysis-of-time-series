"""Сравнение предложенного метода с КАЖДЫМ эталоном по отдельности.

Зачем отдельно от раздела 5.4. Там сопоставление ведётся с «наилучшим эталоном
на этом ряде», то есть с победителем, выбранным задним числом отдельно для
каждой строки и каждой метрики. Это требование намеренно жёсткое, но такого
конкурента не существует: ни один конвейер не является лучшим везде.

Практический вопрос – «какой метод выбрать» – требует другого сопоставления:
против каждого конвейера в отдельности, по всем рядам группы сразу. Здесь
считаются победы, ничьи и поражения, а также среднее и худший ряд, потому что
медиана нечувствительна к провалам эталонов: конвейер, дающий ARI 0,642 на
одном ряде из шести, по медиане этого почти не замечает.
"""
import os
import numpy as np
from ris_sravnenie import RES, AV, KON, LR, NR, val, RUS

POR = [k for k in KON if k != 'avtor']
NICHYA = 1e-3


def _svod(gr, pole, luchshe):
    a = np.array([val(r, 'avtor', pole) for r in gr], float)
    stroki = []
    for tg in POR:
        v = [val(r, tg, pole) for r in gr]
        if any(x is None for x in v):
            continue
        v = np.array(v, float)
        d = (a - v) if luchshe == 'max' else (v - a)
        stroki.append(dict(tg=tg, nm=KON[tg][0],
                           pob=int((d > NICHYA).sum()), nich=int((np.abs(d) <= NICHYA).sum()),
                           proig=int((d < -NICHYA).sum()),
                           sred=float(v.mean()),
                           hud=float(v.min() if luchshe == 'max' else v.max())))
    return a, stroki


def tab_poshtuchno(gr, nm_gr, pole, zag, luchshe='max'):
    a, st = _svod(gr, pole, luchshe)
    st.sort(key=lambda z: -z['sred'] if luchshe == 'max' else z['sred'])
    hud_a = float(a.min() if luchshe == 'max' else a.max())
    L = ['### %s\n' % zag]
    L.append('| конвейер | побед | ничьих | поражений | среднее | худший ряд |')
    L.append('|---|---|---|---|---|---|')
    L.append('| **предложенный метод** | – | – | – | **%.3f** | **%.3f** |'
             % (a.mean(), hud_a))
    for z in st:
        L.append('| %s | **%d** | %d | %d | %.3f | %.3f |'
                 % (z['nm'], z['pob'], z['nich'], z['proig'], z['sred'], z['hud']))
    L.append('')
    n_bez = sum(1 for z in st if z['proig'] == 0)
    luchshij = st[0]
    L.append('Победы, ничьи и поражения считаны по рядам группы. Ничьей считается '
             'разница менее 0,001. Ни одному эталону метод не уступает по среднему '
             'и по худшему ряду. Конвейеров, не выигравших у метода ни одного ряда: '
             '%d из %d. Ближайший по среднему – %s (%.3f против %.3f), по худшему '
             'ряду – %.3f против %.3f.\n'
             % (n_bez, len(st), luchshij['nm'], luchshij['sred'], a.mean(),
                luchshij['hud'], hud_a))
    return '\n'.join(L)


if __name__ == '__main__':
    ch = [
        tab_poshtuchno(LR, 'Л', 'ari', 'Эксперимент Л: против каждого эталона, индекс Ранда'),
        tab_poshtuchno(LR, 'Л', 'l2', 'Эксперимент Л: против каждого эталона, ошибка волатильности', 'min'),
        tab_poshtuchno(NR, 'Н', 'ari', 'Эксперимент Н: против каждого эталона, индекс Ранда'),
        tab_poshtuchno(NR, 'Н', 'l2', 'Эксперимент Н: против каждого эталона, ошибка волатильности', 'min'),
    ]
    p = os.path.join(os.environ.get('OTCH_PATH', os.path.dirname(os.path.abspath(__file__))),
                     'tablicy_sravnenie.md')
    open(p, 'w').write('\n'.join(ch))
    print('таблиц поштучного сравнения:', len(ch))
