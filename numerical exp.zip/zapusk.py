#!/usr/bin/env python3
"""Единая точка входа для всего вычислительного эксперимента.

Настраивает пути так, чтобы модули предложенного метода, данные и результаты
находились автоматически, и запускает выбранный этап.

    python zapusk.py spisok                 перечень этапов
    python zapusk.py avtor                  результаты предложенного метода
    python zapusk.py konveyer L1 L2 L3      эталоны на указанных рядах
    python zapusk.py mssv N1                MSSV на указанном ряде
    python zapusk.py kalibrovka hmm         аттестация эталонов
    python zapusk.py perebor msg            сверка правдоподобий
    python zapusk.py risunki                все рисунки, 350 dpi
    python zapusk.py tablicy                все таблицы
    python zapusk.py otchet                 сборка отчёта (нужны pandoc и xelatex)
    python zapusk.py vse                    всё подряд (несколько часов)
"""
import os, sys, subprocess

KOREN = os.path.dirname(os.path.abspath(__file__))
METOD = os.path.join(KOREN, '01_metod')
DANNYE = os.path.join(KOREN, '02_dannye')
SRAV = os.path.join(KOREN, '03_sravnenie')
ATT = os.path.join(KOREN, '04_attestaciya')
OTCH = os.path.join(KOREN, '05_otchet')
REZ = os.path.join(KOREN, '06_rezultaty')
RIS = os.path.join(KOREN, '07_risunki_350dpi')

# модули предложенного метода лежат в трёх подкаталогах и импортируются плоско
PUT = [os.path.join(METOD, x) for x in ('baza', 'yadro', 'prognon')]
PUT += [SRAV, ATT, OTCH]

SREDA = dict(os.environ)
SREDA['PYTHONPATH'] = os.pathsep.join(PUT + [SREDA.get('PYTHONPATH', '')])
SREDA['RYADY_PATH'] = DANNYE
SREDA['REZ_PATH'] = REZ
SREDA['RIS_PATH'] = RIS
SREDA['MSDE_PATH'] = os.path.join(METOD, 'baza')
SREDA['MSDE_REZ'] = REZ

ETAPY = {
    'avtor':      (SRAV, 'avtor.py',        'результаты предложенного метода, включая проверку N=K+2'),
    'konveyer':   (SRAV, 'konveyer.py',     'эталоны на рядах (укажите ряды: L1 L2 ...)'),
    'mssv':       (SRAV, 'mssv_progon.py',  'переключающаяся стохастическая волатильность'),
    'kalibrovka': (ATT,  'kalibrovka.py',   'аттестация эталонов (hmm | pelt | msg | lozh)'),
    'perebor':    (ATT,  'perebor.py',      'сверка правдоподобий (msg | mssv)'),
    'ris_dannye': (OTCH, 'ris_dannye.py',   'рисунки рядов (укажите ряды или sigma / drayver)'),
    'ris_sravn':  (OTCH, 'ris_sravnenie.py','рисунки сравнения конвейеров'),
    'ris_kalib':  (OTCH, 'ris_kalib.py',    'рисунки аттестации и контрольного опыта'),
    'tablicy':    (OTCH, 'tablicy.py',      'генерация всех таблиц отчёта'),
    'sborka':     (OTCH, 'sborka.py',       'сборка markdown отчёта'),
}

RYADY_L = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6']
RYADY_N = ['N1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7']
VSE_RYADY = RYADY_L + RYADY_N


def zapust(kat, fajl, argv=()):
    print('\n>>> %s %s' % (fajl, ' '.join(argv)), flush=True)
    k = subprocess.run([sys.executable, os.path.join(kat, fajl)] + list(argv),
                       cwd=kat, env=SREDA)
    if k.returncode:
        print('!!! %s завершился с кодом %d' % (fajl, k.returncode))
    return k.returncode


def risunki():
    for r in VSE_RYADY:
        zapust(OTCH, 'ris_dannye.py', [r, '--zanovo'])
    zapust(OTCH, 'ris_dannye.py', ['sigma', 'drayver'])
    zapust(OTCH, 'ris_sravnenie.py')
    zapust(OTCH, 'ris_kalib.py')


def otchet():
    zapust(OTCH, 'tablicy.py')
    zapust(OTCH, 'sborka.py')
    md = os.path.join(OTCH, 'otchet.md')
    tex = os.path.join(OTCH, 'otchet.tex')
    cmd = ['pandoc', md, '-s', '-o', tex, '--pdf-engine=xelatex',
           '-V', 'documentclass=article', '-V', 'fontsize=10pt',
           '-V', 'mainfont=DejaVu Serif', '-V', 'sansfont=DejaVu Sans',
           '-V', 'monofont=DejaVu Sans Mono',
           '-V', 'mainfontoptions=Scale=0.92', '-V', 'sansfontoptions=Scale=0.92',
           '-V', 'monofontoptions=Scale=0.82',
           '-H', os.path.join(OTCH, 'pre_otchet.tex'), '--toc', '--toc-depth=2']
    if subprocess.run(cmd, cwd=OTCH).returncode:
        print('!!! pandoc недоступен или завершился с ошибкой'); return
    s = open(tex).read().replace('\\usepackage{lmodern}', '%\\usepackage{lmodern}')
    tit = os.path.join(OTCH, 'titul.tex')
    if os.path.exists(tit):
        s = s.replace('\\begin{document}', '\\begin{document}\n' + open(tit).read(), 1)
    open(tex, 'w').write(s)
    for _ in range(3):
        subprocess.run(['xelatex', '-interaction=nonstopmode', 'otchet.tex'],
                       cwd=OTCH, stdout=subprocess.DEVNULL)
    proverit_perepolneniya(os.path.join(OTCH, 'otchet.log'))
    print('готово:', os.path.join(OTCH, 'otchet.pdf'))


def proverit_perepolneniya(log, porog=1.0):
    """Контроль вёрстки: Overfull \\hbox есть ровно тот признак, по которому
    текст выезжает за отведённое ему место. Именно так в прежнем отчёте слово
    «предложенный» печаталось поверх числа в соседней колонке. Проверка
    обязательна, иначе о налезании узнаёт только читатель."""
    import re as _re
    if not os.path.exists(log):
        print('  журнал LaTeX не найден, проверка вёрстки пропущена'); return []
    txt = open(log, errors='replace').read()
    sluch = []
    for m in _re.finditer(r'Overfull \\hbox \(([0-9.]+)pt too wide\)(.{0,120})',
                          txt, _re.S):
        pt = float(m.group(1))
        if pt >= porog:
            sluch.append((pt, ' '.join(m.group(2).split())[:90]))
    sluch.sort(key=lambda z: -z[0])
    if not sluch:
        print('  вёрстка: переполнений строк нет')
    else:
        print('  ВНИМАНИЕ: переполнений строк: %d, худшие:' % len(sluch))
        for pt, ctx in sluch[:10]:
            print('      %6.1f pt  %s' % (pt, ctx))
    return sluch


if __name__ == '__main__':
    if len(sys.argv) < 2 or sys.argv[1] in ('spisok', '-h', '--help'):
        print(__doc__)
        print('Этапы:')
        for k, (_, f, op) in ETAPY.items():
            print('  %-12s %-20s %s' % (k, f, op))
        print('  %-12s %-20s %s' % ('risunki', '(все рисунки)', 'ris_dannye + ris_sravn + ris_kalib'))
        print('  %-12s %-20s %s' % ('otchet', '(сборка)', 'tablicy + sborka + pandoc + xelatex'))
        print('  %-12s %-20s %s' % ('vse', '(всё)', 'полный прогон, несколько часов'))
        sys.exit(0)
    et = sys.argv[1]; arg = sys.argv[2:]
    if et == 'risunki':
        risunki()
    elif et == 'otchet':
        otchet()
    elif et == 'vse':
        zapust(SRAV, 'avtor.py')
        for r in VSE_RYADY:
            zapust(SRAV, 'konveyer.py', [r])
        for r in ['N1', 'N2', 'N3', 'N6']:
            zapust(SRAV, 'mssv_progon.py', [r])
        for a in ['hmm', 'pelt', 'msg', 'lozh']:
            zapust(ATT, 'kalibrovka.py', [a])
        for a in ['msg', 'mssv']:
            zapust(ATT, 'perebor.py', [a])
        risunki(); otchet()
    elif et in ETAPY:
        kat, fajl, _ = ETAPY[et]
        sys.exit(zapust(kat, fajl, arg))
    else:
        print('неизвестный этап: %s (см. python zapusk.py spisok)' % et)
        sys.exit(1)
